nom=input("entrer votre prenom")
s=input("entrez votre sexe")
if s=="M":
    print("cher monsieur ",nom)
else:
    print("chere madame ",nom)
