#exercice 2

num=int(input("Entrer le nombre : "))
if num%3==0 and num%13==0:
    print(num,"est divisible par 3 et par 13")
else:
    print(num,"n'est pas divisible par 3 et par 13")
        
