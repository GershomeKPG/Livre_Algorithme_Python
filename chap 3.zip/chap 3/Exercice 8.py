for i in range(1,150,2):
    print (i)
