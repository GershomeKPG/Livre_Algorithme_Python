nbre=int(input("ENTRER LE NOMBRE : "))
for i in range(0,10):
    print(i,"x",nbre,"=",nbre*i)
         
