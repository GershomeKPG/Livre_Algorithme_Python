degreCel=float(input("La temperature en c : "))
degreF=(9/5)*degreCel+32
degreK=273+degreCel
print("La temperature : ",degreCel,'C = ',degreF,'F = ',degreK,'K')
