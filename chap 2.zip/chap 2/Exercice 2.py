###Resolution equation du premier degre

print("Equation : ax+b=0 avec a!=0")
a=int(input("a = "))
b=int(input("b = "))
x=-b/a
print("L'equation : ",a,'x+',b,'=0')#,sep='')
print("A pour racine x=",x)
