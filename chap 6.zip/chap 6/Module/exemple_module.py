from forme import*

form1=Rectangle(15,10)
mesure1= form1.Mesures()

form2=Carre(12)
mesure2=form2.Mesures()

print(mesure1,"\n")
print(mesure2,"\n")

