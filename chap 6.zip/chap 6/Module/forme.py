
class Rectangle(object):
    "Definition d'un Rectangle"
    def __init__(self,long,larg):
        self._long=long
        self._larg=larg
        self._Nom="Rectangle"
        
    def getLong(self):
        return self._long
    def getLarg(self):
        return self._larg
    
    def setlarg(self,larg):
        self._larg=larg
    def setLong(self,long):
        self._long=long
        
    def perimetre(self):
        per = "Le perimetre est 2x({}+{})={}"
        return per.format(self._long,self._larg,2*(self._long+self._larg))
    def surface(self):
        surf="Le Surface est {}x{}={}"
        return surf.format(self._long,self._larg,(self._long*self._larg))
    def Mesures(self):
        mes1 = "Un {0} de {1} sur {2} a pour mesure:".format(self._Nom,self._long,self._larg)
        mes2 = "Perimetre : {0:d}".format(2*(self._long+self._larg))
        mes3 = "Surface : {0:d}".format(self._long*self._larg)
        return mes1+"\n"+mes2+"\n"+mes3

class Carre(Rectangle):
    "Definition d'un Carre"
    def __init__(self,cote):
        Rectangle.__init__(self,cote,cote)
        self._Nom="Carre"


        
    
