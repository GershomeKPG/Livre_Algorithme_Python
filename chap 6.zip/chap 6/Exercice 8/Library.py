# creation de la classe library

from book import*

class Library(object):
    "creation d'une library"
    def __init__(self,nom="inconnue"):
        self._Nom=nom
        self._book=[]

    def getNom(self):
        return self._Nom
    def setNom(self,nom):
        self._Nom=nom
    def add_book(self,book):
        self._book.append(book)
    def remove_book(self,titre):
        book=[book for book in self._book if titre==book.getTitre()]
        index=self._book.index(book[0])
        self._book.pop(index)
        print("Le livre <<{}>> a ete supprime".format(titre))
    def find_book_by_autor(self,auteur):
        book=[book for book in self._book if auteur==book.getAuteur()]
        print("Les livres de l'auteur : {}".format(auteur))
        num=1
        for book in book:
            txt="{0}. {1}, publie en {2}"
            txt=txt.format(num,book.getTitre(),book.getAnnee())
            print(txt)
    def find_book_by_year(self,annee):
        book=[book for book in self._book if annee==book.getAnnee()]
        print("Les livres publie en {}".format(annee))
        num=1
        for book in book:
            txt="{0}. {1}, {2}"
            txt=txt.format(num,book.getAuteur(),book.getTitre())
            print(txt)
