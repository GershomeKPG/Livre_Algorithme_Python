# creation de la classe book

class book(object):
    "creation d'un livre"
    def __init__(self,titre="inconnu",auteur="inconnu",annee="inconnu"):
        self._titre=titre
        self._auteur=auteur
        self._annee=annee

    def getTitre(self):
        return self._titre
    def getAuteur(self):
        return self._auteur
    def getAnnee(self):
        return self._annee
    def setTitre(self,titre):
        self._titre=titre
    def setAuteur(self,auteur):
        self._auteur=auteur
    def setAnnee(self,annee):
        self._annee=annee
