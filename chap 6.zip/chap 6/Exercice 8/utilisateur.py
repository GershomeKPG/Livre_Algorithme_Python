from Library import *
from book import *
import pickle

def savedata(lib):
    with open(r"D:\Cours\Algoithme et Programmation\Exercice\Ex8_6\data","wb") as f:
        pickle.dump(lib,f)
def restaure():
    with open(r"D:\Cours\Algoithme et Programmation\Exercice\Ex8_6\data","rb") as f:
        libr=pickle.load(f)
    return libr

def ajouter():
    print("-----Ajouter un livre-----")
    aut=input("Auteur : ")
    titre=input("Titre : ")
    annee=input("Annee de publication : ")
    livre=book(titre=titre,auteur=aut,annee=annee)
    lib.add_book(livre)
    savedata(lib)

def trouverA():
    print("-----Trouver les livres selon l'annee-----")
    annee=input("Annee de publication : ")
    lib.find_book_by_year(annee)

def trouverAut():
    print("-----Trouver les livres selon l'Auteur-----")
    aut=input("Auteur : ")
    lib.find_book_by_autor(aut)

def Supprimer():
    print("-----Supprimer un livre selon le titre-----")
    titre=input("Titre : ")
    lib.remove_book(titre)
    savedata(lib)

fonct={'1':"ajouter()",'2':"trouverA()",'3':"trouverAut()",'4':"Supprimer()"}
lib=restaure()
while True:
    print("Entrer : ")
    print("0 : Pour quitter")
    print("1 : Pour Ajouter un livre")
    print("2 : Pour chercher les livres selon l'annee")
    print("3 : Pour chercher les livres selon l'Auteur")
    print("4 : Pour supprimer un livre")
    choix=input("Choix : ")
    if choix=='0':
        print("---Terminer---")
        break
    else:
        eval(fonct[choix])
