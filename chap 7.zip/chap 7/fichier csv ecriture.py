tableau=[['Etudiant','Info','Algo','Logique'],
         ['Ngoie','13.5','12','18'],
         ['Gloire','19','11.5','14'],
         ['Kitenge','14','15','13.5']]

import csv

with open(r"D:\Cours\Algoithme et Programmation\Code\CSV\cote2.csv",'w',newline='') as f:
    ecrire=csv.writer(f)
    for ligne in tableau:
        ecrire.writerow(ligne)

with open(r"D:\Cours\Algoithme et Programmation\Code\CSV\cote2.csv",'a',newline='') as f:
    ecrire=csv.writer(f)
    ecrire.writerow(['Best','13','14.5','14'])

    
