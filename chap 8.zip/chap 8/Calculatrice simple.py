
from math import *
from tkinter import *

def VerifierFactoriel(expression):
    while '!' in expression:
        point=expression.index('!')
        if expression[point-1]!=')':
            for i in range(point-1,-1,-1):
                if expression[i].isdigit() and i!=0:
                    continue
                else:
                    e=(expression[i+1:point])if i!=0 else (expression[i:point])
                    expression=expression.replace(e+"!",
                                                  str(eval("factorial(int("+e+"))")))
                    break
        else:
            for i in range(point-2,-1,-1):
                if expression[i]=='(' and i!=0:
                    continue
                else:
                    e=expression[i+1:point]if i!=0 else (expression[i:point])
                    if e.count('(')==e.count(')'):
                        expression=expression.replace(e+"!",
                                                      str(eval("factorial(int("+e+"))")))
                        break
                    else:
                        continue
    return expression
                    
def operation(tch):
    global result
    global textE
    global Ans
    if tch=='AC':
        textE=textE[0:len(textE)-1]
    elif tch=='=':
        val=textE.replace('X','*')
        val=val.replace('log','log10')
        val=val.replace('ln','log')
        val=val.replace('Ans',str(Ans))
        val=val.replace('^','**')
        try:
            val=VerifierFactoriel(val)
            result=str(eval(val))
            EcranRes.configure(text=result)
            Ans=result
        except:
            EcranRes.configure(text='Erreur')
        
    elif tch=='C':
        textE=''
        EcranRes.configure(text='0')
    else:
        textE=textE+tch
    Ecrantape.configure(text=textE)
        

textE=''
Ans=''
fen = Tk()
fen.title("Calculatrice")
fen.geometry("250x340")
fen.resizable(width=False,height=False)

touche=[['pi','sin','cos','tan'],
        ['log','ln','e^x','10^x'],
        ['!','(',')','x^y'],
        ['AC','C','%','/'],
        ['7','8','9','X'],
        ['4','5','6','-'],
        ['1','2','3','+'],
        ['0','.','Ans','=']]

Valeur={'pi':'pi','sin':'sin(','cos':'cos(','tan':'tan(',
        'log':'log(','ln':'ln(','e^x':'e^','10^x':'10^',
        '!':'!','(':'(',')':')','x^y':'^',
        'AC':'AC','C':'C','%':'%','/':'/',
        '7':'7','8':'8','9':'9','X':'X',
        '4':'4','5':'5','6':'6','-':'-',
        '1':'1','2':'2','3':'3','+':'+',
        '0':'0','.':'.','Ans':'Ans','=':'='}

titre=Label(fen,text='Calculatrice',fg='blue',
            font=('Comic Sans MS','13','italic'))
titre.grid(row=0,column=0,columnspan=4,padx=5,pady=5,sticky=W)
Ecrantape=Label(fen,text='',font=('Cambria',10),
                relief=FLAT,bg='white',width=34,anchor=E)
Ecrantape.grid(row=1,column=0,columnspan=4,sticky=W,padx=3)
EcranRes=Label(fen,text='0',font=('Arial Narrow',15),
               relief=FLAT,bg='white',width=24,anchor=E)
EcranRes.grid(row=2,column=0,columnspan=4,sticky=NW,padx=2)

li=0
co=0
bout=[Button(fen,text=tch,width=6,command=lambda tch=tch:operation(Valeur[tch]))
      for ligne in touche for tch in ligne ]
##for ligne in touche:
##    for tch in ligne:
##        btn=Button(fen,text=tch,width=6,command=lambda:operation(Valeur[tch]))
##        bout.append(btn)
for b in bout:
    b.grid(row=co+3,column=li%4,padx=2,pady=2)
    li=li+1
    co=li//4


fen.mainloop()

