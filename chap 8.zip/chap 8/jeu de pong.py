import tkinter as tk

# Paramètres du jeu
WIDTH = 600
HEIGHT = 400
PADDLE_WIDTH = 10
PADDLE_HEIGHT = 80
BALL_SIZE = 20
BALL_SPEED = 4
PADDLE_SPEED = 20

class PongGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Jeu de Pong 🏓")

        # Création du Canvas
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="black")
        self.canvas.pack()

        # Création des raquettes et de la balle
        self.left_paddle = self.canvas.create_rectangle(20, (HEIGHT // 2) - (PADDLE_HEIGHT // 2),
                                                        20 + PADDLE_WIDTH, (HEIGHT // 2) + (PADDLE_HEIGHT // 2),
                                                        fill="white")
        self.right_paddle = self.canvas.create_rectangle(WIDTH - 30, (HEIGHT // 2) - (PADDLE_HEIGHT // 2),
                                                         WIDTH - 30 + PADDLE_WIDTH, (HEIGHT // 2) + (PADDLE_HEIGHT // 2),
                                                         fill="white")
        self.ball = self.canvas.create_oval((WIDTH // 2) - (BALL_SIZE // 2), (HEIGHT // 2) - (BALL_SIZE // 2),
                                            (WIDTH // 2) + (BALL_SIZE // 2), (HEIGHT // 2) + (BALL_SIZE // 2),
                                            fill="red")

        # Vitesse de la balle
        self.ball_dx = BALL_SPEED
        self.ball_dy = BALL_SPEED

        # Scores des joueurs
        self.left_score = 0
        self.right_score = 0
        self.score_text = self.canvas.create_text(WIDTH // 2, 20, text="0 - 0", font=("Arial", 20), fill="white")

        # Lier les touches du clavier
        self.root.bind("<w>", self.move_paddle)
        self.root.bind("<s>", self.move_paddle)
        self.root.bind("<Up>", self.move_paddle)
        self.root.bind("<Down>", self.move_paddle)

        # Lancer le jeu
        self.update()

    def move_paddle(self, event):
        """Déplace les raquettes en fonction des touches pressées."""
        if event.keysym == "w":
            self.canvas.move(self.left_paddle, 0, -PADDLE_SPEED)
        elif event.keysym == "s":
            self.canvas.move(self.left_paddle, 0, PADDLE_SPEED)
        elif event.keysym == "Up":
            self.canvas.move(self.right_paddle, 0, -PADDLE_SPEED)
        elif event.keysym == "Down":
            self.canvas.move(self.right_paddle, 0, PADDLE_SPEED)

    def update(self):
        """Met à jour le jeu : mouvement de la balle et gestion des collisions."""
        self.canvas.move(self.ball, self.ball_dx, self.ball_dy)
        x1, y1, x2, y2 = self.canvas.coords(self.ball)
        lpx1, lpy1, lpx2, lpy2 = self.canvas.coords(self.left_paddle)
        rpx1, rpy1, rpx2, rpy2 = self.canvas.coords(self.right_paddle)

        # Rebond contre le haut et le bas
        if y1 <= 0 or y2 >= HEIGHT:
            self.ball_dy = -self.ball_dy

        # Collision avec les raquettes
        if x1 <= lpx2 and lpy1 < y1 < lpy2:
            self.ball_dx = -self.ball_dx
        elif x2 >= rpx1 and rpy1 < y2 < rpy2:
            self.ball_dx = -self.ball_dx

        # Gestion du score
        if x1 <= 0:
            self.right_score += 1
            self.reset_ball()
        elif x2 >= WIDTH:
            self.left_score += 1
            self.reset_ball()

        # Mettre à jour le score
        self.canvas.itemconfig(self.score_text, text=f"{self.left_score} - {self.right_score}")

        # Rafraîchir l'animation
        self.root.after(20, self.update)

    def reset_ball(self):
        """Replace la balle au centre et inverse sa direction."""
        self.canvas.coords(self.ball, (WIDTH // 2) - (BALL_SIZE // 2), (HEIGHT // 2) - (BALL_SIZE // 2),
                           (WIDTH // 2) + (BALL_SIZE // 2), (HEIGHT // 2) + (BALL_SIZE // 2))
        self.ball_dx = -self.ball_dx

# Lancer le jeu
root = tk.Tk()
game = PongGame(root)
root.mainloop()
