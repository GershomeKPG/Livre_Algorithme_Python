
from tkinter import *

def textDef1():
    text=txtsp1.get()
    label1.configure(text=text)
def textDef2():
    text=txtsp2.get()
    label2.configure(text=text)

fen=Tk()
fen.geometry("200x150")
fen.title("Widget Entry")

label1=Label(fen,fg='orange',font="Cambria 12 italic")
txtsp1=Spinbox(fen,justify='center',from_=0,to=10,increment=0.5,
            command=textDef1,width=10)

label2=Label(fen,fg='blue',font="Cambria 12 italic")
txtsp2=Spinbox(fen,justify='center',width=10
               ,values=["Homme","Femme","Autre"])
btn=Button(fen,text="Enter",command=textDef2)
label1.grid(pady=5, padx=5,row=0,column=0)
label2.grid(pady=5, padx=5,row=0,column=1)
txtsp1.grid(pady=5, padx=5,row=1,column=0)
txtsp2.grid(pady=5, padx=5,row=1,column=1)
btn.grid(pady=5, padx=5,row=2,column=1)
fen.mainloop()

