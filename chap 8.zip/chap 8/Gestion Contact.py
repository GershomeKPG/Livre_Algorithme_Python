

def importer():
    global contact
    file=filedialog.askopenfilename(title="Importer contact",
                              filetypes=[("Fichier csv","*.csv"),("Tous fichiers","*.*")])
    with open(file,'r') as f:
        rd = list(csv.reader(f))
    contact=contact+rd[1:]
    ActualiserTableau()

def ActualiserTableau():
    tab.delete(*tab.get_children())
    for id, data in enumerate(contact):
        tab.insert("",index='end',iid=id,text=str(id),values=data)

def afficher(event):
    sel=tab.selection()[0]
    val=tab.item(sel,"values")
    txtNom.delete(0,'end')
    txtPhone.delete(0,'end')
    txtMail.delete(0,'end')
    txtNom.insert("end",val[0])
    txtPhone.insert("end",val[1])
    txtMail.insert("end",val[2])

def save():
    global contact
    nom=txtNom.get()
    phone=txtPhone.get()
    mail=txtMail.get()
    if nom=="" or phone=="" or mail=="":
        messagebox.showerror(title="Erreur",message="Veillez remplir\nTout les champ")
    else:
        data=[nom,phone,mail]
        contact.append(data)
        messagebox.showinfo(title="Save",message="Enregistrer avec succes")
        ActualiserTableau()

def recherche(event):
    rech=txtRec.get()
    rech=[ligne for ligne in contact if rech in ligne[0]]
    tab.delete(*tab.get_children())
    for id, data in enumerate(rech):
        tab.insert("",index='end',iid=id,text=str(id),values=data)
    

from tkinter import*
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog
import csv

fen=Tk()
fen.title("Gestion des Contacts")
fen.geometry("400x400")
colonne=["Nom","Telephone","Email"]

contact=[]

style=ttk.Style()
style.configure("txt.TEntry",justify='center',font="Cambria 12",relief='ridge')
style.configure("txt.TLabel",anchor='w',font="Cambria 12")
style.configure("btn.TButton",font="Cambria 12",width=9)
style.configure("tab.Treeview",font="Cambria 12",background='light pink')
style.configure("tab.Treeview.Heading",font="Cambria 12 italic",
                forground='blue',background="white")

labF=LabelFrame(fen,text="Contact",relief='solid',width=300,height=150)
ttk.Label(labF,text="Nom           : ",style="txt.TLabel").grid(row=0,column=0, sticky='w')
ttk.Label(labF,text="Telephone : ",style="txt.TLabel").grid(row=1,column=0, sticky='w')
ttk.Label(labF,text="Email         : ",style="txt.TLabel").grid(row=2,column=0, sticky='w')

txtNom=ttk.Entry(labF,width=30,style="txt.TEntry",justify='center')
txtPhone=ttk.Entry(labF,width=30,style="txt.TEntry",justify='center')
txtMail=ttk.Entry(labF,width=30,style="txt.TEntry",justify='center')
txtNom.grid(row=0,column=1, sticky='w',pady=3)
txtPhone.grid(row=1,column=1, sticky='w',pady=3)
txtMail.grid(row=2,column=1, sticky='w',pady=3)

fr=Frame(fen,width=300,height=150,relief='solid')
btnsave=ttk.Button(fr,text="Save",style="btn.TButton",command=save)
btnAdd=ttk.Button(fr,text="Add",style="btn.TButton")
btnEdit=ttk.Button(fr,text="Edit",style="btn.TButton")
btnDel=ttk.Button(fr,text="Delete",style="btn.TButton")
btnRec=ttk.Button(fr,text="Research",style="btn.TButton")
btnAct=ttk.Button(fr,text="Actualise",style="btn.TButton",command=ActualiserTableau)
txtRec=ttk.Entry(fr,width=30,style="txt.TEntry",justify='center')

btnsave.grid(row=0,column=0,padx=2,pady=2)
btnAdd.grid(row=0,column=1,padx=2,pady=2)
btnEdit.grid(row=0,column=2,padx=2,pady=2)
btnDel.grid(row=0,column=3,padx=2,pady=2)
btnRec.grid(row=1,column=0,padx=2,pady=2,sticky='e')
txtRec.grid(row=1,column=1,columnspan=2,padx=2,pady=2)
btnAct.grid(row=1,column=3,sticky='w',padx=2,pady=2)

tab=ttk.Treeview(fen,height=10,column=colonne,style="tab.Treeview")
tab.heading("#0",text="No")
tab.heading("Nom",text="Nom")
tab.heading("Telephone",text="Telephone")
tab.heading("Email",text="Email")
tab.column("#0",width=30,anchor='center')
tab.column("Nom",width=100,anchor='w')
tab.column("Telephone",width=100,anchor='center')
tab.column("Email",width=140,anchor='center')

tab.bind("<<TreeviewSelect>>",afficher)
txtRec.bind("<KeyPress>",recherche)
btnRec.bind("<ButtonPress>",recherche)

Bar_menu=Menu(fen,tearoff=0)
menu_fil=Menu(Bar_menu,tearoff=0)
menu_fil.add_command(label="Contact",state="disabled")
menu_fil.add_command(label="Exporter", accelerator="CTRL-E")
menu_fil.add_command(label="Importer",accelerator="CTRL-I",command=importer)
menu_fil.add_separator()
menu_fil.add_command(label="Quitter",accelerator="CTRL-Q")
Bar_menu.add_cascade(menu=menu_fil,label="Fichier")
fen.config(menu=Bar_menu)

labF.pack(padx=5,pady=5,fill='x')
fr.pack(padx=5,pady=5,fill='x')
tab.pack(padx=5,pady=5,fill='x')
