from tkinter import*
from tkinter import ttk
from math import*

def dessiner(event):
    global newTrain
    global positionAct
    global positionPas
    if DrEr:
        if newTrain:
            positionPas=(event.x,event.y)
            newTrain=False
        d=sqrt(pow(positionPas[0]-event.x,2)+pow(positionPas[1]-event.y,2))
        if d>1:
            PositionAct=(event.x,event.y)
            can.create_line(positionPas,PositionAct,fill=coul.get(),
                            width=3,capstyle=pice.get())
            positionPas=(event.x,event.y)
    else:
        lin=can.find_closest(event.x,event.y)
        can.delete(lin)
    
def reset(event):
    global newTrain
    newTrain=True
def erase():
    global DrEr
    DrEr=False
    can.itemconfigure(act,text="Action : Eraser")
def draw():
    global DrEr
    DrEr=True
    can.itemconfigure(act,text="Action : Marker")

fen=Tk()
fen.geometry("550x300")
fen.title("Ardoise magique")

newTrain=True
DrEr=True
positionAct=(0,0)
positionPas=(0,0)

couleur=["black","blue","red","green"]
pice=StringVar(value="round")

largeur=380
hauteur=350

ers1=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\eraser1.png''')
ers2=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\eraser2.png''')
ers3=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\erase3.png''')
pen1=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\pen1.png''')
pen2=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\pen2.png''')
pen3=PhotoImage(file=r'''D:\Cours\Algoithme et
                Programmation\Code\Graphic\icon\pen3.png''')

styl=ttk.Style()
styl.configure("btn1.TButton",
               foreground="orange",
               background="silver",
               font="calibri 12",
               image=ers1
              )
styl.map("btn1.TButton",
               foreground=[("pressed","cyan"),("active","navy blue")],
               background=[("pressed","gray"),("active","light gray")],
         image=[("pressed",ers2),("active",ers3)])

styl.configure("btn2.TButton",
               foreground="orange",
               background="silver",
               font="calibri 12",
               image=pen1
              )
styl.map("btn2.TButton",
               foreground=[("pressed","cyan"),("active","navy blue")],
               background=[("pressed","gray"),("active","light gray")],
         image=[("pressed",pen2),("active",pen3)])
styl.configure("cb.TCombobox",
               justify="right",
               font="cambia 14 bold",
               width=10
              )

can=Canvas(fen,width=largeur,height=hauteur,bg="Ivory",relief="solid")
cont=LabelFrame(fen,width=150,height=hauteur,labelanchor='nw',
                text="Outils",relief="ridge",bg="white")
act=can.create_text(5,8,text="Action : Marker",font=("Cambria 10"),
                    justify='right',anchor='w')

can.bind("<B1-Motion>",dessiner)
can.bind("<ButtonRelease-1>",reset)

coul=ttk.Combobox(cont,values=couleur,style="cb.TCombobox",state='readonly')
coul.set("black")
btn_PR=ttk.Button(cont,style="btn1.TButton",command=erase)
btn_Pen=ttk.Button(cont,style="btn2.TButton",command=draw)
p1=Radiobutton(cont,text="Rond",value="round",variable=pice)
p2=Radiobutton(cont,text="Carre",value="butt",variable=pice)

btn_Pen.grid(row=0,column=0, padx=2,pady=5)
btn_PR.grid(row=1,column=0, padx=2,pady=5)
coul.grid(row=2,column=0, padx=2,pady=5)
p1.grid(row=3,column=0, padx=2,pady=5)
p2.grid(row=4,column=0, padx=2,pady=5)


can.pack(side=LEFT,padx=2,pady=5)
cont.pack(side=RIGHT,padx=2,pady=5, fill='y')

fen.mainloop()

