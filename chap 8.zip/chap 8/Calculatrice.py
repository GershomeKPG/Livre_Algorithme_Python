
def getButton(btn):
    global aff
    if btn=='AC':
        aff='0'
        text.configure(text=aff)
    elif btn=='C':
        aff=aff[:len(aff)-1]
        if aff=="":
            aff="0"
        text.configure(text=aff)
    elif btn=='=':
        result=eval(aff.replace('X','*'))
        text.configure(text=result)
    else:
        if aff=='0':
            aff=""
        aff=aff+btn
        text.configure(text=aff)
    

from tkinter import*
from functools import partial

lig=1
col=0
sp=1
tbt=4
aff="0"
fen=Tk()
fen.geometry("190x230")
fen.title("Calculatrice")

touche=[['C','AC','%','X'],
        ['7','8','9','/'],
        ['4','5','6','-'],
        ['1','2','3','+'],
        ['=','0','.']]
text=Label(fen,text=aff,font=('Arial',11),bg='white',anchor=E,relief=SUNKEN,width=15)
text.grid(row=0,column=0,columnspan=4,padx=2,pady=2)
for btnLign in touche:
    col=0
    for btnCol in btnLign:
        if btnCol=='=':
            sp=2
            tbt=10
        else:
            sp=1
            tbt=4
        Button(fen,text=btnCol,width=tbt,command=partial(getButton,btnCol)).grid(row=lig,columnspan=sp,column=col,padx=2,pady=2)
        if sp==2:
            col+=1
        col+=1
    lig+=1
