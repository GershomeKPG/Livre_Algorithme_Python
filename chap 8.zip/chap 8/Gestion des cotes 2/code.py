import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import csv
import os
import re
from datetime import datetime
import hashlib
import random

class StudentGradeManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestionnaire des Cotes Universitaires")
        self.root.geometry("1000x600")
        self.root.minsize(900, 550)
        
        # Configuration des couleurs et styles
        self.colors = {
            "primary": "#1a73e8",
            "secondary": "#34a853",
            "accent": "#ea4335",
            "light_bg": "#f8f9fa",
            "dark_bg": "#202124",
            "light_gray": "#e0e0e0",
            "medium_gray": "#9aa0a6",
            "text_dark": "#202124",
            "text_light": "#ffffff"
        }
        
        # Configuration des styles ttk
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Style des boutons
        self.style.configure('TButton', 
                             font=('Segoe UI', 10),
                             background=self.colors["primary"],
                             foreground=self.colors["text_light"])
        
        # Style des onglets
        self.style.configure('TNotebook.Tab', 
                            font=('Segoe UI', 11),
                            padding=[10, 5])
        
        # Style des entêtes de tableaux
        self.style.configure('Treeview.Heading', 
                            font=('Segoe UI', 10, 'bold'))
        
        # Style des tableaux
        self.style.configure('Treeview',
                            font=('Segoe UI', 10),
                            rowheight=25)
        
        # Variables d'état
        self.current_user = None
        self.user_role = None
        
        # Création des fichiers s'ils n'existent pas
        self.create_csv_files()
        
        # Afficher l'écran d'accueil
        self.show_welcome_screen()
    
    def create_csv_files(self):
        """Crée les fichiers CSV nécessaires s'ils n'existent pas."""
        # Structure: username,password_hash,role,promotion
        if not os.path.exists('utilisateurs.csv'):
            with open('utilisateurs.csv', 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['username', 'password_hash', 'role', 'promotion'])
                # Créer un compte admin par défaut (admin/admin)
                admin_pwd_hash = hashlib.sha256("admin".encode()).hexdigest()
                writer.writerow(['admin', admin_pwd_hash, 'admin', ''])
        
        # Structure: student_id,name,promotion,course_id,interrogation_score,exam_score
        if not os.path.exists('cotes.csv'):
            with open('cotes.csv', 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['student_id', 'name', 'promotion', 'course_id', 'interrogation_score', 'exam_score'])
        
        # Structure: course_id,course_name,credits,promotion
        if not os.path.exists('cours.csv'):
            with open('cours.csv', 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['course_id', 'course_name', 'credits', 'promotion'])
                
        # Structure: id,name,promotion
        if not os.path.exists('etudiants.csv'):
            with open('etudiants.csv', 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['id', 'name', 'promotion'])
    
    def clear_window(self):
        """Efface tous les widgets de la fenêtre actuelle."""
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def show_welcome_screen(self):
        """Affiche l'écran d'accueil de l'application."""
        self.clear_window()
        
        # Création d'un cadre pour l'écran d'accueil
        welcome_frame = tk.Frame(self.root, bg=self.colors["light_bg"])
        welcome_frame.pack(fill=tk.BOTH, expand=True)
        
        # Logo (texte stylisé)
        logo_label = tk.Label(welcome_frame, 
                             text="Cote de L'université",
                             font=("Segoe UI", 32, "bold"),
                             fg=self.colors["primary"],
                             bg=self.colors["light_bg"])
        logo_label.pack(pady=(100, 10))
        
        # Message de bienvenue
        welcome_label = tk.Label(welcome_frame, 
                                text="Bienvenue dans votre gestionnaire de cotes universitaires",
                                font=("Segoe UI", 14),
                                fg=self.colors["text_dark"],
                                bg=self.colors["light_bg"])
        welcome_label.pack(pady=(10, 50))
        
        # Cadre pour les boutons
        buttons_frame = tk.Frame(welcome_frame, bg=self.colors["light_bg"])
        buttons_frame.pack(pady=20)
        
        # Bouton de connexion
        login_button = tk.Button(buttons_frame,
                                text="Se connecter",
                                font=("Segoe UI", 12),
                                bg=self.colors["primary"],
                                fg=self.colors["text_light"],
                                padx=20, pady=10,
                                relief=tk.FLAT,
                                command=self.show_login_screen)
        login_button.pack(side=tk.LEFT, padx=10)
        
        # Bouton d'inscription
        register_button = tk.Button(buttons_frame,
                                   text="S'inscrire",
                                   font=("Segoe UI", 12),
                                   bg=self.colors["secondary"],
                                   fg=self.colors["text_light"],
                                   padx=20, pady=10,
                                   relief=tk.FLAT,
                                   command=self.show_register_screen)
        register_button.pack(side=tk.LEFT, padx=10)
        
        # Version et copyright
        version_label = tk.Label(welcome_frame, 
                               text="v1.0 - © 2025 UniGrade",
                               font=("Segoe UI", 8),
                               fg=self.colors["medium_gray"],
                               bg=self.colors["light_bg"])
        version_label.pack(side=tk.BOTTOM, pady=10)
    
    def show_login_screen(self):
        """Affiche l'écran de connexion."""
        self.clear_window()
        
        # Frame principal avec dégradé (simulé)
        login_frame = tk.Frame(self.root, bg=self.colors["light_bg"])
        login_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame pour le formulaire
        form_frame = tk.Frame(login_frame, 
                             bg="white",
                             highlightbackground=self.colors["light_gray"],
                             highlightthickness=1)
        form_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=400, height=350)
        
        # Titre
        title_label = tk.Label(form_frame,
                              text="Connexion",
                              font=("Segoe UI", 20, "bold"),
                              fg=self.colors["primary"],
                              bg="white")
        title_label.pack(pady=(30, 20))
        
        # Username
        username_frame = tk.Frame(form_frame, bg="white")
        username_frame.pack(fill=tk.X, padx=30, pady=5)
        
        username_label = tk.Label(username_frame,
                                 text="Nom d'utilisateur",
                                 font=("Segoe UI", 10),
                                 anchor=tk.W,
                                 bg="white")
        username_label.pack(fill=tk.X)
        
        self.username_entry = tk.Entry(username_frame,
                                      font=("Segoe UI", 12),
                                      relief=tk.SOLID,
                                      bd=1)
        self.username_entry.pack(fill=tk.X, pady=(5, 0))
        
        # Password
        password_frame = tk.Frame(form_frame, bg="white")
        password_frame.pack(fill=tk.X, padx=30, pady=5)
        
        password_label = tk.Label(password_frame,
                                 text="Mot de passe",
                                 font=("Segoe UI", 10),
                                 anchor=tk.W,
                                 bg="white")
        password_label.pack(fill=tk.X)
        
        self.password_entry = tk.Entry(password_frame,
                                      font=("Segoe UI", 12),
                                      relief=tk.SOLID,
                                      bd=1,
                                      show="•")
        self.password_entry.pack(fill=tk.X, pady=(5, 0))
        
        # Bouton de connexion
        login_button = tk.Button(form_frame,
                                text="Se connecter",
                                font=("Segoe UI", 12),
                                bg=self.colors["primary"],
                                fg=self.colors["text_light"],
                                relief=tk.FLAT,
                                padx=20, pady=8,
                                command=self.login)
        login_button.pack(pady=20)
        
        # Lien vers l'inscription
        register_link = tk.Label(form_frame,
                                text="Pas encore inscrit? S'inscrire",
                                font=("Segoe UI", 10),
                                fg=self.colors["primary"],
                                bg="white",
                                cursor="hand2")
        register_link.pack(pady=5)
        register_link.bind("<Button-1>", lambda e: self.show_register_screen())
        
        # Bouton retour
        back_button = tk.Button(form_frame,
                               text="Retour",
                               font=("Segoe UI", 10),
                               bg="white",
                               fg=self.colors["text_dark"],
                               relief=tk.FLAT,
                               command=self.show_welcome_screen)
        back_button.pack(side=tk.BOTTOM, pady=10)
    
    def show_register_screen(self):
        """Affiche l'écran d'inscription."""
        self.clear_window()
        
        # Frame principal avec dégradé verdâtre (simulé)
        register_frame = tk.Frame(self.root, bg="#f0f7f0")  # Fond vert clair
        register_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame pour le formulaire
        form_frame = tk.Frame(register_frame, 
                             bg="white",
                             highlightbackground=self.colors["light_gray"],
                             highlightthickness=1)
        form_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=400, height=350)  # Ajusté la hauteur car plus de champs Promotion
        
        # Titre
        title_label = tk.Label(form_frame,
                              text="Inscription",
                              font=("Segoe UI", 20, "bold"),
                              fg=self.colors["secondary"],
                              bg="white")
        title_label.pack(pady=(30, 20))
        
        # Username
        username_frame = tk.Frame(form_frame, bg="white")
        username_frame.pack(fill=tk.X, padx=30, pady=5)
        
        username_label = tk.Label(username_frame,
                                 text="Nom d'utilisateur",
                                 font=("Segoe UI", 10),
                                 anchor=tk.W,
                                 bg="white")
        username_label.pack(fill=tk.X)
        
        self.reg_username_entry = tk.Entry(username_frame,
                                         font=("Segoe UI", 12),
                                         relief=tk.SOLID,
                                         bd=1)
        self.reg_username_entry.pack(fill=tk.X, pady=(5, 0))
        
        # Password
        password_frame = tk.Frame(form_frame, bg="white")
        password_frame.pack(fill=tk.X, padx=30, pady=5)
        
        password_label = tk.Label(password_frame,
                                 text="Mot de passe",
                                 font=("Segoe UI", 10),
                                 anchor=tk.W,
                                 bg="white")
        password_label.pack(fill=tk.X)
        
        self.reg_password_entry = tk.Entry(password_frame,
                                         font=("Segoe UI", 12),
                                         relief=tk.SOLID,
                                         bd=1,
                                         show="•")
        self.reg_password_entry.pack(fill=tk.X, pady=(5, 0))
        
        # Confirm Password
        confirm_frame = tk.Frame(form_frame, bg="white")
        confirm_frame.pack(fill=tk.X, padx=30, pady=5)
        
        confirm_label = tk.Label(confirm_frame,
                                text="Confirmer le mot de passe",
                                font=("Segoe UI", 10),
                                anchor=tk.W,
                                bg="white")
        confirm_label.pack(fill=tk.X)
        
        self.reg_confirm_entry = tk.Entry(confirm_frame,
                                        font=("Segoe UI", 12),
                                        relief=tk.SOLID,
                                        bd=1,
                                        show="•")
        self.reg_confirm_entry.pack(fill=tk.X, pady=(5, 0))
        
        # Bouton d'inscription
        register_button = tk.Button(form_frame,
                                   text="Valider l'inscription",
                                   font=("Segoe UI", 12),
                                   bg=self.colors["secondary"],
                                   fg=self.colors["text_light"],
                                   relief=tk.FLAT,
                                   padx=20, pady=8,
                                   command=self.register)
        register_button.pack(pady=20)
        
        # Lien vers la connexion
        login_link = tk.Label(form_frame,
                             text="Déjà inscrit? Se connecter",
                             font=("Segoe UI", 10),
                             fg=self.colors["primary"],
                             bg="white",
                             cursor="hand2")
        login_link.pack(pady=5)
        login_link.bind("<Button-1>", lambda e: self.show_login_screen())
        
        # Bouton retour
        back_button = tk.Button(form_frame,
                               text="Retour",
                               font=("Segoe UI", 10),
                               bg="white",
                               fg=self.colors["text_dark"],
                               relief=tk.FLAT,
                               command=self.show_welcome_screen)
        back_button.pack(side=tk.BOTTOM, pady=10)
    
    def login(self):
        """Gère le processus de connexion."""
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        # Vérifier les identifiants
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        user_found = False
        
        with open('utilisateurs.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['username'] == username and row['password_hash'] == password_hash:
                    user_found = True
                    self.current_user = username
                    self.user_role = row['role']
                    self.user_promotion = row['promotion'] if 'promotion' in row else None
                    break
        
        if user_found:
            messagebox.showinfo("Succès", f"Bienvenue, {username}!")
            self.show_dashboard()
        else:
            messagebox.showerror("Erreur", "Nom d'utilisateur ou mot de passe incorrect.")
    
    def register(self):
        """Gère le processus d'inscription."""
        username = self.reg_username_entry.get().strip()
        password = self.reg_password_entry.get()
        confirm = self.reg_confirm_entry.get()
        
        if not username or not password or not confirm:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs obligatoires.")
            return
        
        if password != confirm:
            messagebox.showerror("Erreur", "Les mots de passe ne correspondent pas.")
            return
        
        # Vérifier si l'utilisateur existe déjà
        user_exists = False
        with open('utilisateurs.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['username'] == username:
                    user_exists = True
                    break
        
        if user_exists:
            messagebox.showerror("Erreur", "Ce nom d'utilisateur existe déjà.")
            return
        
        # Créer le nouvel utilisateur
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        with open('utilisateurs.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            # Par défaut, les nouveaux utilisateurs sont des étudiants
            writer.writerow([username, password_hash, 'student', ''])
        
        messagebox.showinfo("Succès", "Inscription réussie! Vous pouvez maintenant vous connecter.")
        self.show_login_screen()
    
    def show_dashboard(self):
        """Affiche le tableau de bord principal de l'application."""
        self.clear_window()
        
        # Frame principal
        main_frame = tk.Frame(self.root, bg=self.colors["light_bg"])
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # En-tête avec titre et infos utilisateur
        header_frame = tk.Frame(main_frame, bg=self.colors["primary"], height=60)
        header_frame.pack(fill=tk.X)
        
        app_title = tk.Label(header_frame, 
                           text="Cote de L'université",
                           font=("Segoe UI", 18, "bold"),
                           fg=self.colors["text_light"],
                           bg=self.colors["primary"])
        app_title.pack(side=tk.LEFT, padx=20, pady=10)
        
        # Affichage de l'utilisateur connecté
        user_info = tk.Label(header_frame,
                            text=f"Connecté en tant que: {self.current_user}",
                            font=("Segoe UI", 10),
                            fg=self.colors["text_light"],
                            bg=self.colors["primary"])
        user_info.pack(side=tk.RIGHT, padx=20, pady=15)
        
        # Bouton de déconnexion
        logout_button = tk.Button(header_frame,
                                 text="Déconnexion",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["primary"],
                                 fg=self.colors["text_light"],
                                 activebackground=self.colors["accent"],
                                 relief=tk.FLAT,
                                 command=self.logout)
        logout_button.pack(side=tk.RIGHT, padx=5, pady=15)
        
        # Notebook pour les onglets
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Onglet 1: Liste des cotes
        self.grades_tab = tk.Frame(self.notebook, bg=self.colors["light_bg"])
        self.notebook.add(self.grades_tab, text=" Liste des cotes ")
        
        # Onglet 2: Gestion des cours
        self.courses_tab = tk.Frame(self.notebook, bg=self.colors["light_bg"])
        self.notebook.add(self.courses_tab, text=" Gestion des cours ")
        
        # Onglet 3: Gestion des étudiants (nouveau)
        self.students_tab = tk.Frame(self.notebook, bg=self.colors["light_bg"])
        self.notebook.add(self.students_tab, text=" Gestion des étudiants ")
        
        # Onglet 4: Paramètres du compte
        self.settings_tab = tk.Frame(self.notebook, bg=self.colors["light_bg"])
        self.notebook.add(self.settings_tab, text=" Paramètres du compte ")
        
        # Initialiser le contenu des onglets
        self.setup_grades_tab()
        self.setup_courses_tab()
        self.setup_students_tab()  # Nouvel onglet
        self.setup_settings_tab()
    
    def setup_grades_tab(self):
        """Configure l'onglet de liste des cotes."""
        grades_frame = tk.Frame(self.grades_tab, bg=self.colors["light_bg"])
        grades_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # En-tête et filtres
        header_frame = tk.Frame(grades_frame, bg=self.colors["light_bg"])
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Titre
        title_label = tk.Label(header_frame,
                              text="Liste des cotes",
                              font=("Segoe UI", 16, "bold"),
                              fg=self.colors["text_dark"],
                              bg=self.colors["light_bg"])
        title_label.pack(side=tk.LEFT)
        
        # Barre de recherche
        search_frame = tk.Frame(header_frame, bg=self.colors["light_bg"])
        search_frame.pack(side=tk.RIGHT)
        
        search_label = tk.Label(search_frame,
                               text="Rechercher:",
                               font=("Segoe UI", 10),
                               bg=self.colors["light_bg"])
        search_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.search_entry = tk.Entry(search_frame, width=25, font=("Segoe UI", 10))
        self.search_entry.pack(side=tk.LEFT)
        self.search_entry.bind("<KeyRelease>", self.search_grades)
        
        # Filtre par promotion
        filter_frame = tk.Frame(header_frame, bg=self.colors["light_bg"])
        filter_frame.pack(side=tk.RIGHT, padx=(0, 20))
        
        filter_label = tk.Label(filter_frame,
                               text="Filtrer par promotion:",
                               font=("Segoe UI", 10),
                               bg=self.colors["light_bg"])
        filter_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.filter_var = tk.StringVar()
        filter_options = ["Tous", "L1", "L2", "L3", "M1", "M2"]
        filter_combobox = ttk.Combobox(filter_frame,
                                     textvariable=self.filter_var,
                                     values=filter_options,
                                     width=5,
                                     state="readonly")
        filter_combobox.pack(side=tk.LEFT)
        filter_combobox.current(0)
        filter_combobox.bind("<<ComboboxSelected>>", self.filter_grades)
        
        # Tableau des cotes
        table_frame = tk.Frame(grades_frame, bg=self.colors["light_bg"])
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Colonnes du tableau: Étudiant, Promotion, Cours, Interrogation, Examen, Note Finale, Statut
        self.grades_tree = ttk.Treeview(table_frame, columns=("student", "promotion", "course", "interrogation", "exam", "final", "status"))
        
        # Configuration des colonnes
        self.grades_tree.column("#0", width=0, stretch=tk.NO)  # Colonne invisible
        self.grades_tree.column("student", width=150, anchor=tk.W)
        self.grades_tree.column("promotion", width=80, anchor=tk.CENTER)
        self.grades_tree.column("course", width=200, anchor=tk.W)
        self.grades_tree.column("interrogation", width=100, anchor=tk.CENTER)
        self.grades_tree.column("exam", width=100, anchor=tk.CENTER)
        self.grades_tree.column("final", width=100, anchor=tk.CENTER)
        self.grades_tree.column("status", width=100, anchor=tk.CENTER)
        
        # En-têtes des colonnes
        self.grades_tree.heading("student", text="Étudiant")
        self.grades_tree.heading("promotion", text="Promotion")
        self.grades_tree.heading("course", text="Cours")
        self.grades_tree.heading("interrogation", text="Interrogation (/10)")
        self.grades_tree.heading("exam", text="Examen (/10)")
        self.grades_tree.heading("final", text="Note Finale (/20)")
        self.grades_tree.heading("status", text="Statut")
        
        # Configuration des barres de défilement
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.grades_tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.grades_tree.xview)
        self.grades_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Placement du tableau et des barres de défilement
        self.grades_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Boutons d'action
        action_frame = tk.Frame(grades_frame, bg=self.colors["light_bg"])
        action_frame.pack(fill=tk.X, pady=10)
        
        # Bouton Ajouter
        add_button = tk.Button(action_frame,
                              text="Ajouter une cote",
                              font=("Segoe UI", 10),
                              bg=self.colors["secondary"],
                              fg=self.colors["text_light"],
                              padx=15, pady=5,
                              relief=tk.FLAT,
                              command=self.show_add_grade_dialog)
        add_button.pack(side=tk.LEFT, padx=5)
        
        # Bouton Modifier
        edit_button = tk.Button(action_frame,
                               text="Modifier",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=self.show_edit_grade_dialog)
        edit_button.pack(side=tk.LEFT, padx=5)
        
        # Bouton Supprimer
        delete_button = tk.Button(action_frame,
                                 text="Supprimer",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["accent"],
                                 fg=self.colors["text_light"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=self.delete_grade)
        delete_button.pack(side=tk.LEFT, padx=5)
        
        # Charger les données initiales
        self.load_grades()
    
    def setup_courses_tab(self):
        """Configure l'onglet de gestion des cours."""
        courses_frame = tk.Frame(self.courses_tab, bg=self.colors["light_bg"])
        courses_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # En-tête et filtres
        header_frame = tk.Frame(courses_frame, bg=self.colors["light_bg"])
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Titre
        title_label = tk.Label(header_frame,
                              text="Gestion des cours",
                              font=("Segoe UI", 16, "bold"),
                              fg=self.colors["text_dark"],
                              bg=self.colors["light_bg"])
        title_label.pack(side=tk.LEFT)
        
        # Formulaire d'ajout de cours
        form_frame = tk.Frame(courses_frame, bg=self.colors["light_bg"])
        form_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Nom du cours
        name_frame = tk.Frame(form_frame, bg=self.colors["light_bg"])
        name_frame.pack(side=tk.LEFT, padx=10)
        
        name_label = tk.Label(name_frame,
                             text="Nom du cours:",
                             font=("Segoe UI", 10),
                             bg=self.colors["light_bg"])
        name_label.pack(anchor=tk.W)
        
        self.course_name_entry = tk.Entry(name_frame, width=30, font=("Segoe UI", 10))
        self.course_name_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Crédits
        credits_frame = tk.Frame(form_frame, bg=self.colors["light_bg"])
        credits_frame.pack(side=tk.LEFT, padx=10)
        
        credits_label = tk.Label(credits_frame,
                                text="Crédits:",
                                font=("Segoe UI", 10),
                                bg=self.colors["light_bg"])
        credits_label.pack(anchor=tk.W)
        
        self.course_credits_entry = tk.Entry(credits_frame, width=5, font=("Segoe UI", 10))
        self.course_credits_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg=self.colors["light_bg"])
        promotion_frame.pack(side=tk.LEFT, padx=10)
        
        promotion_label = tk.Label(promotion_frame,
                                  text="Promotion:",
                                  font=("Segoe UI", 10),
                                  bg=self.colors["light_bg"])
        promotion_label.pack(anchor=tk.W)
        
        self.course_promotion_var = tk.StringVar()
        promotion_options = ["L1", "L2", "L3", "M1", "M2"]
        promotion_combobox = ttk.Combobox(promotion_frame,
                                        textvariable=self.course_promotion_var,
                                        values=promotion_options,
                                        width=5,
                                        state="readonly")
        promotion_combobox.pack(anchor=tk.W, pady=(5, 0))
        promotion_combobox.current(0)
        
        # Bouton Ajouter
        add_button = tk.Button(form_frame,
                              text="Ajouter",
                              font=("Segoe UI", 10),
                              bg=self.colors["secondary"],
                              fg=self.colors["text_light"],
                              padx=15, pady=5,
                              relief=tk.FLAT,
                              command=self.add_course)
        add_button.pack(side=tk.LEFT, padx=20, pady=(20, 0))
        
        # Tableau des cours
        table_frame = tk.Frame(courses_frame, bg=self.colors["light_bg"])
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Colonnes du tableau: ID, Nom du cours, Crédits, Promotion
        self.courses_tree = ttk.Treeview(table_frame, columns=("id", "name", "credits", "promotion"))
        
        # Configuration des colonnes
        self.courses_tree.column("#0", width=0, stretch=tk.NO)  # Colonne invisible
        self.courses_tree.column("id", width=50, anchor=tk.CENTER)
        self.courses_tree.column("name", width=300, anchor=tk.W)
        self.courses_tree.column("credits", width=100, anchor=tk.CENTER)
        self.courses_tree.column("promotion", width=100, anchor=tk.CENTER)
        
        # En-têtes des colonnes
        self.courses_tree.heading("id", text="ID")
        self.courses_tree.heading("name", text="Nom du cours")
        self.courses_tree.heading("credits", text="Crédits")
        self.courses_tree.heading("promotion", text="Promotion")
        
        # Configuration des barres de défilement
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.courses_tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.courses_tree.xview)
        self.courses_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Placement du tableau et des barres de défilement
        self.courses_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Boutons d'action
        action_frame = tk.Frame(courses_frame, bg=self.colors["light_bg"])
        action_frame.pack(fill=tk.X, pady=10)
        
        # Bouton Modifier
        edit_button = tk.Button(action_frame,
                               text="Modifier",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=self.show_edit_course_dialog)
        edit_button.pack(side=tk.LEFT, padx=5)
        
        # Bouton Supprimer
        delete_button = tk.Button(action_frame,
                                 text="Supprimer",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["accent"],
                                 fg=self.colors["text_light"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=self.delete_course)
        delete_button.pack(side=tk.LEFT, padx=5)
        
        # Charger les données initiales
        self.load_courses()

    def setup_students_tab(self):
        """Configure l'onglet de gestion des étudiants."""
        students_frame = tk.Frame(self.students_tab, bg=self.colors["light_bg"])
        students_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # En-tête
        header_frame = tk.Frame(students_frame, bg=self.colors["light_bg"])
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Titre
        title_label = tk.Label(header_frame,
                              text="Gestion des étudiants",
                              font=("Segoe UI", 16, "bold"),
                              fg=self.colors["text_dark"],
                              bg=self.colors["light_bg"])
        title_label.pack(side=tk.LEFT)
        
        # Formulaire d'ajout d'étudiant
        form_frame = tk.Frame(students_frame, bg=self.colors["light_bg"])
        form_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Nom de l'étudiant
        name_frame = tk.Frame(form_frame, bg=self.colors["light_bg"])
        name_frame.pack(side=tk.LEFT, padx=10)
        
        name_label = tk.Label(name_frame,
                             text="Nom de l'étudiant:",
                             font=("Segoe UI", 10),
                             bg=self.colors["light_bg"])
        name_label.pack(anchor=tk.W)
        
        self.student_name_entry = tk.Entry(name_frame, width=30, font=("Segoe UI", 10))
        self.student_name_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg=self.colors["light_bg"])
        promotion_frame.pack(side=tk.LEFT, padx=10)
        
        promotion_label = tk.Label(promotion_frame,
                                  text="Promotion:",
                                  font=("Segoe UI", 10),
                                  bg=self.colors["light_bg"])
        promotion_label.pack(anchor=tk.W)
        
        self.student_promotion_var = tk.StringVar()
        promotion_options = ["L1", "L2", "L3", "M1", "M2"]
        promotion_combobox = ttk.Combobox(promotion_frame,
                                        textvariable=self.student_promotion_var,
                                        values=promotion_options,
                                        width=5,
                                        state="readonly")
        promotion_combobox.pack(anchor=tk.W, pady=(5, 0))
        promotion_combobox.current(0)
        
        # Bouton Ajouter
        add_button = tk.Button(form_frame,
                              text="Ajouter",
                              font=("Segoe UI", 10),
                              bg=self.colors["secondary"],
                              fg=self.colors["text_light"],
                              padx=15, pady=5,
                              relief=tk.FLAT,
                              command=self.add_student)
        add_button.pack(side=tk.LEFT, padx=20, pady=(20, 0))
        
        # Tableau des étudiants
        table_frame = tk.Frame(students_frame, bg=self.colors["light_bg"])
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Colonnes du tableau: ID, Nom, Promotion
        self.students_tree = ttk.Treeview(table_frame, columns=("id", "name", "promotion"))
        
        # Configuration des colonnes
        self.students_tree.column("#0", width=0, stretch=tk.NO)  # Colonne invisible
        self.students_tree.column("id", width=80, anchor=tk.CENTER)
        self.students_tree.column("name", width=300, anchor=tk.W)
        self.students_tree.column("promotion", width=100, anchor=tk.CENTER)
        
        # En-têtes des colonnes
        self.students_tree.heading("id", text="ID")
        self.students_tree.heading("name", text="Nom de l'étudiant")
        self.students_tree.heading("promotion", text="Promotion")
        
        # Configuration des barres de défilement
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.students_tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.students_tree.xview)
        self.students_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Placement du tableau et des barres de défilement
        self.students_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Boutons d'action
        action_frame = tk.Frame(students_frame, bg=self.colors["light_bg"])
        action_frame.pack(fill=tk.X, pady=10)
        
        # Bouton Modifier
        edit_button = tk.Button(action_frame,
                               text="Modifier",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=self.show_edit_student_dialog)
        edit_button.pack(side=tk.LEFT, padx=5)
        
        # Bouton Supprimer
        delete_button = tk.Button(action_frame,
                                 text="Supprimer",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["accent"],
                                 fg=self.colors["text_light"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=self.delete_student)
        delete_button.pack(side=tk.LEFT, padx=5)
        
        # Charger les données initiales
        self.load_students()
    
    def setup_settings_tab(self):
        """Configure l'onglet des paramètres du compte."""
        settings_frame = tk.Frame(self.settings_tab, bg=self.colors["light_bg"])
        settings_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Titre
        title_label = tk.Label(settings_frame,
                              text="Paramètres du compte",
                              font=("Segoe UI", 16, "bold"),
                              fg=self.colors["text_dark"],
                              bg=self.colors["light_bg"])
        title_label.pack(anchor=tk.W, pady=(0, 20))
        
        # Formulaire de paramètres
        form_frame = tk.Frame(settings_frame, bg="white", padx=20, pady=20)
        form_frame.pack(fill=tk.X)
        
        # Nom d'utilisateur (affichage seulement)
        username_frame = tk.Frame(form_frame, bg="white")
        username_frame.pack(fill=tk.X, pady=10)
        
        username_label = tk.Label(username_frame,
                                 text="Nom d'utilisateur:",
                                 font=("Segoe UI", 10, "bold"),
                                 anchor=tk.W,
                                 bg="white")
        username_label.pack(anchor=tk.W)
        
        current_username = tk.Label(username_frame,
                                   text=self.current_user,
                                   font=("Segoe UI", 10),
                                   anchor=tk.W,
                                   bg="white")
        current_username.pack(anchor=tk.W, pady=(5, 0))
        
        # Changer le mot de passe
        password_frame = tk.Frame(form_frame, bg="white")
        password_frame.pack(fill=tk.X, pady=10)
        
        password_title = tk.Label(password_frame,
                                 text="Changer le mot de passe",
                                 font=("Segoe UI", 12, "bold"),
                                 anchor=tk.W,
                                 bg="white")
        password_title.pack(anchor=tk.W, pady=(10, 5))
        
        # Mot de passe actuel
        current_pw_frame = tk.Frame(password_frame, bg="white")
        current_pw_frame.pack(fill=tk.X, pady=5)
        
        current_pw_label = tk.Label(current_pw_frame,
                                   text="Mot de passe actuel:",
                                   font=("Segoe UI", 10),
                                   anchor=tk.W,
                                   bg="white")
        current_pw_label.pack(anchor=tk.W)
        
        self.current_pw_entry = tk.Entry(current_pw_frame,
                                       font=("Segoe UI", 10),
                                       show="•",
                                       width=30)
        self.current_pw_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Nouveau mot de passe
        new_pw_frame = tk.Frame(password_frame, bg="white")
        new_pw_frame.pack(fill=tk.X, pady=5)
        
        new_pw_label = tk.Label(new_pw_frame,
                               text="Nouveau mot de passe:",
                               font=("Segoe UI", 10),
                               anchor=tk.W,
                               bg="white")
        new_pw_label.pack(anchor=tk.W)
        
        self.new_pw_entry = tk.Entry(new_pw_frame,
                                   font=("Segoe UI", 10),
                                   show="•",
                                   width=30)
        self.new_pw_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Confirmer le nouveau mot de passe
        confirm_pw_frame = tk.Frame(password_frame, bg="white")
        confirm_pw_frame.pack(fill=tk.X, pady=5)
        
        confirm_pw_label = tk.Label(confirm_pw_frame,
                                   text="Confirmer le nouveau mot de passe:",
                                   font=("Segoe UI", 10),
                                   anchor=tk.W,
                                   bg="white")
        confirm_pw_label.pack(anchor=tk.W)
        
        self.confirm_pw_entry = tk.Entry(confirm_pw_frame,
                                       font=("Segoe UI", 10),
                                       show="•",
                                       width=30)
        self.confirm_pw_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Bouton de modification
        change_pw_button = tk.Button(password_frame,
                                    text="Changer le mot de passe",
                                    font=("Segoe UI", 10),
                                    bg=self.colors["primary"],
                                    fg=self.colors["text_light"],
                                    padx=15, pady=5,
                                    relief=tk.FLAT,
                                    command=self.change_password)
        change_pw_button.pack(anchor=tk.W, pady=15)
        
        # Section informations
        info_frame = tk.Frame(settings_frame, bg=self.colors["light_bg"])
        info_frame.pack(fill=tk.X, pady=20)
        
        info_title = tk.Label(info_frame,
                             text="Informations",
                             font=("Segoe UI", 12, "bold"),
                             anchor=tk.W,
                             bg=self.colors["light_bg"])
        info_title.pack(anchor=tk.W)
        
        info_text = tk.Label(info_frame,
                            text="Cette application a été créée pour la gestion des cotes universitaires.\n"
                                 "Version 1.0 - UniGrade © 2025",
                            font=("Segoe UI", 10),
                            anchor=tk.W,
                            bg=self.colors["light_bg"])
        info_text.pack(anchor=tk.W, pady=5)
    
    def load_grades(self):
        """Charge les cotes depuis le fichier CSV et remplit le tableau."""
        # Effacer les données existantes
        for item in self.grades_tree.get_children():
            self.grades_tree.delete(item)
        
        try:
            # Charger les cours pour avoir les noms
            courses = {}
            with open('cours.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    courses[row['course_id']] = row['course_name']
            
            # Charger les étudiants
            students = {}
            with open('etudiants.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    students[row['id']] = {'name': row['name'], 'promotion': row['promotion']}
            
            # Préparer les données pour calculer les moyennes par étudiant
            student_grades = {}
            
            # Charger les cotes
            with open('cotes.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    try:
                        student_id = row['student_id']
                        course_id = row['course_id']
                        
                        # Utiliser les informations de l'étudiant si disponibles, sinon utiliser celles de la cote
                        if student_id in students:
                            student_name = students[student_id]['name']
                            promotion = students[student_id]['promotion']
                        else:
                            student_name = row['name']
                            promotion = row['promotion']
                        
                        # Obtenir le nom du cours
                        course_name = courses.get(course_id, f"Cours {course_id}")
                        
                        # Calculer la note finale
                        try:
                            interrogation = float(row['interrogation_score'])
                            exam = float(row['exam_score'])
                        except (ValueError, KeyError):
                            # Si les notes ne sont pas disponibles, utiliser 0
                            interrogation = 0
                            exam = 0
                            
                        final = interrogation + exam
                        
                        # Déterminer le statut
                        status = "Admis" if final >= 10 else "Ajourné"
                        
                        # Ajouter à l'arbre
                        self.grades_tree.insert("", tk.END, values=(
                            student_name,
                            promotion,
                            course_name,
                            f"{interrogation:.1f}",
                            f"{exam:.1f}",
                            f"{final:.1f}",
                            status
                        ))
                        
                        # Stocker pour calculer les moyennes
                        if student_id not in student_grades:
                            student_grades[student_id] = {
                                'name': student_name,
                                'promotion': promotion,
                                'total_points': 0,
                                'courses': 0
                            }
                        
                        student_grades[student_id]['total_points'] += final
                        student_grades[student_id]['courses'] += 1
                        
                    except Exception as e:
                        print(f"Erreur lors du chargement d'une cote: {e}")
            
            # Ajouter les étudiants sans notes
            for student_id, student_info in students.items():
                if student_id not in student_grades:
                    # L'étudiant n'a pas de notes, ajouter avec des zéros
                    self.grades_tree.insert("", tk.END, values=(
                        student_info['name'],
                        student_info['promotion'],
                        "Aucun cours",
                        "0.0",
                        "0.0",
                        "0.0",
                        "Ajourné"
                    ))
            
            # Calculer et afficher les moyennes
            for student_id, data in student_grades.items():
                if data['courses'] > 0:
                    avg = data['total_points'] / data['courses']
                    status = "Admis" if avg >= 10 else "Ajourné"
                    
                    # Ajouter la moyenne à l'arbre
                    self.grades_tree.insert("", tk.END, values=(
                        data['name'],
                        data['promotion'],
                        "MOYENNE GÉNÉRALE",
                        "",
                        "",
                        f"{avg:.1f}",
                        status
                    ))
                
        except FileNotFoundError:
            messagebox.showwarning("Attention", "Fichier de cotes non trouvé. Un nouveau fichier sera créé.")
    
    def load_courses(self):
        """Charge les cours depuis le fichier CSV et remplit le tableau."""
        # Effacer les données existantes
        for item in self.courses_tree.get_children():
            self.courses_tree.delete(item)
        
        try:
            with open('cours.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    self.courses_tree.insert("", tk.END, values=(
                        row['course_id'],
                        row['course_name'],
                        row['credits'],
                        row['promotion']
                    ))
        except FileNotFoundError:
            messagebox.showwarning("Attention", "Fichier de cours non trouvé. Un nouveau fichier sera créé.")
    
    def load_students(self):
        """Charge les étudiants depuis le fichier CSV et remplit le tableau."""
        # Effacer les données existantes
        for item in self.students_tree.get_children():
            self.students_tree.delete(item)
        
        try:
            with open('etudiants.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    self.students_tree.insert("", tk.END, values=(
                        row['id'],
                        row['name'],
                        row['promotion']
                    ))
        except FileNotFoundError:
            messagebox.showwarning("Attention", "Fichier des étudiants non trouvé. Un nouveau fichier sera créé.")
    
    def search_grades(self, event=None):
        """Filtre les cotes en fonction du texte de recherche."""
        search_text = self.search_entry.get().lower()
        
        # Réinitialiser l'affichage
        self.load_grades()
        
        # Si aucun texte de recherche, ne rien faire d'autre
        if not search_text:
            return
        
        # Parcourir toutes les lignes et cacher celles qui ne correspondent pas
        for item in self.grades_tree.get_children():
            values = self.grades_tree.item(item)['values']
            # Chercher dans le nom de l'étudiant ou le nom du cours
            if not (search_text in str(values[0]).lower() or search_text in str(values[2]).lower()):
                self.grades_tree.detach(item)
    
    def filter_grades(self, event=None):
        """Filtre les cotes par promotion."""
        selected_promotion = self.filter_var.get()
        
        # Réinitialiser l'affichage
        self.load_grades()
        
        # Si "Tous" est sélectionné, ne rien faire d'autre
        if selected_promotion == "Tous":
            return
        
        # Parcourir toutes les lignes et cacher celles qui ne correspondent pas
        for item in self.grades_tree.get_children():
            values = self.grades_tree.item(item)['values']
            if values[1] != selected_promotion:
                self.grades_tree.detach(item)
    
    def show_add_grade_dialog(self):
        """Affiche une boîte de dialogue pour ajouter une cote."""
        # Créer une fenêtre de dialogue
        dialog = tk.Toplevel(self.root)
        dialog.title("Ajouter une cote")
        dialog.geometry("500x400")
        dialog.resizable(False, False)
        dialog.grab_set()  # Rendre la fenêtre modale
        
        # Styliser la fenêtre
        dialog.configure(bg="white")
        
        # Titre
        title_label = tk.Label(dialog,
                              text="Ajouter une nouvelle cote",
                              font=("Segoe UI", 14, "bold"),
                              fg=self.colors["primary"],
                              bg="white")
        title_label.pack(pady=(20, 30))
        
        # Formulaire
        form_frame = tk.Frame(dialog, bg="white")
        form_frame.pack(fill=tk.X, padx=30)
        
        # Étudiant
        student_frame = tk.Frame(form_frame, bg="white")
        student_frame.pack(fill=tk.X, pady=5)
        
        student_label = tk.Label(student_frame,
                                text="Étudiant:",
                                font=("Segoe UI", 10),
                                anchor=tk.W,
                                bg="white")
        student_label.pack(anchor=tk.W)
        
        # Obtenir la liste des étudiants depuis le fichier etudiants.csv
        students = []
        try:
            with open('etudiants.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    students.append((row['id'], row['name'], row['promotion']))
        except FileNotFoundError:
            # Vérifier aussi les utilisateurs avec rôle 'student'
            with open('utilisateurs.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    if row['role'] == 'student':
                        # Générer un ID pour l'étudiant s'il n'en a pas
                        student_id = f"S{random.randint(1000, 9999)}"
                        students.append((student_id, row['username'], row['promotion']))
        
        # Variable pour stocker l'étudiant sélectionné
        self.selected_student_var = tk.StringVar()
        student_options = [f"{student[1]} ({student[2]})" for student in students]
        
        if student_options:
            student_combobox = ttk.Combobox(student_frame,
                                          textvariable=self.selected_student_var,
                                          values=student_options,
                                          font=("Segoe UI", 10),
                                          width=30,
                                          state="readonly")
            student_combobox.pack(anchor=tk.W, pady=(5, 0))
            student_combobox.current(0)
        else:
            tk.Label(student_frame,
                   text="Aucun étudiant disponible. Veuillez d'abord ajouter des étudiants.",
                   font=("Segoe UI", 10),
                   fg="red",
                   bg="white").pack(anchor=tk.W, pady=(5, 0))
            return
        
        # Cours
        course_frame = tk.Frame(form_frame, bg="white")
        course_frame.pack(fill=tk.X, pady=5)
        
        course_label = tk.Label(course_frame,
                               text="Cours:",
                               font=("Segoe UI", 10),
                               anchor=tk.W,
                               bg="white")
        course_label.pack(anchor=tk.W)
        
        # Obtenir la liste des cours
        courses = []
        try:
            with open('cours.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    courses.append((row['course_id'], row['course_name'], row['promotion']))
        except FileNotFoundError:
            tk.Label(course_frame,
                   text="Aucun cours disponible. Veuillez d'abord ajouter des cours.",
                   font=("Segoe UI", 10),
                   fg="red",
                   bg="white").pack(anchor=tk.W, pady=(5, 0))
            return
        
        # Variable pour stocker le cours sélectionné
        self.selected_course_var = tk.StringVar()
        course_options = [f"{course[1]} ({course[2]})" for course in courses]
        
        course_combobox = ttk.Combobox(course_frame,
                                     textvariable=self.selected_course_var,
                                     values=course_options,
                                     font=("Segoe UI", 10),
                                     width=30,
                                     state="readonly")
        course_combobox.pack(anchor=tk.W, pady=(5, 0))
        if course_options:
            course_combobox.current(0)
        
        # Note d'interrogation
        interrogation_frame = tk.Frame(form_frame, bg="white")
        interrogation_frame.pack(fill=tk.X, pady=5)
        
        interrogation_label = tk.Label(interrogation_frame,
                                      text="Note d'interrogation (/10):",
                                      font=("Segoe UI", 10),
                                      anchor=tk.W,
                                      bg="white")
        interrogation_label.pack(anchor=tk.W)
        
        vcmd = (dialog.register(self.validate_float), '%P')
        self.interrogation_entry = tk.Entry(interrogation_frame,
                                          font=("Segoe UI", 10),
                                          validate='key',
                                          validatecommand=vcmd,
                                          width=10)
        self.interrogation_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Note d'examen
        exam_frame = tk.Frame(form_frame, bg="white")
        exam_frame.pack(fill=tk.X, pady=5)
        
        exam_label = tk.Label(exam_frame,
                             text="Note d'examen (/10):",
                             font=("Segoe UI", 10),
                             anchor=tk.W,
                             bg="white")
        exam_label.pack(anchor=tk.W)
        
        self.exam_entry = tk.Entry(exam_frame,
                                 font=("Segoe UI", 10),
                                 validate='key',
                                 validatecommand=vcmd,
                                 width=10)
        self.exam_entry.pack(anchor=tk.W, pady=(5, 0))
        
        # Boutons
        button_frame = tk.Frame(dialog, bg="white")
        button_frame.pack(fill=tk.X, pady=30)
        
        cancel_button = tk.Button(button_frame,
                                 text="Annuler",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["light_gray"],
                                 fg=self.colors["text_dark"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=10)
        
        save_button = tk.Button(button_frame,
                               text="Enregistrer",
                               font=("Segoe UI", 10),
                               bg=self.colors["secondary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=lambda: self.add_grade(dialog, students, courses))
        save_button.pack(side=tk.RIGHT, padx=10)
    
    def add_grade(self, dialog, students, courses):
        """Ajoute une cote à partir des données du formulaire."""
        try:
            # Récupérer l'étudiant sélectionné
            selected_student_str = self.selected_student_var.get()
            selected_student_name = selected_student_str.split(" (")[0]
            selected_promotion = selected_student_str.split("(")[1].split(")")[0]
            
            # Récupérer le cours sélectionné
            selected_course_str = self.selected_course_var.get()
            course_name = selected_course_str.split(" (")[0]
            
            # Trouver l'ID du cours
            course_id = None
            for course in courses:
                if course[1] == course_name:
                    course_id = course[0]
                    break
            
            if not course_id:
                messagebox.showerror("Erreur", "Cours non trouvé.")
                return
            
            # Trouver l'ID de l'étudiant
            student_id = None
            for student in students:
                if student[1] == selected_student_name:
                    student_id = student[0]
                    break
            
            if not student_id:
                messagebox.showerror("Erreur", "Étudiant non trouvé.")
                return
            
            # Récupérer les notes
            interrogation = float(self.interrogation_entry.get() or "0")
            exam = float(self.exam_entry.get() or "0")
            
            # Valider les notes (entre 0 et 10)
            if not (0 <= interrogation <= 10 and 0 <= exam <= 10):
                messagebox.showerror("Erreur", "Les notes doivent être comprises entre 0 et 10.")
                return
            
            # Ajouter la cote au fichier CSV
            with open('cotes.csv', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([student_id, selected_student_name, selected_promotion, course_id, interrogation, exam])
            
            # Fermer la boîte de dialogue et actualiser l'affichage
            dialog.destroy()
            self.load_grades()
            messagebox.showinfo("Succès", "Cote ajoutée avec succès.")
            
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez remplir correctement tous les champs.")
    
    def show_edit_grade_dialog(self):
        """Affiche une boîte de dialogue pour modifier une cote."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.grades_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner une cote à modifier.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.grades_tree.item(selected_item[0])['values']
        
        # Vérifier que ce n'est pas une ligne de moyenne
        if selected_values[2] == "MOYENNE GÉNÉRALE":
            messagebox.showinfo("Information", "Impossible de modifier une ligne de moyenne.")
            return
        
        # Créer une fenêtre de dialogue
        dialog = tk.Toplevel(self.root)
        dialog.title("Modifier une cote")
        dialog.geometry("500x350")
        dialog.resizable(False, False)
        dialog.grab_set()  # Rendre la fenêtre modale
        
        # Styliser la fenêtre
        dialog.configure(bg="white")
        
        # Titre
        title_label = tk.Label(dialog,
                              text="Modifier la cote",
                              font=("Segoe UI", 14, "bold"),
                              fg=self.colors["primary"],
                              bg="white")
        title_label.pack(pady=(20, 30))
        
        # Formulaire
        form_frame = tk.Frame(dialog, bg="white")
        form_frame.pack(fill=tk.X, padx=30)
        
        # Informations de l'étudiant et du cours (non modifiables)
        info_frame = tk.Frame(form_frame, bg="white")
        info_frame.pack(fill=tk.X, pady=5)
        
        info_label = tk.Label(info_frame,
                             text=f"Étudiant: {selected_values[0]} ({selected_values[1]})\nCours: {selected_values[2]}",
                             font=("Segoe UI", 10),
                             anchor=tk.W,
                             justify=tk.LEFT,
                             bg="white")
        info_label.pack(anchor=tk.W, pady=(0, 15))
        
        # Note d'interrogation
        interrogation_frame = tk.Frame(form_frame, bg="white")
        interrogation_frame.pack(fill=tk.X, pady=5)
        
        interrogation_label = tk.Label(interrogation_frame,
                                      text="Note d'interrogation (/10):",
                                      font=("Segoe UI", 10),
                                      anchor=tk.W,
                                      bg="white")
        interrogation_label.pack(anchor=tk.W)
        
        vcmd = (dialog.register(self.validate_float), '%P')
        self.edit_interrogation_entry = tk.Entry(interrogation_frame,
                                               font=("Segoe UI", 10),
                                               validate='key',
                                               validatecommand=vcmd,
                                               width=10)
        self.edit_interrogation_entry.pack(anchor=tk.W, pady=(5, 0))
        self.edit_interrogation_entry.insert(0, selected_values[3])
        
        # Note d'examen
        exam_frame = tk.Frame(form_frame, bg="white")
        exam_frame.pack(fill=tk.X, pady=5)
        
        exam_label = tk.Label(exam_frame,
                             text="Note d'examen (/10):",
                             font=("Segoe UI", 10),
                             anchor=tk.W,
                             bg="white")
        exam_label.pack(anchor=tk.W)
        
        self.edit_exam_entry = tk.Entry(exam_frame,
                                      font=("Segoe UI", 10),
                                      validate='key',
                                      validatecommand=vcmd,
                                      width=10)
        self.edit_exam_entry.pack(anchor=tk.W, pady=(5, 0))
        self.edit_exam_entry.insert(0, selected_values[4])
        
        # Boutons
        button_frame = tk.Frame(dialog, bg="white")
        button_frame.pack(fill=tk.X, pady=30)
        
        cancel_button = tk.Button(button_frame,
                                 text="Annuler",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["light_gray"],
                                 fg=self.colors["text_dark"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=10)
        
        save_button = tk.Button(button_frame,
                               text="Enregistrer",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=lambda: self.update_grade(dialog, selected_values))
        save_button.pack(side=tk.RIGHT, padx=10)
    
    def update_grade(self, dialog, selected_values):
        """Met à jour une cote dans le fichier CSV."""
        try:
            # Récupérer les nouvelles notes
            new_interrogation = float(self.edit_interrogation_entry.get() or "0")
            new_exam = float(self.edit_exam_entry.get() or "0")
            
            # Valider les notes (entre 0 et 10)
            if not (0 <= new_interrogation <= 10 and 0 <= new_exam <= 10):
                messagebox.showerror("Erreur", "Les notes doivent être comprises entre 0 et 10.")
                return
            
            # Récupérer les données actuelles
            student_name = selected_values[0]
            course_name = selected_values[2]
            
            # Trouver l'ID du cours
            course_id = None
            with open('cours.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    if row['course_name'] == course_name:
                        course_id = row['course_id']
                        break
            
            if not course_id:
                messagebox.showerror("Erreur", "Cours non trouvé.")
                return
            
            # Mettre à jour le fichier CSV
            rows = []
            updated = False
            
            with open('cotes.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['name'] == student_name and row['course_id'] == course_id:
                        row['interrogation_score'] = str(new_interrogation)
                        row['exam_score'] = str(new_exam)
                        updated = True
                    rows.append(row)
            
            if updated:
                with open('cotes.csv', 'w', newline='') as file:
                    writer = csv.DictWriter(file, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(rows)
                
                # Fermer la boîte de dialogue et actualiser l'affichage
                dialog.destroy()
                self.load_grades()
                messagebox.showinfo("Succès", "Cote mise à jour avec succès.")
            else:
                messagebox.showerror("Erreur", "Impossible de trouver la cote à mettre à jour.")
                
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez remplir correctement tous les champs.")
    
    def delete_grade(self):
        """Supprime une cote sélectionnée."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.grades_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner une cote à supprimer.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.grades_tree.item(selected_item[0])['values']
        
        # Vérifier que ce n'est pas une ligne de moyenne
        if selected_values[2] == "MOYENNE GÉNÉRALE":
            messagebox.showinfo("Information", "Impossible de supprimer une ligne de moyenne.")
            return
        
        # Demander confirmation
        if not messagebox.askyesno("Confirmation", "Êtes-vous sûr de vouloir supprimer cette cote?"):
            return
        
        # Récupérer les données
        student_name = selected_values[0]
        course_name = selected_values[2]
        
        # Trouver l'ID du cours
        course_id = None
        with open('cours.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['course_name'] == course_name:
                    course_id = row['course_id']
                    break
        
        if not course_id:
            messagebox.showerror("Erreur", "Cours non trouvé.")
            return
        
        # Supprimer la cote du fichier CSV
        rows = []
        removed = False
        
        with open('cotes.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            fieldnames = reader.fieldnames
            for row in reader:
                if row['name'] == student_name and row['course_id'] == course_id:
                    removed = True
                    continue
                rows.append(row)
        
        if removed:
            with open('cotes.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
            
            # Actualiser l'affichage
            self.load_grades()
            messagebox.showinfo("Succès", "Cote supprimée avec succès.")
        else:
            messagebox.showerror("Erreur", "Impossible de trouver la cote à supprimer.")
    
    def add_course(self):
        """Ajoute un nouveau cours."""
        # Récupérer les valeurs du formulaire
        course_name = self.course_name_entry.get().strip()
        credits_text = self.course_credits_entry.get().strip()
        promotion = self.course_promotion_var.get()
        
        # Valider les entrées
        if not course_name:
            messagebox.showerror("Erreur", "Veuillez entrer un nom de cours.")
            return
        
        if not credits_text:
            messagebox.showerror("Erreur", "Veuillez entrer un nombre de crédits.")
            return
        
        try:
            credits = int(credits_text)
            if credits <= 0:
                raise ValueError("Les crédits doivent être positifs")
        except ValueError:
            messagebox.showerror("Erreur", "Le nombre de crédits doit être un entier positif.")
            return
        
        if not promotion:
            messagebox.showerror("Erreur", "Veuillez sélectionner une promotion.")
            return
        
        # Générer un ID unique pour le cours
        course_id = f"C{random.randint(1000, 9999)}"
        
        # Vérifier que le cours n'existe pas déjà
        with open('cours.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['course_name'] == course_name and row['promotion'] == promotion:
                    messagebox.showerror("Erreur", "Ce cours existe déjà pour cette promotion.")
                    return
        
        # Ajouter le cours au fichier CSV
        with open('cours.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([course_id, course_name, credits, promotion])
        
        # Réinitialiser les champs du formulaire
        self.course_name_entry.delete(0, tk.END)
        self.course_credits_entry.delete(0, tk.END)
        
        # Actualiser l'affichage
        self.load_courses()
        messagebox.showinfo("Succès", "Cours ajouté avec succès.")

    def add_student(self):
        """Ajoute un nouvel étudiant."""
        # Récupérer les valeurs du formulaire
        student_name = self.student_name_entry.get().strip()
        promotion = self.student_promotion_var.get()
        
        # Valider les entrées
        if not student_name:
            messagebox.showerror("Erreur", "Veuillez entrer un nom d'étudiant.")
            return
        
        if not promotion:
            messagebox.showerror("Erreur", "Veuillez sélectionner une promotion.")
            return
        
        # Générer un ID unique pour l'étudiant
        student_id = f"S{random.randint(1000, 9999)}"
        
        # Vérifier que l'étudiant n'existe pas déjà
        with open('etudiants.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['name'] == student_name:
                    messagebox.showerror("Erreur", "Cet étudiant existe déjà.")
                    return
        
        # Ajouter l'étudiant au fichier CSV
        with open('etudiants.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([student_id, student_name, promotion])
        
        # Réinitialiser les champs du formulaire
        self.student_name_entry.delete(0, tk.END)
        
        # Actualiser l'affichage
        self.load_students()
        messagebox.showinfo("Succès", "Étudiant ajouté avec succès.")
    
    def show_edit_course_dialog(self):
        """Affiche une boîte de dialogue pour modifier un cours."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.courses_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner un cours à modifier.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.courses_tree.item(selected_item[0])['values']
        
        # Créer une fenêtre de dialogue
        dialog = tk.Toplevel(self.root)
        dialog.title("Modifier un cours")
        dialog.geometry("450x350")
        dialog.resizable(False, False)
        dialog.grab_set()  # Rendre la fenêtre modale
        
        # Styliser la fenêtre
        dialog.configure(bg="white")
        
        # Titre
        title_label = tk.Label(dialog,
                              text="Modifier le cours",
                              font=("Segoe UI", 14, "bold"),
                              fg=self.colors["primary"],
                              bg="white")
        title_label.pack(pady=(20, 30))
        
        # Formulaire
        form_frame = tk.Frame(dialog, bg="white")
        form_frame.pack(fill=tk.X, padx=30)
        
        # ID du cours (non modifiable)
        id_frame = tk.Frame(form_frame, bg="white")
        id_frame.pack(fill=tk.X, pady=5)
        
        id_label = tk.Label(id_frame,
                           text="ID du cours:",
                           font=("Segoe UI", 10),
                           anchor=tk.W,
                           bg="white")
        id_label.pack(anchor=tk.W)
        
        id_value = tk.Label(id_frame,
                           text=selected_values[0],
                           font=("Segoe UI", 10),
                           anchor=tk.W,
                           bg="white")
        id_value.pack(anchor=tk.W, pady=(5, 0))
        
        # Nom du cours
        name_frame = tk.Frame(form_frame, bg="white")
        name_frame.pack(fill=tk.X, pady=5)
        
        name_label = tk.Label(name_frame,
                             text="Nom du cours:",
                             font=("Segoe UI", 10),
                             anchor=tk.W,
                             bg="white")
        name_label.pack(anchor=tk.W)
        
        self.edit_course_name = tk.Entry(name_frame,
                                       font=("Segoe UI", 10),
                                       width=30)
        self.edit_course_name.pack(anchor=tk.W, pady=(5, 0))
        self.edit_course_name.insert(0, selected_values[1])
        
        # Crédits
        credits_frame = tk.Frame(form_frame, bg="white")
        credits_frame.pack(fill=tk.X, pady=5)
        
        credits_label = tk.Label(credits_frame,
                                text="Crédits:",
                                font=("Segoe UI", 10),
                                anchor=tk.W,
                                bg="white")
        credits_label.pack(anchor=tk.W)
        
        vcmd = (dialog.register(self.validate_int), '%P')
        self.edit_course_credits = tk.Entry(credits_frame,
                                          font=("Segoe UI", 10),
                                          validate='key',
                                          validatecommand=vcmd,
                                          width=10)
        self.edit_course_credits.pack(anchor=tk.W, pady=(5, 0))
        self.edit_course_credits.insert(0, selected_values[2])
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg="white")
        promotion_frame.pack(fill=tk.X, pady=5)
        
        promotion_label = tk.Label(promotion_frame,
                                  text="Promotion:",
                                  font=("Segoe UI", 10),
                                  anchor=tk.W,
                                  bg="white")
        promotion_label.pack(anchor=tk.W)
        
        self.edit_course_promotion = tk.StringVar(value=selected_values[3])
        promotion_options = ["L1", "L2", "L3", "M1", "M2"]
        promotion_combobox = ttk.Combobox(promotion_frame,
                                        textvariable=self.edit_course_promotion,
                                        values=promotion_options,
                                        font=("Segoe UI", 10),
                                        width=10,
                                        state="readonly")
        promotion_combobox.pack(anchor=tk.W, pady=(5, 0))
        
        # Boutons
        button_frame = tk.Frame(dialog, bg="white")
        button_frame.pack(fill=tk.X, pady=30)
        
        cancel_button = tk.Button(button_frame,
                                 text="Annuler",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["light_gray"],
                                 fg=self.colors["text_dark"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=10)
        
        save_button = tk.Button(button_frame,
                               text="Enregistrer",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=lambda: self.update_course(dialog, selected_values[0]))
        save_button.pack(side=tk.RIGHT, padx=10)
    
    def show_edit_student_dialog(self):
        """Affiche une boîte de dialogue pour modifier un étudiant."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.students_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner un étudiant à modifier.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.students_tree.item(selected_item[0])['values']
        
        # Créer une fenêtre de dialogue
        dialog = tk.Toplevel(self.root)
        dialog.title("Modifier un étudiant")
        dialog.geometry("450x300")
        dialog.resizable(False, False)
        dialog.grab_set()  # Rendre la fenêtre modale
        
        # Styliser la fenêtre
        dialog.configure(bg="white")
        
        # Titre
        title_label = tk.Label(dialog,
                              text="Modifier l'étudiant",
                              font=("Segoe UI", 14, "bold"),
                              fg=self.colors["primary"],
                              bg="white")
        title_label.pack(pady=(20, 30))
        
        # Formulaire
        form_frame = tk.Frame(dialog, bg="white")
        form_frame.pack(fill=tk.X, padx=30)
        
        # ID de l'étudiant (non modifiable)
        id_frame = tk.Frame(form_frame, bg="white")
        id_frame.pack(fill=tk.X, pady=5)
        
        id_label = tk.Label(id_frame,
                           text="ID de l'étudiant:",
                           font=("Segoe UI", 10),
                           anchor=tk.W,
                           bg="white")
        id_label.pack(anchor=tk.W)
        
        id_value = tk.Label(id_frame,
                           text=selected_values[0],
                           font=("Segoe UI", 10),
                           anchor=tk.W,
                           bg="white")
        id_value.pack(anchor=tk.W, pady=(5, 0))
        
        # Nom de l'étudiant
        name_frame = tk.Frame(form_frame, bg="white")
        name_frame.pack(fill=tk.X, pady=5)
        
        name_label = tk.Label(name_frame,
                             text="Nom de l'étudiant:",
                             font=("Segoe UI", 10),
                             anchor=tk.W,
                             bg="white")
        name_label.pack(anchor=tk.W)
        
        self.edit_student_name = tk.Entry(name_frame,
                                       font=("Segoe UI", 10),
                                       width=30)
        self.edit_student_name.pack(anchor=tk.W, pady=(5, 0))
        self.edit_student_name.insert(0, selected_values[1])
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg="white")
        promotion_frame.pack(fill=tk.X, pady=5)
        
        promotion_label = tk.Label(promotion_frame,
                                  text="Promotion:",
                                  font=("Segoe UI", 10),
                                  anchor=tk.W,
                                  bg="white")
        promotion_label.pack(anchor=tk.W)
        
        self.edit_student_promotion = tk.StringVar(value=selected_values[2])
        promotion_options = ["L1", "L2", "L3", "M1", "M2"]
        promotion_combobox = ttk.Combobox(promotion_frame,
                                        textvariable=self.edit_student_promotion,
                                        values=promotion_options,
                                        font=("Segoe UI", 10),
                                        width=10,
                                        state="readonly")
        promotion_combobox.pack(anchor=tk.W, pady=(5, 0))
        
        # Boutons
        button_frame = tk.Frame(dialog, bg="white")
        button_frame.pack(fill=tk.X, pady=30)
        
        cancel_button = tk.Button(button_frame,
                                 text="Annuler",
                                 font=("Segoe UI", 10),
                                 bg=self.colors["light_gray"],
                                 fg=self.colors["text_dark"],
                                 padx=15, pady=5,
                                 relief=tk.FLAT,
                                 command=dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=10)
        
        save_button = tk.Button(button_frame,
                               text="Enregistrer",
                               font=("Segoe UI", 10),
                               bg=self.colors["primary"],
                               fg=self.colors["text_light"],
                               padx=15, pady=5,
                               relief=tk.FLAT,
                               command=lambda: self.update_student(dialog, selected_values[0]))
        save_button.pack(side=tk.RIGHT, padx=10)
    
    def update_course(self, dialog, course_id):
        """Met à jour un cours dans le fichier CSV."""
        try:
            # Récupérer les nouvelles valeurs
            new_name = self.edit_course_name.get().strip()
            new_credits = int(self.edit_course_credits.get())
            new_promotion = self.edit_course_promotion.get()
            
            # Valider les entrées
            if not new_name:
                messagebox.showerror("Erreur", "Veuillez entrer un nom de cours.")
                return
            
            if new_credits <= 0:
                messagebox.showerror("Erreur", "Le nombre de crédits doit être un entier positif.")
                return
            
            # Mettre à jour le fichier CSV
            rows = []
            
            with open('cours.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['course_id'] == course_id:
                        row['course_name'] = new_name
                        row['credits'] = str(new_credits)
                        row['promotion'] = new_promotion
                    rows.append(row)
            
            with open('cours.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
            
            # Fermer la boîte de dialogue et actualiser l'affichage
            dialog.destroy()
            self.load_courses()
            self.load_grades()  # Recharger aussi les cotes pour refléter les changements
            messagebox.showinfo("Succès", "Cours mis à jour avec succès.")
                
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez remplir correctement tous les champs.")
    
    def update_student(self, dialog, student_id):
        """Met à jour un étudiant dans le fichier CSV."""
        try:
            # Récupérer les nouvelles valeurs
            new_name = self.edit_student_name.get().strip()
            new_promotion = self.edit_student_promotion.get()
            
            # Valider les entrées
            if not new_name:
                messagebox.showerror("Erreur", "Veuillez entrer un nom d'étudiant.")
                return
            
            # Mettre à jour le fichier CSV des étudiants
            rows = []
            
            with open('etudiants.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['id'] == student_id:
                        row['name'] = new_name
                        row['promotion'] = new_promotion
                    rows.append(row)
            
            with open('etudiants.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
            
            # Mettre également à jour le fichier de cotes
            grade_rows = []
            
            with open('cotes.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['student_id'] == student_id:
                        row['name'] = new_name
                        row['promotion'] = new_promotion
                    grade_rows.append(row)
            
            with open('cotes.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(grade_rows)
            
            # Fermer la boîte de dialogue et actualiser l'affichage
            dialog.destroy()
            self.load_students()
            self.load_grades()  # Recharger aussi les cotes pour refléter les changements
            messagebox.showinfo("Succès", "Étudiant mis à jour avec succès.")
                
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez remplir correctement tous les champs.")
    
    def delete_course(self):
        """Supprime un cours sélectionné."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.courses_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner un cours à supprimer.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.courses_tree.item(selected_item[0])['values']
        course_id = selected_values[0]
        
        # Vérifier si le cours est utilisé dans les cotes
        course_in_use = False
        with open('cotes.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['course_id'] == course_id:
                    course_in_use = True
                    break
        
        if course_in_use:
            if not messagebox.askyesno("Attention", "Ce cours est utilisé dans des cotes d'étudiants. Sa suppression entraînera également la suppression de toutes les cotes associées. Continuer?"):
                return
        else:
            # Demander confirmation
            if not messagebox.askyesno("Confirmation", "Êtes-vous sûr de vouloir supprimer ce cours?"):
                return
        
        # Supprimer le cours du fichier CSV
        rows = []
        
        with open('cours.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            fieldnames = reader.fieldnames
            for row in reader:
                if row['course_id'] != course_id:
                    rows.append(row)
        
        with open('cours.csv', 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        
        # Si nécessaire, supprimer les cotes associées
        if course_in_use:
            grade_rows = []
            
            with open('cotes.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['course_id'] != course_id:
                        grade_rows.append(row)
            
            with open('cotes.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(grade_rows)
        
        # Actualiser l'affichage
        self.load_courses()
        if course_in_use:
            self.load_grades()  # Recharger aussi les cotes si des modifications ont été apportées
        
        messagebox.showinfo("Succès", "Cours supprimé avec succès.")
    
    def delete_student(self):
        """Supprime un étudiant sélectionné."""
        # Vérifier si une ligne est sélectionnée
        selected_item = self.students_tree.selection()
        if not selected_item:
            messagebox.showinfo("Information", "Veuillez sélectionner un étudiant à supprimer.")
            return
        
        # Récupérer les valeurs de la ligne sélectionnée
        selected_values = self.students_tree.item(selected_item[0])['values']
        student_id = selected_values[0]
        
        # Vérifier si l'étudiant a des cotes
        student_has_grades = False
        with open('cotes.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['student_id'] == student_id:
                    student_has_grades = True
                    break
        
        if student_has_grades:
            if not messagebox.askyesno("Attention", "Cet étudiant a des cotes enregistrées. Sa suppression entraînera également la suppression de toutes ses cotes. Continuer?"):
                return
        else:
            # Demander confirmation
            if not messagebox.askyesno("Confirmation", "Êtes-vous sûr de vouloir supprimer cet étudiant?"):
                return
        
        # Supprimer l'étudiant du fichier CSV
        rows = []
        
        with open('etudiants.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            fieldnames = reader.fieldnames
            for row in reader:
                if row['id'] != student_id:
                    rows.append(row)
        
        with open('etudiants.csv', 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        
        # Si nécessaire, supprimer les cotes associées
        if student_has_grades:
            grade_rows = []
            
            with open('cotes.csv', 'r', newline='') as file:
                reader = csv.DictReader(file)
                fieldnames = reader.fieldnames
                for row in reader:
                    if row['student_id'] != student_id:
                        grade_rows.append(row)
            
            with open('cotes.csv', 'w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(grade_rows)
        
        # Actualiser l'affichage
        self.load_students()
        if student_has_grades:
            self.load_grades()  # Recharger aussi les cotes si des modifications ont été apportées
        
        messagebox.showinfo("Succès", "Étudiant supprimé avec succès.")
    
    def change_password(self):
        """Change le mot de passe de l'utilisateur actuel."""
        current_password = self.current_pw_entry.get()
        new_password = self.new_pw_entry.get()
        confirm_password = self.confirm_pw_entry.get()
        
        if not current_password or not new_password or not confirm_password:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        if new_password != confirm_password:
            messagebox.showerror("Erreur", "Les nouveaux mots de passe ne correspondent pas.")
            return
        
        # Vérifier le mot de passe actuel
        current_hash = hashlib.sha256(current_password.encode()).hexdigest()
        password_correct = False
        
        with open('utilisateurs.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['username'] == self.current_user and row['password_hash'] == current_hash:
                    password_correct = True
                    break
        
        if not password_correct:
            messagebox.showerror("Erreur", "Mot de passe actuel incorrect.")
            return
        
        # Changer le mot de passe
        new_hash = hashlib.sha256(new_password.encode()).hexdigest()
        rows = []
        
        with open('utilisateurs.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            fieldnames = reader.fieldnames
            for row in reader:
                if row['username'] == self.current_user:
                    row['password_hash'] = new_hash
                rows.append(row)
        
        with open('utilisateurs.csv', 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        
        # Effacer les champs
        self.current_pw_entry.delete(0, tk.END)
        self.new_pw_entry.delete(0, tk.END)
        self.confirm_pw_entry.delete(0, tk.END)
        
        messagebox.showinfo("Succès", "Mot de passe changé avec succès.")
    
    def validate_float(self, value):
        """Valide qu'une valeur peut être convertie en float."""
        if value == "":
            return True
        try:
            float(value)
            return True
        except ValueError:
            return False
    
    def validate_int(self, value):
        """Valide qu'une valeur peut être convertie en int."""
        if value == "":
            return True
        try:
            int(value)
            return True
        except ValueError:
            return False
    
    def logout(self):
        """Déconnecte l'utilisateur et retourne à l'écran d'accueil."""
        self.current_user = None
        self.user_role = None
        self.show_welcome_screen()

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentGradeManager(root)
    root.mainloop()

