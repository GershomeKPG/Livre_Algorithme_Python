from tkinter import*

def color():
    print(var.get())
def italic():
    print("Italic" if var2.get() else "Pas italic")
    
def Menucontex(event):
    #coodonnee relatives
    x = event.x_root 
    y = event.y_root
    men_col.post(x,y)

fen=Tk()
fen.geometry("250x200")
fen.title("Les menus")

boutF=Menubutton(fen,text="Fichier",relief="sunken")
boutC=Menubutton(fen,text="Couleur",relief="solid")

#-------creation du menu fichier-----------#

men_File=Menu(boutF,tearoff=0)
#Ajout des options
men_File.add_command(label="Ouvrir",accelerator="ctrl-o",
                     command=lambda:print("sous Menu ouvrir"))
men_File.add_command(label="Enregistrer",accelerator="ctrl-s",
                     command=lambda:print("sous Menu save"))
#Creation d'un sous menu exporter
opt_File_exp=Menu(men_File,tearoff=0)
opt_File_exp.add_command(label="PDF",command=lambda:print("Exporter PDF"))
opt_File_exp.add_command(label="Word",command=lambda:print("Exporter Word"))
men_File.add_cascade(label="Exporter",menu=opt_File_exp)
#Ajouter un separateur
men_File.add_separator()
men_File.add_command(label="Quitter",command=fen.quit)

#lie le menu au bouton Fichier
boutF["menu"]= men_File



#-------creation du menu Couleur-----------#

var=StringVar(value="Rouge")
var2=BooleanVar(value=True)

men_col=Menu(boutC,tearoff=0)
men_col.add_radiobutton(label="Rouge",foreground="red",variable=var,value="Rouge",
                        command=color)
men_col.add_radiobutton(label="Verte",foreground="green",variable=var,value="Verte",
                        command=color)
men_col.add_radiobutton(label="Bleu",foreground="blue",variable=var,value="Blue",
                        command=color)
men_col.add_radiobutton(label="Jaune",foreground="yellow",variable=var,value="Jaune",
                        command=color)
men_col.add_separator()
men_col.add_command(label="Italic",font="cambria 10 italic",state="disabled")
men_col.add_checkbutton(label="Italic",variable=var2,
                        command=italic)
#lie le menu au bouton Couleur
boutC["menu"]= men_col


boutF.grid(row=0,column=0,padx=2,pady=5)
boutC.grid(row=0,column=1,padx=2,pady=5)

fen.bind("<Button-3>",Menucontex)



fen.mainloop()
