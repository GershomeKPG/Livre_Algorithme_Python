
from tkinter import *

def textDef():
    selec=lisB.curselection()
    if selec:
        itemS=lisB.get(selec[0])
        label.configure(text=itemS)

fen=Tk()
fen.geometry("220x200")
fen.title("Widget Entry")
item=["Celibataire","Marie","Divorse","Fiance",
      "Pretre","Engage","Soeur","Autre"]
label=Label(fen,fg='orange',font="Cambria 12 italic")
lisB=Listbox(fen,justify='center',font="Arial 12",height=5)
scl=Scrollbar(fen,command=lisB.yview)
lisB.config(yscrollcommand=scl.set)
for i in item:
    lisB.insert("end",i)

btn=Button(fen,text="Enter",command=textDef)
label.grid(pady=5, padx=5,row=0,column=0)
lisB.grid(pady=5, padx=5,row=1,column=0)
btn.grid(pady=5, padx=5,row=2,column=0)
scl.grid(pady=5, padx=5,row=0,column=1,rowspan=3)
fen.mainloop()

