from tkinter import *

fen=Tk()
fen.geometry("300x250")
fen.title("Frame")
fr=Frame(fen, width=120,height=240,bg='green')
#Button(fr, text='Bouton').pack()
LFr=LabelFrame(fen,text='LabelFrame',labelanchor='ne' ,
               width=160,height=240,bg='pink',relief=SOLID)
#Label(LFr,text='Du texte', fg='blue').pack()
fr.pack(side=LEFT,padx=5)
LFr.pack(side=RIGHT,padx=5)

