from tkinter import *
def BtnClick():
    text.configure(text="Evenement : Bouton click")
def BtnClickD(event):
    text.configure(text="Evenement : Bouton click droit")

fen = Tk()
fen.title("Bouton & Texte")
fen.geometry("300x100")

btn=Button(fen,text='Bouton', bg='pink', fg='blue',command=BtnClick)
text=Label(fen,text='Evenement : ',
           font=('Times new roman ', 12, 'bold','italic'),
           fg='green')
btn.bind('<Button-3>',BtnClickD)
btn.pack(side=BOTTOM, pady=10,fill=X)
text.pack(side=TOP)
fen.mainloop()

