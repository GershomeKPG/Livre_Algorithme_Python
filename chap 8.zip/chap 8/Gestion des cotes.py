import tkinter as tk
from tkinter import ttk,messagebox
import json

class Promotion:
    def __init__(self, nom: str):
        self.nom = nom
        self.etudiants = []
        self.cours = []

    @staticmethod
    def ajouter_promotion(nom: str):
        nouvelle_promotion = Promotion(nom)
        promotions.append(nouvelle_promotion)
        sauvegarder_donnees()

    def modifier_promotion(self, nouveau_nom: str):
        self.nom = nouveau_nom
        sauvegarder_donnees()

    def supprimer_promotion(self):
        promotions.remove(self)
        sauvegarder_donnees()

class Cours:
    def __init__(self, nom: str, credits: int, code: str):
        self.nom = nom
        self.credits = credits
        self.code = code

class Etudiant:
    def __init__(self, nom: list, sexe: bool, code: int):
        self.nom = nom
        self.sexe = sexe
        self.code = code
        self.points = {}

class Point:
    pass

def inscrire_etudiant():
    nom = entry_student_name.get().split(", ")
    sexe = entry_student_gender.get().upper() == "M"
    code = int(entry_student_code.get())
    promotion = promotion_combo_student.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            nouvel_etudiant = Etudiant(nom, sexe, code)
            promotion_obj.etudiants.append(nouvel_etudiant)
            for cours in promotion_obj.cours:
                nouvel_etudiant.points[cours.code] = 0
            sauvegarder_donnees()
            actualiser_combobox_cours()
            lister_etudiants()
            actualiser_combobox_etudiants()

def modifier_etudiant():
    nom = entry_student_name.get().split(", ")
    sexe = entry_student_gender.get().upper() == "M"
    code = int(entry_student_code.get())
    promotion = promotion_combo_student.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            etudiant_index = student_list.curselection()[0]
            etudiant = promotion_obj.etudiants[etudiant_index]
            etudiant.nom = nom
            etudiant.sexe = sexe
            etudiant.code = code
            sauvegarder_donnees()
            actualiser_combobox_cours()
            lister_etudiants()
            actualiser_combobox_etudiants()
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion pour modifier un  etudiant.")
def lister_etudiants():
    student_list.delete(0, tk.END)
    promotion = promotion_combo_student.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            for etudiant in promotion_obj.etudiants:
                student_list.insert(tk.END, f"{', '.join(etudiant.nom)} ({etudiant.code})")
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion ")
def supprimer_etudiant():
    promotion = promotion_combo_student.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            etudiant_index = student_list.curselection()[0]
            etudiant = promotion_obj.etudiants[etudiant_index]
            promotion_obj.etudiants.remove(etudiant)
            sauvegarder_donnees()
            actualiser_combobox_cours()
            lister_etudiants()
            actualiser_combobox_etudiants()
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion pour suprimmer un etudiant.")

def creer_cours():
    nom = entry_course_name.get()
    credits = int(entry_course_credits.get())
    code = entry_course_code.get()
    promotion = promotion_combo_course.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            nouveau_cours = Cours(nom, credits, code)
            promotion_obj.cours.append(nouveau_cours)
            for etudiant in promotion_obj.etudiants:
                etudiant.points[code] = 0
            sauvegarder_donnees()
            actualiser_combobox_cours()
            lister_cours()
            actualiser_combobox_etudiants()
            # Actualiser les valeurs des ComboBox des cours
            promotion_combo_course['values'] = [promotion.nom for promotion in promotions]

    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion ainsi que le cour, pour creer un  cour.")

def modifier_cours():
    nom = entry_course_name.get()
    credits = int(entry_course_credits.get())
    code = entry_course_code.get()
    promotion = promotion_combo_course.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            cours_index = course_list.curselection()[0]
            cours = promotion_obj.cours[cours_index]
            cours.nom = nom
            cours.credits = credits
            cours.code = code
            sauvegarder_donnees()
            actualiser_combobox_cours()
            lister_cours()
            actualiser_combobox_etudiants()
            # Actualiser les valeurs des ComboBox des cours
            promotion_combo_course['values'] = [promotion.nom for promotion in promotions]

    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion ainsi que le cour, pour modifier un cour.")

def lister_cours():
    course_list.delete(0, tk.END)
    promotion = promotion_combo_course.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            for cours in promotion_obj.cours:
                course_list.insert(tk.END, f"{cours.nom} ({cours.code}, {cours.credits} crédits)")
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion ")
def supprimer_cours():
    promotion = promotion_combo_course.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            cours_index = course_list.curselection()[0]
            cours = promotion_obj.cours[cours_index]
            promotion_obj.cours.remove(cours)
            for etudiant in promotion_obj.etudiants:
                del etudiant.points[cours.code]
            sauvegarder_donnees()
            lister_cours()
            actualiser_combobox_etudiants()
            actualiser_combobox_cours()
            # Actualiser les valeurs des ComboBox des cours
            promotion_combo_course['values'] = [promotion.nom for promotion in promotions]
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion ainsi que le cour a supprimmer.")

def modifier_point():
    nouveau_point = int(entry_point.get())
    # Vérifier que nouveau_point est compris entre 0 et 20
    if nouveau_point < 0:
        messagebox.showerror("Erreur", "La cote ne peut pas être inférieure à 0.")
    elif nouveau_point > 20:
        messagebox.showerror("Erreur", "La cote ne peut pas être supérieure à 20.")

    promotion = promotion_combo_point.get()
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            etudiant_index = student_combo_point.current()
            if etudiant_index < len(promotion_obj.etudiants):  # Vérifier si l'index est valide
                etudiant = promotion_obj.etudiants[etudiant_index]
                cours_index = course_combo_point.current()
                cours = promotion_obj.cours[cours_index]
                etudiant.points[cours.code] = nouveau_point
                sauvegarder_donnees()
            else:
                messagebox.showerror("Erreur", "Index d'étudiant invalide.")
    else:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion.")

def produire_proclamation():
    promotion_nom = proclamation_combo.get()
    if promotion_nom:
        promotion = next((p for p in promotions if p.nom == promotion_nom), None)
        if promotion:
            proclamation_text.delete('1.0', tk.END)
            proclamation_text.insert(tk.END, f"{'Nom':<20} {'Points':<30} {'Pourcentage':<10}\n")
            proclamation_text.insert(tk.END, "-" * 65 + "\n")
            etudiants_tries = sorted(promotion.etudiants, key=lambda etudiant: sum(etudiant.points.values()), reverse=True)
            for etudiant in etudiants_tries:
                total_points = sum(etudiant.points.values())
                pourcentage = (total_points / (len(promotion.cours) * 20)) * 100
                points_format = ', '.join([f"{cours}: {points}" for cours, points in etudiant.points.items()])
                proclamation_text.insert(tk.END, f"{', '.join(etudiant.nom):<20} {points_format:<30} {pourcentage:.2f}%\n")

def sauvegarder_donnees():
    donnees = {
        "promotions": [
            {
                "nom": promotion.nom,
                "etudiants": [
                    {
                        "nom": etudiant.nom,
                        "sexe": etudiant.sexe,
                        "code": etudiant.code,
                        "points": etudiant.points
                    }
                    for etudiant in promotion.etudiants
                ],
                "cours": [
                    {
                        "nom": cours.nom,
                        "credits": cours.credits,
                        "code": cours.code
                    }
                    for cours in promotion.cours
                ]
            }
            for promotion in promotions
        ]
    }
    with open(chemin_fichier, "w") as fichier:
        json.dump(donnees, fichier)

def charger_donnees():
    global promotions
    try:
        with open(chemin_fichier, "r") as fichier:
            donnees = json.load(fichier)
        promotions = [
            Promotion(promotion["nom"])
            for promotion in donnees["promotions"]
        ]
        for promotion in promotions:
            promotion.etudiants = [
                Etudiant(etudiant["nom"], etudiant["sexe"], etudiant["code"])
                for etudiant in donnees["promotions"][promotions.index(promotion)]["etudiants"]
            ]
            promotion.cours = [
                Cours(cours["nom"], cours["credits"], cours["code"])
                for cours in donnees["promotions"][promotions.index(promotion)]["cours"]
            ]
            
            for etudiant in promotion.etudiants:
                etudiant.points = donnees["promotions"][promotions.index(promotion)]["etudiants"][promotion.etudiants.index(etudiant)]["points"]
    except FileNotFoundError:
        pass

def creer_promotion():
    nom_promotion = entry_promotion_name.get()
    Promotion.ajouter_promotion(nom_promotion)
    promotion_combo_student['values'] = [promotion.nom for promotion in promotions]
    promotion_combo_course['values'] = [promotion.nom for promotion in promotions]
    promotion_combo_point['values'] = [promotion.nom for promotion in promotions]
    proclamation_combo['values'] = [promotion.nom for promotion in promotions]
    mettre_a_jour_listbox_promotions()
    mettre_a_jour_combobox()

def modifier_promotion():
    try:
        index = promotions_list.curselection()[0]  # Récupérer l'index de la sélection actuelle dans la Listbox
        promotion_selectionnee = promotions_list.get(index)  # Récupérer le nom de la promotion sélectionnée
        nom_promotion = entry_promotion_name.get()  # Récupérer le nouveau nom de la promotion depuis l'entrée

        # Trouver l'objet promotion correspondant
        promotion_obj = next((p for p in promotions if p.nom == promotion_selectionnee), None)

        if promotion_obj and nom_promotion:
            promotion_obj.nom = nom_promotion  # Modifier le nom de la promotion
            mettre_a_jour_listbox_promotions()
            mettre_a_jour_combobox()  # Mettre à jour la Listbox et autres widgets si nécessaire
            entry_promotion_name.delete(0, tk.END)  # Nettoyer l'entrée après modification
        else:
            messagebox.showerror("Erreur", "Veuillez entrer un nouveau nom pour la promotion.")
    except IndexError:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion à modifier.")


def supprimer_promotion():
    try:
        index = promotions_list.curselection()[0]  # Récupérer l'index de la sélection actuelle dans la Listbox
        promotion_selectionnee = promotions_list.get(index)  # Récupérer le nom de la promotion sélectionnée

        # Trouver et supprimer l'objet promotion correspondant
        promotion_obj = next((p for p in promotions if p.nom == promotion_selectionnee), None)

        if promotion_obj:
            promotions.remove(promotion_obj)  # Supprimer la promotion de la liste
            mettre_a_jour_listbox_promotions()  # Mettre à jour la Listbox et autres widgets si nécessaire
            mettre_a_jour_combobox()
        else:
            messagebox.showerror("Erreur", "La promotion sélectionnée n'existe pas.")
    except IndexError:
        messagebox.showerror("Erreur", "Veuillez sélectionner une promotion à supprimer.")

def mettre_a_jour_combobox():
    # Mettre à jour les promotions
    promotions_noms = [promotion.nom for promotion in promotions]
    promotion_combo_promotion['values'] = promotions_noms
    promotion_combo_student['values'] = promotions_noms
    promotion_combo_course['values'] = promotions_noms
    promotion_combo_point['values'] = promotions_noms

    # Mettre à jour les ComboBox dans le frame des points en fonction de la promotion sélectionnée
    promotion_nom = promotion_combo_point.get()
    if promotion_nom:
        promotion = next((p for p in promotions if p.nom == promotion_nom), None)
        if promotion:
            etudiants_noms = [', '.join(etudiant.nom) for etudiant in promotion.etudiants]
            student_combo_point['values'] = etudiants_noms
            if etudiants_noms:  # Sélectionner automatiquement le premier étudiant si la liste n'est pas vide
                student_combo_point.current(0)
            else:
                student_combo_point.set('')
            # Mettez à jour les cours également si nécessaire
            cours_noms = [cours.nom for cours in promotion.cours]
            course_combo_point['values'] = cours_noms
            if cours_noms:
                course_combo_point.current(0)
            else:
                course_combo_point.set('')


def mettre_a_jour_listbox_promotions():
    promotions_list.delete(0, tk.END)  # Supprimer les entrées actuelles
    for promotion in promotions:
        promotions_list.insert(tk.END, promotion.nom)  # Ajouter la nouvelle liste des noms de promotions

def actualiser_listbox_cours():
    # Supposons que `course_list` est la ListBox que vous souhaitez mettre à jour.
    course_list.delete(0, tk.END)  # Supprimer les entrées actuelles
    
    promotion = promotion_combo_course.get()  # Obtenir la promotion sélectionnée dans le combobox
    if promotion:
        promotion_obj = next((p for p in promotions if p.nom == promotion), None)
        if promotion_obj:
            # Pour chaque cours dans la promotion sélectionnée, insérer le nom du cours dans la ListBox
            for cours in promotion_obj.cours:
                course_list.insert(tk.END, f"{cours.nom} ({cours.code}, {cours.credits} crédits)")


def actualiser_combobox_etudiants():
    promotion_nom = promotion_combo_point.get()
    if promotion_nom:
        promotion = next((p for p in promotions if p.nom == promotion_nom), None)
        if promotion:
            etudiants_noms = [', '.join(etudiant.nom) + f" ({etudiant.code})" for etudiant in promotion.etudiants]
            student_combo_point['values'] = etudiants_noms

def actualiser_combobox_cours():
    promotion_nom = promotion_combo_point.get()
    if promotion_nom:
        promotion = next((p for p in promotions if p.nom == promotion_nom), None)
        if promotion:
            cours_noms = [f"{cours.nom} ({cours.code})" for cours in promotion.cours]
            course_combo_point['values'] = cours_noms


promotions = []
chemin_fichier = "donnees.json"
charger_donnees()

app = tk.Tk()
app.title("Gestion des Promotions")

promotion_frame = tk.LabelFrame(app, text="Gestion des Promotions")
promotion_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

promotions_list = tk.Listbox(promotion_frame,width=10,height=18)
promotions_list.grid(row=3, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")

label_promotion = ttk.Label(promotion_frame, text="Promotion :")
label_promotion.grid(row=0, column=0, padx=5, pady=5, sticky="w")

promotion_combo_promotion = ttk.Combobox(promotion_frame, values=[promotion.nom for promotion in promotions])
promotion_combo_promotion.grid(row=0, column=1, padx=5, pady=5)

button_create_promotion = ttk.Button(promotion_frame, text="Créer", command=creer_promotion)
button_create_promotion.grid(row=2, column=0, padx=5, pady=5, sticky="ew")

button_modify_promotion = ttk.Button(promotion_frame, text="Modifier", command=modifier_promotion)
button_modify_promotion.grid(row=2, column=1, padx=5, pady=5, sticky="ew")

button_delete_promotion = ttk.Button(promotion_frame, text="Supprimer", command=supprimer_promotion)
button_delete_promotion.grid(row=2, column=2, padx=5, pady=5, sticky="ew")

entry_promotion_name = ttk.Entry(promotion_frame)
entry_promotion_name.grid(row=1, column=0, columnspan=5, padx=5, pady=5, sticky="ew")

student_frame = tk.LabelFrame(app, text="Gestion des Étudiants")
student_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")

label_student_name = ttk.Label(student_frame, text="Nom complet :")
label_student_name.grid(row=0, column=0, padx=5, pady=5, sticky="w")

entry_student_name = ttk.Entry(student_frame)
entry_student_name.grid(row=0, column=1, padx=5, pady=5)

label_student_gender = ttk.Label(student_frame, text="Sexe (M/F) :")
label_student_gender.grid(row=1, column=0, padx=5, pady=5, sticky="w")

entry_student_gender = ttk.Entry(student_frame)
entry_student_gender.grid(row=1, column=1, padx=5, pady=5)

label_student_code = ttk.Label(student_frame, text="Code étudiant :")
label_student_code.grid(row=2, column=0, padx=5, pady=5, sticky="w")

entry_student_code = ttk.Entry(student_frame)
entry_student_code.grid(row=2, column=1, padx=5, pady=5)

label_course_promotion = ttk.Label(student_frame, text="Promotion :")
label_course_promotion.grid(row=3, column=0, padx=5, pady=5, sticky="w")

button_add_student = ttk.Button(student_frame, text="Inscrire", command=inscrire_etudiant)
button_add_student.grid(row=4, column=0, columnspan=2, padx=5, pady=5, sticky="ew")

button_modify_student = ttk.Button(student_frame, text="Modifier", command=modifier_etudiant)
button_modify_student.grid(row=5, column=0, padx=5, pady=5, sticky="ew")

button_delete_student = ttk.Button(student_frame, text="Supprimer", command=supprimer_etudiant)
button_delete_student.grid(row=5, column=1, padx=5, pady=5, sticky="ew")

button_show_students = ttk.Button(student_frame, text="Afficher Étudiants", command=lister_etudiants)
button_show_students.grid(row=7, column=0, columnspan=2, padx=5, pady=5, sticky="ew")

student_list = tk.Listbox(student_frame,width=10,height=10)
student_list.grid(row=6, column=0, columnspan=2, padx=5, pady=5, sticky="nsew")

promotion_combo_student = ttk.Combobox(student_frame, values=[promotion.nom for promotion in promotions])
promotion_combo_student.grid(row=3, column=1, padx=5, pady=5)

course_frame = tk.LabelFrame(app, text="Gestion des Cours")
course_frame.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")

label_course_name = ttk.Label(course_frame, text="Nom du cours :")
label_course_name.grid(row=0, column=0, padx=5, pady=5, sticky="w")

entry_course_name = ttk.Entry(course_frame)
entry_course_name.grid(row=0, column=1, padx=5, pady=5)

label_course_credits = ttk.Label(course_frame, text="Crédits :")
label_course_credits.grid(row=1, column=0, padx=5, pady=5, sticky="w")

entry_course_credits = ttk.Entry(course_frame)
entry_course_credits.grid(row=1, column=1, padx=5, pady=5)

label_course_code = ttk.Label(course_frame, text="Code du cours :")
label_course_code.grid(row=2, column=0, padx=5, pady=5, sticky="w")

entry_course_code = ttk.Entry(course_frame)
entry_course_code.grid(row=2, column=1, padx=5, pady=5)

label_course_promotion = ttk.Label(course_frame, text="Promotion :")
label_course_promotion.grid(row=3, column=0, padx=5, pady=5, sticky="w")

promotion_combo_course = ttk.Combobox(course_frame, values=[promotion.nom for promotion in promotions])
promotion_combo_course.grid(row=3, column=1, padx=5, pady=5)

button_create_course = ttk.Button(course_frame, text="Créer", command=creer_cours)
button_create_course.grid(row=4, column=0, padx=5, pady=5, sticky="ew")

button_modify_course = ttk.Button(course_frame, text="Modifier", command=modifier_cours)
button_modify_course.grid(row=4, column=1, padx=5, pady=5, sticky="ew")

button_delete_course = ttk.Button(course_frame, text="Supprimer", command=supprimer_cours)
button_delete_course.grid(row=4, column=2, padx=5, pady=5, sticky="ew")

course_list = tk.Listbox(course_frame,width=15,height=13)
course_list.grid(row=5, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")

button_show_courses = ttk.Button(course_frame, text="Afficher Cours", command=lister_cours)
button_show_courses.grid(row=6, column=0, columnspan=3, padx=5, pady=5, sticky="ew")

point_frame = tk.LabelFrame(app, text="Gestion des Points")
point_frame.grid(row=0, column=3, padx=10, pady=10, sticky="nsew")

label_point = ttk.Label(point_frame, text="Points :")
label_point.grid(row=0, column=0, padx=5, pady=5, sticky="w")

entry_point = ttk.Entry(point_frame)
entry_point.grid(row=0, column=1, padx=5, pady=5)

label_student_point = ttk.Label(point_frame, text="Étudiant :")
label_student_point.grid(row=1, column=0, padx=5, pady=5, sticky="w")

student_combo_point = ttk.Combobox(point_frame, values=[ ','.join(etudiant.nom) for promotion in promotions for etudiant in promotion.etudiants])
student_combo_point.grid(row=1, column=1, padx=5, pady=5)

label_promotion_point = ttk.Label(point_frame, text="Promotion :")
label_promotion_point.grid(row=2, column=0, padx=5, pady=5, sticky="w")

promotion_combo_point = ttk.Combobox(point_frame, values=[promotion.nom for promotion in promotions])
promotion_combo_point.grid(row=2, column=1, padx=5, pady=5)

label_course_point = ttk.Label(point_frame, text="Cours :")
label_course_point.grid(row=3, column=0, padx=5, pady=5, sticky="w")

course_combo_point = ttk.Combobox(point_frame, values=[cours.nom for promotion in promotions for cours in promotion.cours])
course_combo_point.grid(row=3, column=1, padx=5, pady=5)

button_modify_point = ttk.Button(point_frame, text="Modifier", command=modifier_point)
button_modify_point.grid(row=4, column=0, columnspan=2, padx=5, pady=5, sticky="ew")

proclamation_frame = tk.LabelFrame(app, text="Production de la Proclamation")
proclamation_frame.grid(row=1, column=0, columnspan=4, padx=10, pady=10, sticky="nsew")

label_proclamation = ttk.Label(proclamation_frame, text="Promotion :")
label_proclamation.grid(row=0, column=0, padx=5, pady=5, sticky="w")

proclamation_combo = ttk.Combobox(proclamation_frame, values=[promotion.nom for promotion in promotions])
proclamation_combo.grid(row=0, column=1, padx=5, pady=5)

button_produce_proclamation = ttk.Button(proclamation_frame, text="Produire", command=produire_proclamation)
button_produce_proclamation.grid(row=0, column=2, padx=5, pady=5, sticky="ew")

proclamation_text = tk.Text(proclamation_frame,width=150,height=10)
proclamation_text.grid(row=1, column=0, columnspan=4, padx=5, pady=5, sticky="nsew",)

mettre_a_jour_listbox_promotions()
actualiser_combobox_etudiants()
actualiser_combobox_cours()
actualiser_listbox_cours()

app.mainloop()