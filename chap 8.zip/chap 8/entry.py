from tkinter import *

def textDef(event):
    text=txt.get()
    label.configure(text=text)

fen=Tk()
fen.geometry("200x150")
fen.title("Widget Entry")

label=Label(fen,fg='orange',font="Cambria 12 italic")
txt=Entry(fen,font="Cambria 12 italic bold",justify='center')
btn=Button(fen,text="Enter")
btn.bind("<Button-1>",textDef)
txt.insert(0,"Algo")
label.pack(pady=5)
txt.pack(pady=5)
btn.pack(pady=5)
fen.mainloop()
