
from tkinter import *

def textDef(val):
    label.configure(text="Position : "+str(val))
    
fen=Tk()
fen.geometry("200x150")
fen.title("Widget")

label=Label(fen,fg='orange',font="Cambria 12 italic")
scl=Scale(fen,font="Cambria 12 italic",
          from_=0,to=100,orient='horizontal',length=150,
          label='Reglage',bg='Light Gray',fg='black',
          showvalue=1,resolution=10,tickinterval=25,
          sliderlength=15,command=textDef)

label.pack(pady=5,side=TOP)
scl.pack(side=BOTTOM, pady=5)
fen.mainloop()

