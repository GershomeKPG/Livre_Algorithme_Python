from tkinter import ttk 
from tkinter import *  

def DefText(event):
    l1.config(text=bbox.get())

fen=Tk()
fen.geometry("200x120")
fen.title("tkinter.ttk")

option=["Enfant","Adulte","Majeur","Vieux"]

style = ttk.Style()
style.configure("aff.TLabel", foreground="Dark Blue", background="white")
style.configure("Cb.TCombobox", foreground="Black", background="gray")
style.map("Cb.TCombobox",
                foreground=[("pressed","blue"),("active","green")],
                background=[("pressed","white"),("active","Ivory")])
l1 = ttk.Label(fen, style="aff.TLabel")
bbox = ttk.Combobox(fen,value=option,state="readonly", style="Cb.TCombobox")
bbox.current(newindex=1)
bbox.bind("<<ComboboxSelected>>", DefText)

l1.pack(pady=5)
bbox.pack(pady=5)
fen.mainloop()

