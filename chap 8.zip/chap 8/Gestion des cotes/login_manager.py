# login_manager.py - Gestion de la connexion et inscription
import tkinter as tk
from tkinter import messagebox
import data_handler as dh
from config import COLORS, FONTS
from ui_components import PrimaryButton, SecondaryButton, LabeledEntry

class LoginFrame(tk.Frame):
    """Cadre pour la page de connexion."""
    def __init__(self, parent, login_callback, switch_to_register):
        super().__init__(parent)
        self.parent = parent
        self.login_callback = login_callback
        
        # Configuration du dégradé de fond (simulation avec une étiquette)
        self.config(bg=COLORS["login_gradient_start"])
        
        # Cadre central pour le formulaire de connexion
        login_form = tk.Frame(
            self,
            bg=COLORS["bg_white"],
            padx=40,
            pady=40,
            bd=1,
            relief="solid"
        )
        login_form.place(relx=0.5, rely=0.5, anchor="center")
        
        # Titre
        title = tk.Label(
            login_form,
            text="Connexion",
            font=FONTS["title"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Champ d'utilisateur
        self.username_field = LabeledEntry(login_form, "Nom d'utilisateur")
        self.username_field.pack(fill="x", pady=5)
        
        # Champ de mot de passe
        self.password_field = LabeledEntry(login_form, "Mot de passe", show="*")
        self.password_field.pack(fill="x", pady=5)
        
        # Boutons
        buttons_frame = tk.Frame(login_form, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        login_btn = PrimaryButton(
            buttons_frame,
            text="Se connecter",
            command=self._attempt_login
        )
        login_btn.pack(side="left", padx=(0, 5))
        
        register_btn = SecondaryButton(
            buttons_frame,
            text="S'inscrire",
            command=switch_to_register
        )
        register_btn.pack(side="left")
    
    def _attempt_login(self):
        """Tentative de connexion avec les identifiants fournis."""
        username = self.username_field.get()
        password = self.password_field.get()
        
        if not username or not password:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        # Vérification des identifiants
        if dh.authenticate_user(username, password):
            self.login_callback(username)
        else:
            messagebox.showerror("Erreur", "Identifiants incorrects.")

class RegisterFrame(tk.Frame):
    """Cadre pour la page d'inscription."""
    def __init__(self, parent, register_callback, switch_to_login):
        super().__init__(parent)
        self.parent = parent
        self.register_callback = register_callback
        
        # Configuration du dégradé de fond (simulation avec une étiquette)
        self.config(bg=COLORS["signup_gradient_start"])
        
        # Cadre central pour le formulaire d'inscription
        register_form = tk.Frame(
            self,
            bg=COLORS["bg_white"],
            padx=40,
            pady=40,
            bd=1,
            relief="solid"
        )
        register_form.place(relx=0.5, rely=0.5, anchor="center")
        
        # Titre
        title = tk.Label(
            register_form,
            text="Inscription",
            font=FONTS["title"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Champ d'utilisateur
        self.username_field = LabeledEntry(register_form, "Nouveau nom d'utilisateur")
        self.username_field.pack(fill="x", pady=5)
        
        # Champ de mot de passe
        self.password_field = LabeledEntry(register_form, "Nouveau mot de passe", show="*")
        self.password_field.pack(fill="x", pady=5)
        
        # Confirmation du mot de passe
        self.confirm_password_field = LabeledEntry(register_form, "Confirmer le mot de passe", show="*")
        self.confirm_password_field.pack(fill="x", pady=5)
        
        # Boutons
        buttons_frame = tk.Frame(register_form, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        register_btn = SecondaryButton(
            buttons_frame,
            text="Valider l'inscription",
            command=self._attempt_register
        )
        register_btn.pack(side="left", padx=(0, 5))
        
        login_btn = PrimaryButton(
            buttons_frame,
            text="Retour à la connexion",
            command=switch_to_login
        )
        login_btn.pack(side="left")
    
    def _attempt_register(self):
        """Tentative d'inscription avec les identifiants fournis."""
        username = self.username_field.get()
        password = self.password_field.get()
        confirm_password = self.confirm_password_field.get()
        
        if not username or not password or not confirm_password:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        if password != confirm_password:
            messagebox.showerror("Erreur", "Les mots de passe ne correspondent pas.")
            return
        
        # Enregistrement de l'utilisateur
        if dh.register_user(username, password):
            messagebox.showinfo("Succès", "Inscription réussie. Vous pouvez maintenant vous connecter.")
            self.register_callback()
        else:
            messagebox.showerror("Erreur", "Ce nom d'utilisateur existe déjà.")

class AccountSettingsFrame(tk.Frame):
    """Cadre pour les paramètres du compte."""
    def __init__(self, parent, username, navigate_callback):
        super().__init__(parent, bg=COLORS["bg_light"])
        self.username = username
        self.navigate_callback = navigate_callback
        
        # Titre
        title_frame = tk.Frame(self, bg=COLORS["bg_light"], pady=20)
        title_frame.pack(fill="x")
        
        title = tk.Label(
            title_frame,
            text="Paramètres du compte",
            font=FONTS["title"],
            bg=COLORS["bg_light"]
        )
        title.pack()
        
        # Formulaire central
        form_frame = tk.Frame(
            self,
            bg=COLORS["bg_white"],
            padx=40,
            pady=40,
            bd=1,
            relief="solid"
        )
        form_frame.pack(padx=50, pady=20, fill="both", expand=False)
        
        # Nom d'utilisateur (affichage uniquement)
        username_label = tk.Label(
            form_frame,
            text=f"Nom d'utilisateur: {username}",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        username_label.pack(fill="x", pady=(0, 20))
        
        # Changement de mot de passe
        password_label = tk.Label(
            form_frame,
            text="Changer le mot de passe",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        password_label.pack(fill="x", pady=(0, 10))
        
        # Ancien mot de passe
        self.old_password_field = LabeledEntry(form_frame, "Ancien mot de passe", show="*")
        self.old_password_field.pack(fill="x", pady=5)
        
        # Nouveau mot de passe
        self.new_password_field = LabeledEntry(form_frame, "Nouveau mot de passe", show="*")
        self.new_password_field.pack(fill="x", pady=5)
        
        # Confirmation du nouveau mot de passe
        self.confirm_password_field = LabeledEntry(form_frame, "Confirmer le nouveau mot de passe", show="*")
        self.confirm_password_field.pack(fill="x", pady=5)
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        save_btn = PrimaryButton(
            buttons_frame,
            text="Enregistrer les modifications",
            command=self._save_changes
        )
        save_btn.pack(side="left", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=lambda: navigate_callback("home")
        )
        cancel_btn.pack(side="left")
    
    def _save_changes(self):
        """Enregistre les modifications du mot de passe."""
        old_password = self.old_password_field.get()
        new_password = self.new_password_field.get()
        confirm_password = self.confirm_password_field.get()
        
        if not old_password or not new_password or not confirm_password:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        if new_password != confirm_password:
            messagebox.showerror("Erreur", "Les nouveaux mots de passe ne correspondent pas.")
            return
        
        # Vérification de l'ancien mot de passe
        if not dh.authenticate_user(self.username, old_password):
            messagebox.showerror("Erreur", "L'ancien mot de passe est incorrect.")
            return
        
        # Mise à jour du mot de passe
        if dh.update_user_password(self.username, new_password):
            messagebox.showinfo("Succès", "Mot de passe modifié avec succès.")
            self.navigate_callback("home")
        else:
            messagebox.showerror("Erreur", "Une erreur est survenue lors de la modification du mot de passe.")
