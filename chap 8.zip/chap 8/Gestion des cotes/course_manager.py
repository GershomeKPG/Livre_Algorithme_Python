# course_manager.py - Gestion des cours
import tkinter as tk
from tkinter import ttk, messagebox
import data_handler as dh
from config import COLORS, FONTS, PROMOTIONS
from ui_components import PrimaryButton, SecondaryButton, DangerButton, LabeledEntry, CustomTreeview, validate_numeric_input, PromotionCombobox

class CoursesManagementFrame(tk.Frame):
    """Cadre pour la gestion des cours."""
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg_light"])
        
        # Titre de la page
        title_frame = tk.Frame(self, bg=COLORS["bg_light"], pady=20)
        title_frame.pack(fill="x")
        
        title = tk.Label(
            title_frame,
            text="Gestion des cours",
            font=FONTS["title"],
            bg=COLORS["bg_light"]
        )
        title.pack()
        
        # Zone principale
        main_zone = tk.Frame(self, bg=COLORS["bg_light"])
        main_zone.pack(padx=20, pady=10, fill="both", expand=True)
        
        # Zone de formulaire (haut)
        form_frame = tk.Frame(main_zone, bg=COLORS["bg_white"], padx=20, pady=20, bd=1, relief="solid")
        form_frame.pack(fill="x", pady=(0, 20))
        
        # Formulaire d'ajout/modification de cours
        form_title = tk.Label(
            form_frame,
            text="Ajouter un cours",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        form_title.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 15))
        
        # Champ pour le nom du cours
        self.course_name_entry = LabeledEntry(form_frame, "Nom du cours")
        self.course_name_entry.grid(row=1, column=0, sticky="ew", padx=(0, 10))
        
        # Validation pour les crédits (numérique uniquement)
        vcmd = (self.register(validate_numeric_input), '%d', '%P')
        
        # Champ pour les crédits
        self.credits_entry = LabeledEntry(form_frame, "Nombre de crédits")
        self.credits_entry.entry.config(validate="key", validatecommand=vcmd)
        self.credits_entry.grid(row=1, column=1, sticky="ew", padx=(10, 10))
        
        # Promotion à laquelle appartient le cours
        promotion_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        promotion_frame.grid(row=1, column=2, sticky="ew", padx=(10, 10))
        
        promotion_label = tk.Label(
            promotion_frame,
            text="Promotion",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        promotion_label.pack(fill="x", pady=(5, 2))
        
        self.promotion_combobox = PromotionCombobox(promotion_frame)
        self.promotion_combobox.pack(fill="x", ipady=4)
        
        # Bouton d'ajout
        self.add_btn = PrimaryButton(
            form_frame,
            text="Ajouter",
            command=self._add_course
        )
        self.add_btn.grid(row=1, column=3, sticky="e", padx=(10, 0))
        
        # Configurer la grille
        form_frame.grid_columnconfigure(0, weight=2)
        form_frame.grid_columnconfigure(1, weight=1)
        form_frame.grid_columnconfigure(2, weight=1)
        form_frame.grid_columnconfigure(3, weight=1)
        
        # Variable pour le suivi du cours en cours d'édition
        self.current_editing_course = None
        
        # Tableau des cours (bas)
        table_frame = tk.Frame(main_zone, bg=COLORS["bg_white"], padx=20, pady=20, bd=1, relief="solid")
        table_frame.pack(fill="both", expand=True)
        
        # Titre du tableau
        table_title = tk.Label(
            table_frame,
            text="Liste des cours",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        table_title.pack(anchor="w", pady=(0, 15))
        
        # Tableau des cours
        self.courses_table = CustomTreeview(
            table_frame,
            columns=("course_name", "credits", "promotion"),
            show="headings",
            selectmode="browse",
            height=10
        )
        
        # Configuration des colonnes
        self.courses_table.heading("course_name", text="Nom du cours")
        self.courses_table.heading("credits", text="Crédits")
        self.courses_table.heading("promotion", text="Promotion")
        
        self.courses_table.column("course_name", width=400, anchor="w")
        self.courses_table.column("credits", width=100, anchor="center")
        self.courses_table.column("promotion", width=100, anchor="center")
        
        # Ajout de la barre de défilement
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.courses_table.yview)
        self.courses_table.configure(yscrollcommand=scrollbar.set)
        
        # Placement du tableau et de la barre de défilement
        self.courses_table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Boutons d'action
        buttons_frame = tk.Frame(table_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        self.edit_btn = SecondaryButton(
            buttons_frame,
            text="Modifier",
            command=self._edit_course
        )
        self.edit_btn.pack(side="left", padx=(0, 5))
        
        self.delete_btn = DangerButton(
            buttons_frame,
            text="Supprimer",
            command=self._delete_course
        )
        self.delete_btn.pack(side="left")
        
        # Chargement initial des cours
        self.load_courses()
        
        # Liaison d'événement pour la sélection dans le tableau
        self.courses_table.bind("<<TreeviewSelect>>", self._on_course_select)
    
    def load_courses(self):
        """Charge et affiche tous les cours."""
        # Effacer le tableau existant
        for item in self.courses_table.get_children():
            self.courses_table.delete(item)
        
        # Charger les cours depuis le fichier CSV
        courses = dh.get_all_courses()
        
        # Ajouter chaque cours au tableau
        for i, course in enumerate(courses):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.courses_table.insert(
                "",
                "end",
                values=(course["course_name"], course["credits"], course["promotion"]),
                tags=(tag,)
            )
    
    def _add_course(self):
        """Ajoute ou met à jour un cours."""
        course_name = self.course_name_entry.get()
        credits = self.credits_entry.get()
        promotion = self.promotion_combobox.get()
        
        if not course_name or not credits or not promotion:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        try:
            credits = int(credits)
            if credits <= 0:
                messagebox.showerror("Erreur", "Le nombre de crédits doit être positif.")
                return
        except ValueError:
            messagebox.showerror("Erreur", "Le nombre de crédits doit être un nombre entier.")
            return
        
        if self.current_editing_course:
            # Mode mise à jour
            if dh.update_course(self.current_editing_course, course_name, str(credits), promotion):
                messagebox.showinfo("Succès", "Cours mis à jour avec succès.")
                self._reset_form()
                self.load_courses()
            else:
                messagebox.showerror("Erreur", "Impossible de mettre à jour le cours.")
        else:
            # Mode ajout
            if dh.add_course(course_name, str(credits), promotion):
                messagebox.showinfo("Succès", "Cours ajouté avec succès.")
                self._reset_form()
                self.load_courses()
            else:
                messagebox.showerror("Erreur", "Ce cours existe déjà pour cette promotion.")
    
    def _edit_course(self):
        """Prépare le formulaire pour la modification d'un cours sélectionné."""
        selected_items = self.courses_table.selection()
        if not selected_items:
            messagebox.showinfo("Information", "Veuillez sélectionner un cours à modifier.")
            return
        
        # Récupérer les valeurs du cours sélectionné
        item = selected_items[0]
        course_name, credits, promotion = self.courses_table.item(item, "values")
        
        # Remplir le formulaire avec les valeurs
        self.course_name_entry.set(course_name)
        self.credits_entry.set(credits)
        self.promotion_combobox.set(promotion)
        
        # Changer le bouton d'ajout en bouton de mise à jour
        self.add_btn.config(text="Mettre à jour")
        
        # Mémoriser le cours en cours d'édition
        self.current_editing_course = course_name
    
    def _delete_course(self):
        """Supprime le cours sélectionné."""
        selected_items = self.courses_table.selection()
        if not selected_items:
            messagebox.showinfo("Information", "Veuillez sélectionner un cours à supprimer.")
            return
        
        # Récupérer le nom du cours sélectionné
        item = selected_items[0]
        course_name = self.courses_table.item(item, "values")[0]
        
        # Demander confirmation
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer le cours '{course_name}' ?"):
            if dh.delete_course(course_name):
                messagebox.showinfo("Succès", "Cours supprimé avec succès.")
                self.load_courses()
                
                # Si le cours supprimé était en cours d'édition, réinitialiser le formulaire
                if self.current_editing_course == course_name:
                    self._reset_form()
            else:
                messagebox.showerror("Erreur", "Impossible de supprimer le cours.")
    
    def _reset_form(self):
        """Réinitialise le formulaire pour un nouvel ajout."""
        self.course_name_entry.set("")
        self.credits_entry.set("")
        self.promotion_combobox.current(0)
        self.add_btn.config(text="Ajouter")
        self.current_editing_course = None
    
    def _on_course_select(self, event):
        """Gère l'événement de sélection d'un cours dans le tableau."""
        # Cette méthode peut être utilisée pour activer/désactiver des boutons
        # ou pour d'autres actions lorsqu'un cours est sélectionné
        selected_items = self.courses_table.selection()
        if selected_items:
            self.edit_btn.config(state="normal")
            self.delete_btn.config(state="normal")
        else:
            self.edit_btn.config(state="disabled")
            self.delete_btn.config(state="disabled")
