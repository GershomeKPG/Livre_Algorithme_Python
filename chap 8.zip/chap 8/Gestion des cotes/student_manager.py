# student_manager.py - Gestion des étudiants
import tkinter as tk
from tkinter import ttk, messagebox
import data_handler as dh
from config import COLORS, FONTS, PROMOTIONS
from ui_components import PrimaryButton, SecondaryButton, DangerButton, LabeledEntry, CustomTreeview, PromotionCombobox

class StudentsListFrame(tk.Frame):
    """Cadre pour la liste des étudiants."""
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg_light"])
        
        # Titre de la page
        title_frame = tk.Frame(self, bg=COLORS["bg_light"], pady=20)
        title_frame.pack(fill="x")
        
        title = tk.Label(
            title_frame,
            text="Liste des étudiants",
            font=FONTS["title"],
            bg=COLORS["bg_light"]
        )
        title.pack(side="left", padx=20)
        
        # Zone de recherche
        search_frame = tk.Frame(title_frame, bg=COLORS["bg_light"])
        search_frame.pack(side="right", padx=20)
        
        search_label = tk.Label(
            search_frame,
            text="Rechercher:",
            font=FONTS["main"],
            bg=COLORS["bg_light"]
        )
        search_label.pack(side="left", padx=(0, 10))
        
        self.search_entry = tk.Entry(search_frame, font=FONTS["main"], width=20)
        self.search_entry.pack(side="left")
        
        search_btn = PrimaryButton(
            search_frame,
            text="Rechercher",
            command=self._search_student
        )
        search_btn.pack(side="left", padx=5)
        
        # Zone principale
        main_zone = tk.Frame(self, bg=COLORS["bg_light"])
        main_zone.pack(padx=20, pady=10, fill="both", expand=True)
        
        # Tableau des étudiants
        table_frame = tk.Frame(main_zone, bg=COLORS["bg_white"], padx=20, pady=20, bd=1, relief="solid")
        table_frame.pack(fill="both", expand=True)
        
        # Bouton d'ajout d'étudiant
        add_student_btn = PrimaryButton(
            table_frame,
            text="Ajouter un étudiant",
            command=self._add_student
        )
        add_student_btn.pack(anchor="w", pady=(0, 15))
        
        # Tableau des étudiants
        self.students_table = CustomTreeview(
            table_frame,
            columns=("student_name", "promotion"),
            show="headings",
            selectmode="browse",
            height=15
        )
        
        # Configuration des colonnes
        self.students_table.heading("student_name", text="Nom de l'étudiant")
        self.students_table.heading("promotion", text="Promotion")
        
        self.students_table.column("student_name", width=300, anchor="w")
        self.students_table.column("promotion", width=100, anchor="center")
        
        # Ajout de la barre de défilement
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.students_table.yview)
        self.students_table.configure(yscrollcommand=scrollbar.set)
        
        # Placement du tableau et de la barre de défilement
        self.students_table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Boutons d'action
        buttons_frame = tk.Frame(table_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        self.edit_btn = SecondaryButton(
            buttons_frame,
            text="Modifier",
            command=self._edit_student,
            state="disabled"
        )
        self.edit_btn.pack(side="left", padx=(0, 5))
        
        self.delete_btn = DangerButton(
            buttons_frame,
            text="Supprimer",
            command=self._delete_student,
            state="disabled"
        )
        self.delete_btn.pack(side="left")
        
        # Chargement initial des étudiants
        self.load_students()
        
        # Liaison d'événement pour la sélection dans le tableau
        self.students_table.bind("<<TreeviewSelect>>", self._on_student_select)
        
        # Pour la recherche en temps réel
        self.search_entry.bind("<KeyRelease>", self._search_student)
    
    def load_students(self, search_term=None):
        """Charge et affiche tous les étudiants, avec filtre optionnel."""
        # Effacer le tableau existant
        for item in self.students_table.get_children():
            self.students_table.delete(item)
        
        # Charger les étudiants depuis le fichier CSV
        students = dh.get_all_students()
        
        # Filtrer si un terme de recherche est fourni
        if search_term:
            search_term = search_term.lower()
            students = [student for student in students if search_term in student["student_name"].lower()]
        
        # Ajouter chaque étudiant au tableau
        for i, student in enumerate(students):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.students_table.insert(
                "",
                "end",
                values=(
                    student["student_name"],
                    student["promotion"]
                ),
                tags=(tag,)
            )
    
    def _search_student(self, event=None):
        """Recherche un étudiant par son nom."""
        search_term = self.search_entry.get()
        self.load_students(search_term)
    
    def _add_student(self):
        """Ouvre la fenêtre d'ajout d'un étudiant."""
        self.add_window = tk.Toplevel(self)
        self.add_window.title("Ajouter un étudiant")
        self.add_window.geometry("400x500")
        self.add_window.resizable(False, False)
        self.add_window.configure(bg=COLORS["bg_white"])
        
        # Centrer la fenêtre
        self.add_window.update_idletasks()
        width = self.add_window.winfo_width()
        height = self.add_window.winfo_height()
        x = (self.add_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.add_window.winfo_screenheight() // 2) - (height // 2)
        self.add_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Création du formulaire
        form_frame = tk.Frame(self.add_window, bg=COLORS["bg_white"], padx=20, pady=20)
        form_frame.pack(fill="both", expand=True)
        
        # Titre
        title = tk.Label(
            form_frame,
            text="Ajouter un étudiant",
            font=FONTS["title"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Nom de l'étudiant
        self.student_name_entry = LabeledEntry(form_frame, "Nom de l'étudiant")
        self.student_name_entry.pack(fill="x", pady=5)
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        promotion_frame.pack(fill="x", pady=5)
        
        promotion_label = tk.Label(
            promotion_frame,
            text="Promotion",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        promotion_label.pack(fill="x", pady=(5, 2))
        
        self.promotion_combobox = PromotionCombobox(promotion_frame)
        self.promotion_combobox.pack(fill="x", ipady=4)
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        add_btn = PrimaryButton(
            buttons_frame,
            text="Ajouter",
            command=self._save_student
        )
        add_btn.pack(side="right", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=self.add_window.destroy
        )
        cancel_btn.pack(side="right")
    
    def _save_student(self):
        """Enregistre un nouvel étudiant."""
        student_name = self.student_name_entry.get()
        promotion = self.promotion_combobox.get()
        
        if not student_name or not promotion:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        # Ajout de l'étudiant
        if dh.add_student(student_name, promotion):
            messagebox.showinfo("Succès", "Étudiant ajouté avec succès.")
            self.add_window.destroy()
            self.load_students()
        else:
            messagebox.showerror("Erreur", "Un étudiant avec ce nom existe déjà.")
    
    def _edit_student(self):
        """Ouvre la fenêtre de modification d'un étudiant."""
        selected_items = self.students_table.selection()
        if not selected_items:
            messagebox.showinfo("Information", "Veuillez sélectionner un étudiant à modifier.")
            return
        
        # Récupérer les valeurs de l'étudiant sélectionné
        item = selected_items[0]
        student_name, promotion = self.students_table.item(item, "values")
        
        # Fenêtre de modification
        self.edit_window = tk.Toplevel(self)
        self.edit_window.title("Modifier un étudiant")
        self.edit_window.geometry("400x500")
        self.edit_window.resizable(False, False)
        self.edit_window.configure(bg=COLORS["bg_white"])
        
        # Centrer la fenêtre
        self.edit_window.update_idletasks()
        width = self.edit_window.winfo_width()
        height = self.edit_window.winfo_height()
        x = (self.edit_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.edit_window.winfo_screenheight() // 2) - (height // 2)
        self.edit_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Création du formulaire
        form_frame = tk.Frame(self.edit_window, bg=COLORS["bg_white"], padx=20, pady=20)
        form_frame.pack(fill="both", expand=True)
        
        # Titre
        title = tk.Label(
            form_frame,
            text="Modifier un étudiant",
            font=FONTS["title"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Nom de l'étudiant
        self.edit_student_name_entry = LabeledEntry(form_frame, "Nom de l'étudiant")
        self.edit_student_name_entry.set(student_name)
        self.edit_student_name_entry.pack(fill="x", pady=5)
        
        # Promotion
        promotion_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        promotion_frame.pack(fill="x", pady=5)
        
        promotion_label = tk.Label(
            promotion_frame,
            text="Promotion",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        promotion_label.pack(fill="x", pady=(5, 2))
        
        self.edit_promotion_combobox = PromotionCombobox(promotion_frame)
        self.edit_promotion_combobox.set(promotion)
        self.edit_promotion_combobox.pack(fill="x", ipady=4)
        
        # Variable cachée pour l'identification
        self.old_student_name = student_name
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x", side="bottom")
        
        save_btn = PrimaryButton(
            buttons_frame,
            text="Enregistrer",
            command=self._update_student
        )
        save_btn.pack(side="left", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=self.edit_window.destroy
        )
        cancel_btn.pack(side="left")
    
    def _update_student(self):
        """Met à jour un étudiant existant."""
        new_name = self.edit_student_name_entry.get()
        promotion = self.edit_promotion_combobox.get()
        
        if not new_name or not promotion:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        # Mise à jour de l'étudiant
        if dh.update_student(self.old_student_name, new_name, promotion):
            messagebox.showinfo("Succès", "Étudiant mis à jour avec succès.")
            self.edit_window.destroy()
            self.load_students()
        else:
            messagebox.showerror("Erreur", "Impossible de mettre à jour l'étudiant.")
    
    def _delete_student(self):
        """Supprime un étudiant."""
        selected_items = self.students_table.selection()
        if not selected_items:
            messagebox.showinfo("Information", "Veuillez sélectionner un étudiant à supprimer.")
            return
        
        # Récupérer le nom de l'étudiant sélectionné
        item = selected_items[0]
        student_name = self.students_table.item(item, "values")[0]
        
        # Demander confirmation
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer l'étudiant '{student_name}' ?\nCela supprimera également toutes ses cotes."):
            if dh.delete_student(student_name):
                messagebox.showinfo("Succès", "Étudiant supprimé avec succès.")
                self.load_students()
            else:
                messagebox.showerror("Erreur", "Impossible de supprimer l'étudiant.")
    
    def _on_student_select(self, event):
        """Gère l'événement de sélection d'un étudiant dans le tableau."""
        selected_items = self.students_table.selection()
        if selected_items:
            self.edit_btn.config(state="normal")
            self.delete_btn.config(state="normal")
        else:
            self.edit_btn.config(state="disabled")
            self.delete_btn.config(state="disabled")
