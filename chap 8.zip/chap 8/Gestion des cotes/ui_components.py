# ui_components.py - Composants réutilisables pour l'interface utilisateur
import tkinter as tk
from tkinter import ttk
from config import COLORS, FONTS, PROMOTIONS

class SidebarButton(tk.Button):
    """Bouton personnalisé pour la barre latérale."""
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent,
            text=text,
            font=FONTS["button"],
            bg=COLORS["sidebar_bg"],
            fg=COLORS["text_light"],
            activebackground=COLORS["sidebar_hover"],
            activeforeground=COLORS["text_light"],
            bd=0,
            padx=20,
            pady=10,
            anchor="w",
            cursor="hand2",
            command=command,
            **kwargs
        )
        
        # Binding pour changer la couleur au survol
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
    
    def _on_enter(self, e):
        self.config(background=COLORS["sidebar_hover"])
        
    def _on_leave(self, e):
        self.config(background=COLORS["sidebar_bg"])

class PrimaryButton(tk.Button):
    """Bouton principal de l'application."""
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent,
            text=text,
            font=FONTS["button"],
            bg=COLORS["btn_primary"],
            fg=COLORS["text_light"],
            activebackground=COLORS["sidebar_hover"],
            activeforeground=COLORS["text_light"],
            bd=0,
            padx=15,
            pady=8,
            cursor="hand2",
            command=command,
            **kwargs
        )

class SecondaryButton(tk.Button):
    """Bouton secondaire de l'application."""
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent,
            text=text,
            font=FONTS["button"],
            bg=COLORS["btn_secondary"],
            fg=COLORS["text_light"],
            activebackground="#2E7D32",
            activeforeground=COLORS["text_light"],
            bd=0,
            padx=15,
            pady=8,
            cursor="hand2",
            command=command,
            **kwargs
        )

class DangerButton(tk.Button):
    """Bouton pour les actions dangereuses."""
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent,
            text=text,
            font=FONTS["button"],
            bg=COLORS["btn_danger"],
            fg=COLORS["text_light"],
            activebackground="#c0392b",
            activeforeground=COLORS["text_light"],
            bd=0,
            padx=15,
            pady=8,
            cursor="hand2",
            command=command,
            **kwargs
        )

class LabeledEntry(tk.Frame):
    """Champ d'entrée avec un libellé."""
    def __init__(self, parent, label_text, **kwargs):
        super().__init__(parent, bg=parent["bg"])
        
        self.label = tk.Label(
            self,
            text=label_text,
            font=FONTS["main"],
            bg=self["bg"],
            anchor="w"
        )
        self.label.pack(fill="x", pady=(5, 2))
        
        self.entry = tk.Entry(
            self,
            font=FONTS["main"],
            bd=1,
            relief="solid",
            **kwargs
        )
        self.entry.pack(fill="x", ipady=5)
    
    def get(self):
        """Récupère la valeur de l'entrée."""
        return self.entry.get()
    
    def set(self, value):
        """Définit la valeur de l'entrée."""
        self.entry.delete(0, tk.END)
        self.entry.insert(0, value)

class CustomTreeview(ttk.Treeview):
    """Treeview personnalisé avec des styles cohérents."""
    def __init__(self, parent, columns, **kwargs):
        # Style personnalisé pour le Treeview
        style = ttk.Style()
        style.configure("Treeview", 
                        background=COLORS["bg_white"],
                        fieldbackground=COLORS["bg_white"],
                        foreground=COLORS["text_dark"],
                        font=FONTS["main"])
        
        style.configure("Treeview.Heading",
                        background=COLORS["header_bg"],
                        foreground=COLORS["text_light"],
                        font=FONTS["header"])
        
        # Pour les lignes alternées
        style.map('Treeview', background=[('selected', '#3498db')])
        
        super().__init__(
            parent,
            columns=columns,
            style="Treeview",
            **kwargs
        )
        
        # Configure l'alternance des couleurs de ligne
        self.tag_configure('oddrow', background='#f0f0f0')
        self.tag_configure('evenrow', background=COLORS["bg_white"])

class PromotionCombobox(ttk.Combobox):
    """Combobox prédéfinie pour les promotions."""
    def __init__(self, parent, **kwargs):
        self.var = tk.StringVar()
        
        super().__init__(
            parent,
            textvariable=self.var,
            values=PROMOTIONS,
            font=FONTS["main"],
            state="readonly",
            **kwargs
        )
        
        # Sélectionner la première promotion par défaut
        if PROMOTIONS:
            self.current(0)
    
    def get(self):
        """Récupère la promotion sélectionnée."""
        return self.var.get()
    
    def set(self, value):
        """Définit la promotion sélectionnée."""
        if value in PROMOTIONS:
            index = PROMOTIONS.index(value)
            self.current(index)

class Sidebar(tk.Frame):
    """Barre latérale standard pour l'application."""
    def __init__(self, parent, navigate_callback):
        super().__init__(
            parent,
            bg=COLORS["sidebar_bg"],
            width=200
        )
        
        self.navigate_callback = navigate_callback
        
        # Logo ou titre en haut de la sidebar
        title_frame = tk.Frame(self, bg=COLORS["sidebar_bg"], pady=20)
        title_frame.pack(fill="x")
        
        title_label = tk.Label(
            title_frame,
            text="Gestion Université",
            font=FONTS["title"],
            bg=COLORS["sidebar_bg"],
            fg=COLORS["text_light"]
        )
        title_label.pack(fill="x")
        
        # Boutons de navigation
        self.btn_grades = SidebarButton(
            self,
            text="Liste des étudiants",
            command=lambda: navigate_callback("students_list")
        )
        self.btn_grades.pack(fill="x")
        
        self.btn_grades_mgmt = SidebarButton(
            self,
            text="Gestion des cotes",
            command=lambda: navigate_callback("grades_management")
        )
        self.btn_grades_mgmt.pack(fill="x")
        
        self.btn_courses = SidebarButton(
            self,
            text="Gestion des cours",
            command=lambda: navigate_callback("courses_management")
        )
        self.btn_courses.pack(fill="x")
        
        self.btn_settings = SidebarButton(
            self,
            text="Paramètres du compte",
            command=lambda: navigate_callback("account_settings")
        )
        self.btn_settings.pack(fill="x")
        
        # Espacement pour le bouton de déconnexion en bas
        spacer = tk.Frame(self, bg=COLORS["sidebar_bg"])
        spacer.pack(fill="both", expand=True)
        
        self.btn_logout = SidebarButton(
            self,
            text="Se déconnecter",
            command=lambda: navigate_callback("logout")
        )
        self.btn_logout.pack(fill="x", side="bottom", pady=(0, 20))

def validate_numeric_input(action, value_if_allowed):
    """Validateur pour les entrées numériques uniquement."""
    if action == '1':  # insertion
        if value_if_allowed == "":
            return True
        try:
            float(value_if_allowed)
            return True
        except ValueError:
            return False
    return True
