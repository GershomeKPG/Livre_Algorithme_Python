# config.py - Configuration et constantes pour l'application

# Couleurs
COLORS = {
    "bg_light": "#f7f7f7",           # Fond principal clair
    "bg_white": "#ffffff",            # Fond blanc
    "sidebar_bg": "#2C3E50",          # Bleu nuit pour la barre latérale
    "sidebar_hover": "#34495E",       # Bleu clair pour survol des boutons
    "header_bg": "#34495E",           # Bleu foncé pour les en-têtes (modifié)
    "btn_primary": "#00796B",         # Bleu soutenu pour boutons principaux
    "btn_secondary": "#388E3C",       # Vert soutenu pour boutons secondaires
    "login_gradient_start": "#E0F7FA", # Dégradé bleu clair (haut)
    "login_gradient_end": "#B2EBF2",   # Dégradé bleu clair (bas)
    "signup_gradient_start": "#E8F5E9", # Dégradé vert clair (haut)
    "signup_gradient_end": "#C8E6C9",   # Dégradé vert clair (bas)
    "btn_danger": "#e74c3c",          # Rouge pour actions dangereuses
    "text_dark": "#333333",           # Texte foncé
    "text_light": "#ffffff",          # Texte clair
    "border_light": "#dddddd",        # Bordures légères
}

# Polices
FONTS = {
    "main": ("Segoe UI", 10),
    "title": ("Segoe UI", 16, "bold"),
    "subtitle": ("Segoe UI", 12, "bold"),
    "button": ("Segoe UI", 10),
    "header": ("Segoe UI", 11, "bold"),
}

# Chemins des fichiers
USERS_CSV = "utilisateurs.csv"
COURSES_CSV = "cours.csv"
STUDENTS_CSV = "etudiants.csv"
GRADES_CSV = "cotes.csv"

# Statuts
STATUS = {
    "pass": "Admis",
    "fail": "Ajourné",
}

# Seuil de réussite (moyenne minimale pour être admis)
PASS_THRESHOLD = 10

# Promotions prédéfinies
PROMOTIONS = ["L1", "L2", "L3", "M1", "M2"]
