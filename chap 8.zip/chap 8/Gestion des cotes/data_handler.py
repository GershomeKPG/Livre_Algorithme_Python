# data_handler.py - Gestion des données CSV
import csv
import os
import hashlib
from config import USERS_CSV, COURSES_CSV, GRADES_CSV, STUDENTS_CSV

def ensure_files_exist():
    """Vérifie que tous les fichiers CSV existent, les crée si nécessaire."""
    for file_path in [USERS_CSV, COURSES_CSV, GRADES_CSV, STUDENTS_CSV]:
        if not os.path.exists(file_path):
            create_csv_file(file_path)

def create_csv_file(file_path):
    """Crée un fichier CSV avec les en-têtes appropriés."""
    headers = {
        USERS_CSV: ["username", "password"],
        COURSES_CSV: ["course_name", "credits", "promotion"],
        STUDENTS_CSV: ["student_name", "promotion"],
        GRADES_CSV: ["student_name", "course", "interrogation", "exam", "average", "status"]
    }
    
    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(headers[file_path])

def read_csv(file_path):
    """Lit un fichier CSV et retourne ses données."""
    if not os.path.exists(file_path):
        create_csv_file(file_path)
        return []
    
    with open(file_path, 'r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        return list(reader)

def write_csv(file_path, data, fieldnames=None):
    """Écrit des données dans un fichier CSV."""
    if not fieldnames:
        # Détermine automatiquement les fieldnames à partir du premier élément
        if data and len(data) > 0:
            fieldnames = data[0].keys()
        else:
            return False
    
    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)
    return True

def hash_password(password):
    """Hachage du mot de passe avec SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

# Fonctions spécifiques pour les utilisateurs
def authenticate_user(username, password):
    """Authentifie un utilisateur."""
    users = read_csv(USERS_CSV)
    for user in users:
        if user["username"] == username and user["password"] == hash_password(password):
            return True
    return False

def register_user(username, password):
    """Enregistre un nouvel utilisateur."""
    users = read_csv(USERS_CSV)
    
    # Vérifie si l'utilisateur existe déjà
    for user in users:
        if user["username"] == username:
            return False
    
    # Ajoute le nouvel utilisateur
    users.append({
        "username": username,
        "password": hash_password(password)
    })
    
    return write_csv(USERS_CSV, users)

def update_user_password(username, new_password):
    """Met à jour le mot de passe d'un utilisateur."""
    users = read_csv(USERS_CSV)
    
    for user in users:
        if user["username"] == username:
            user["password"] = hash_password(new_password)
            return write_csv(USERS_CSV, users)
    
    return False

# Fonctions spécifiques pour les cours
def get_all_courses():
    """Récupère tous les cours."""
    return read_csv(COURSES_CSV)

def get_courses_by_promotion(promotion):
    """Récupère tous les cours d'une promotion."""
    courses = read_csv(COURSES_CSV)
    return [course for course in courses if course["promotion"] == promotion]

def add_course(course_name, credits, promotion):
    """Ajoute un nouveau cours."""
    courses = read_csv(COURSES_CSV)
    
    # Vérifie si le cours existe déjà
    for course in courses:
        if course["course_name"] == course_name and course["promotion"] == promotion:
            return False
    
    # Ajoute le nouveau cours
    courses.append({
        "course_name": course_name,
        "credits": credits,
        "promotion": promotion
    })
    
    return write_csv(COURSES_CSV, courses)

def update_course(old_name, new_name, credits, promotion):
    """Met à jour un cours existant."""
    courses = read_csv(COURSES_CSV)
    
    for course in courses:
        if course["course_name"] == old_name:
            course["course_name"] = new_name
            course["credits"] = credits
            course["promotion"] = promotion
            return write_csv(COURSES_CSV, courses)
    
    return False

def delete_course(course_name):
    """Supprime un cours."""
    courses = read_csv(COURSES_CSV)
    
    for i, course in enumerate(courses):
        if course["course_name"] == course_name:
            del courses[i]
            return write_csv(COURSES_CSV, courses)
    
    return False

# Fonctions spécifiques pour les étudiants
def get_all_students():
    """Récupère tous les étudiants."""
    return read_csv(STUDENTS_CSV)

def get_students_by_promotion(promotion):
    """Récupère tous les étudiants d'une promotion."""
    students = read_csv(STUDENTS_CSV)
    return [student for student in students if student["promotion"] == promotion]

def add_student(student_name, promotion):
    """Ajoute un nouvel étudiant."""
    students = read_csv(STUDENTS_CSV)
    
    # Vérifie si l'étudiant existe déjà
    for student in students:
        if student["student_name"] == student_name:
            return False
    
    # Ajoute le nouvel étudiant
    students.append({
        "student_name": student_name,
        "promotion": promotion
    })
    
    return write_csv(STUDENTS_CSV, students)

def update_student(old_name, new_name, promotion):
    """Met à jour un étudiant existant."""
    students = read_csv(STUDENTS_CSV)
    
    for student in students:
        if student["student_name"] == old_name:
            student["student_name"] = new_name
            student["promotion"] = promotion
            
            # Mettre également à jour les cotes associées
            grades = read_csv(GRADES_CSV)
            for grade in grades:
                if grade["student_name"] == old_name:
                    grade["student_name"] = new_name
            
            write_csv(GRADES_CSV, grades)
            return write_csv(STUDENTS_CSV, students)
    
    return False

def delete_student(student_name):
    """Supprime un étudiant."""
    students = read_csv(STUDENTS_CSV)
    
    for i, student in enumerate(students):
        if student["student_name"] == student_name:
            del students[i]
            
            # Supprimer également les cotes associées
            grades = read_csv(GRADES_CSV)
            grades = [grade for grade in grades if grade["student_name"] != student_name]
            write_csv(GRADES_CSV, grades)
            
            return write_csv(STUDENTS_CSV, students)
    
    return False

# Fonctions spécifiques pour les cotes/notes
def get_all_grades():
    """Récupère toutes les notes."""
    return read_csv(GRADES_CSV)

def get_grades_by_student(student_name):
    """Récupère toutes les notes d'un étudiant."""
    grades = read_csv(GRADES_CSV)
    return [grade for grade in grades if grade["student_name"] == student_name]

def add_grade(student_name, course, interrogation, exam):
    """Ajoute une nouvelle note pour un étudiant dans un cours."""
    grades = read_csv(GRADES_CSV)
    
    # Calcul de la moyenne et du statut
    total = float(interrogation) + float(exam)
    average = total / 2  # Sur 10
    status = "Admis" if average >= 5 else "Ajourné"  # seuil de 5/10 (10/20)
    
    # Vérifie si cette combinaison étudiant/cours existe déjà
    for grade in grades:
        if grade["student_name"] == student_name and grade["course"] == course:
            return False
    
    # Ajoute la nouvelle note
    grades.append({
        "student_name": student_name,
        "course": course,
        "interrogation": interrogation,
        "exam": exam,
        "average": str(average),
        "status": status
    })
    
    return write_csv(GRADES_CSV, grades)

def update_grade(student_name, course, interrogation, exam):
    """Met à jour une note existante."""
    grades = read_csv(GRADES_CSV)
    
    # Calcul de la moyenne et du statut
    total = float(interrogation) + float(exam)
    average = total / 2  # Sur 10
    status = "Admis" if average >= 5 else "Ajourné"  # seuil de 5/10 (10/20)
    
    for grade in grades:
        if grade["student_name"] == student_name and grade["course"] == course:
            grade["interrogation"] = interrogation
            grade["exam"] = exam
            grade["average"] = str(average)
            grade["status"] = status
            return write_csv(GRADES_CSV, grades)
    
    return False

def delete_grade(student_name, course):
    """Supprime une note."""
    grades = read_csv(GRADES_CSV)
    
    for i, grade in enumerate(grades):
        if grade["student_name"] == student_name and grade["course"] == course:
            del grades[i]
            return write_csv(GRADES_CSV, grades)
    
    return False

def calculate_student_average(student_name, weighted=True):
    """Calcule la moyenne générale d'un étudiant."""
    grades = read_csv(GRADES_CSV)
    courses = {course["course_name"]: int(course["credits"]) for course in read_csv(COURSES_CSV)}
    
    student_grades = [grade for grade in grades if grade["student_name"] == student_name]
    
    if not student_grades:
        return 0
    
    if weighted:
        total_weighted_score = 0
        total_credits = 0
        
        for grade in student_grades:
            course_name = grade["course"]
            if course_name in courses:
                credits = courses[course_name]
                average = float(grade["average"])
                total_weighted_score += average * credits
                total_credits += credits
        
        if total_credits == 0:
            return 0
        
        return total_weighted_score / total_credits
    else:
        # Moyenne simple
        return sum(float(grade["average"]) for grade in student_grades) / len(student_grades)

def get_student_status(student_name, weighted=True):
    """Détermine si un étudiant est admis ou ajourné en fonction de sa moyenne générale."""
    from config import PASS_THRESHOLD
    
    average = calculate_student_average(student_name, weighted)
    return "Admis" if average >= (PASS_THRESHOLD / 2) else "Ajourné"
