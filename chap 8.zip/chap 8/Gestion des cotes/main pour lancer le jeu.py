# main.py - Point d'entrée principal de l'application
import tkinter as tk
from tkinter import messagebox
import data_handler as dh
from config import COLORS, FONTS
from ui_components import Sidebar, PrimaryButton, SecondaryButton
from login_manager import LoginFrame, RegisterFrame, AccountSettingsFrame
from course_manager import CoursesManagementFrame
from student_manager import StudentsListFrame
from grade_manager import GradesManagementFrame

class UniversityGradesApp:
    """systeme de gestion d'une université."""
    def __init__(self, root):
        self.root = root
        self.root.title("Gestion des cotes universitaires")
        self.root.geometry("1200x700")
        self.root.minsize(800, 600)
        
        # S'assurer que les fichiers CSV existent
        dh.ensure_files_exist()
        
        # Utilisateur actuellement connecté
        self.current_user = None
        
        # Cadre principal (contient toutes les pages)
        self.main_frame = tk.Frame(root)
        self.main_frame.pack(fill="both", expand=True)
        
        # Initialisation de l'interface de connexion
        self.show_login()
    
    def show_login(self):
        """Affiche la page de connexion."""
        self._clear_main_frame()
        self.login_frame = LoginFrame(
            self.main_frame,
            self._handle_login,
            self.show_register
        )
        self.login_frame.pack(fill="both", expand=True)
    
    def show_register(self):
        """Affiche la page d'inscription."""
        self._clear_main_frame()
        self.register_frame = RegisterFrame(
            self.main_frame,
            self.show_login,
            self.show_login
        )
        self.register_frame.pack(fill="both", expand=True)
    
    def _handle_login(self, username):
        """Gère la connexion réussie."""
        self.current_user = username
        self.show_home()
    
    def show_home(self):
        """Affiche la page d'accueil après connexion."""
        self._clear_main_frame()
        
        # Mise en place de la disposition principale
        self.content_frame = tk.Frame(self.main_frame)
        self.content_frame.pack(fill="both", expand=True)
        
        # Barre latérale
        self.sidebar = Sidebar(self.content_frame, self._navigate)
        self.sidebar.pack(side="left", fill="y")
        
        # Zone de contenu principal
        self.home_content = tk.Frame(self.content_frame, bg=COLORS["bg_light"])
        self.home_content.pack(side="right", fill="both", expand=True)
        
        # Contenu de la page d'accueil
        welcome_frame = tk.Frame(self.home_content, bg=COLORS["bg_light"], pady=50)
        welcome_frame.pack(fill="x")
        
        welcome_label = tk.Label(
            welcome_frame,
            text=f"Bienvenue, {self.current_user} !",
            font=FONTS["title"],
            bg=COLORS["bg_light"]
        )
        welcome_label.pack()
        
        # Tuiles pour les actions principales
        tiles_frame = tk.Frame(self.home_content, bg=COLORS["bg_light"], padx=50, pady=20)
        tiles_frame.pack(fill="both", expand=True)
        
        # Configurer la grille
        tiles_frame.columnconfigure(0, weight=1)
        tiles_frame.columnconfigure(1, weight=1)
        tiles_frame.rowconfigure(0, weight=1)
        tiles_frame.rowconfigure(1, weight=1)
        
        # Tuile - Liste des étudiants
        students_tile = tk.Frame(tiles_frame, bg="#3498db", padx=30, pady=30, bd=1, relief="solid")
        students_tile.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        students_label = tk.Label(
            students_tile,
            text="Liste des étudiants",
            font=FONTS["subtitle"],
            bg="#3498db",
            fg=COLORS["text_light"]
        )
        students_label.pack(pady=(0, 15))
        
        students_btn = PrimaryButton(
            students_tile,
            text="Accéder",
            command=lambda: self._navigate("students_list")
        )
        students_btn.pack()
        
        # Tuile - Gestion des cotes
        grades_tile = tk.Frame(tiles_frame, bg="#f39c12", padx=30, pady=30, bd=1, relief="solid")
        grades_tile.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        grades_label = tk.Label(
            grades_tile,
            text="Gestion des cotes",
            font=FONTS["subtitle"],
            bg="#f39c12",
            fg=COLORS["text_light"]
        )
        grades_label.pack(pady=(0, 15))
        
        grades_btn = PrimaryButton(
            grades_tile,
            text="Accéder",
            command=lambda: self._navigate("grades_management")
        )
        grades_btn.pack()
        
        # Tuile - Gestion des cours
        courses_tile = tk.Frame(tiles_frame, bg="#2ecc71", padx=30, pady=30, bd=1, relief="solid")
        courses_tile.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
        
        courses_label = tk.Label(
            courses_tile,
            text="Gestion des cours",
            font=FONTS["subtitle"],
            bg="#2ecc71",
            fg=COLORS["text_light"]
        )
        courses_label.pack(pady=(0, 15))
        
        courses_btn = PrimaryButton(
            courses_tile,
            text="Accéder",
            command=lambda: self._navigate("courses_management")
        )
        courses_btn.pack()
        
        # Tuile - Paramètres du compte
        settings_tile = tk.Frame(tiles_frame, bg="#e67e22", padx=30, pady=30, bd=1, relief="solid")
        settings_tile.grid(row=1, column=1, padx=10, pady=10, sticky="nsew")
        
        settings_label = tk.Label(
            settings_tile,
            text="Paramètres du compte",
            font=FONTS["subtitle"],
            bg="#e67e22",
            fg=COLORS["text_light"]
        )
        settings_label.pack(pady=(0, 15))
        
        settings_btn = PrimaryButton(
            settings_tile,
            text="Accéder",
            command=lambda: self._navigate("account_settings")
        )
        settings_btn.pack()
    
    def _navigate(self, destination):
        """Gère la navigation entre les pages."""
        if destination == "home":
            self.show_home()
        
        elif destination == "students_list":
            self._clear_content_area()
            students_list = StudentsListFrame(self.home_content)
            students_list.pack(fill="both", expand=True)
        
        elif destination == "grades_management":
            self._clear_content_area()
            grades_management = GradesManagementFrame(self.home_content)
            grades_management.pack(fill="both", expand=True)
        
        elif destination == "courses_management":
            self._clear_content_area()
            courses_management = CoursesManagementFrame(self.home_content)
            courses_management.pack(fill="both", expand=True)
        
        elif destination == "account_settings":
            self._clear_content_area()
            account_settings = AccountSettingsFrame(
                self.home_content,
                self.current_user,
                self._navigate
            )
            account_settings.pack(fill="both", expand=True)
        
        elif destination == "logout":
            if messagebox.askyesno("Déconnexion", "Voulez-vous vraiment vous déconnecter ?"):
                self.current_user = None
                self.show_login()
    
    def _clear_main_frame(self):
        """Nettoie le cadre principal."""
        for widget in self.main_frame.winfo_children():
            widget.destroy()
    
    def _clear_content_area(self):
        """Nettoie la zone de contenu principal."""
        for widget in self.home_content.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = UniversityGradesApp(root)
    root.mainloop()
