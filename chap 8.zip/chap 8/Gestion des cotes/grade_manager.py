# grade_manager.py - Gestion des cotes/notes
import tkinter as tk
from tkinter import ttk, messagebox
import data_handler as dh
from config import COLORS, FONTS, PROMOTIONS
from ui_components import PrimaryButton, SecondaryButton, DangerButton, LabeledEntry, CustomTreeview, validate_numeric_input, PromotionCombobox

class GradesManagementFrame(tk.Frame):
    """Cadre pour la gestion des cotes."""
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg_light"])
        
        # Titre de la page
        title_frame = tk.Frame(self, bg=COLORS["bg_light"], pady=20)
        title_frame.pack(fill="x")
        
        title = tk.Label(
            title_frame,
            text="Gestion des cotes",
            font=FONTS["title"],
            bg=COLORS["bg_light"]
        )
        title.pack()
        
        # Zone de sélection de promotion
        selection_frame = tk.Frame(self, bg=COLORS["bg_white"], padx=20, pady=15, bd=1, relief="solid")
        selection_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        # Sélection de promotion
        promotion_label = tk.Label(
            selection_frame,
            text="Sélectionner une promotion:",
            font=FONTS["main"],
            bg=COLORS["bg_white"]
        )
        promotion_label.pack(side="left", padx=(0, 10))
        
        self.promotion_combobox = PromotionCombobox(selection_frame)
        self.promotion_combobox.pack(side="left", padx=(0, 10))
        
        load_btn = PrimaryButton(
            selection_frame,
            text="Charger",
            command=self._load_promotion_data
        )
        load_btn.pack(side="left")
        
        # Zone principale
        self.main_frame = tk.Frame(self, bg=COLORS["bg_light"])
        self.main_frame.pack(padx=20, pady=10, fill="both", expand=True)
        
        # Zone pour afficher les étudiants et leurs cotes (sera remplie après sélection)
        self.students_frame = tk.Frame(self.main_frame, bg=COLORS["bg_white"], padx=20, pady=20, bd=1, relief="solid")
        self.students_frame.pack(fill="both", expand=True)
        
        # Message initial
        self.initial_message = tk.Label(
            self.students_frame,
            text="Veuillez sélectionner une promotion et cliquer sur 'Charger'",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"],
            pady=50
        )
        self.initial_message.pack()
    
    def _load_promotion_data(self):
        """Charge les données des étudiants de la promotion sélectionnée."""
        promotion = self.promotion_combobox.get()
        if not promotion:
            messagebox.showinfo("Information", "Veuillez sélectionner une promotion.")
            return
        
        # Récupérer les étudiants de cette promotion
        students = dh.get_students_by_promotion(promotion)
        
        # Récupérer les cours de cette promotion
        courses = dh.get_courses_by_promotion(promotion)
        
        # Nettoyer la frame principale
        for widget in self.students_frame.winfo_children():
            widget.destroy()
        
        if not students:
            # Aucun étudiant dans cette promotion
            no_students_label = tk.Label(
                self.students_frame,
                text=f"Aucun étudiant dans la promotion {promotion}",
                font=FONTS["subtitle"],
                bg=COLORS["bg_white"],
                pady=50
            )
            no_students_label.pack()
            return
        
        if not courses:
            # Aucun cours pour cette promotion
            no_courses_label = tk.Label(
                self.students_frame,
                text=f"Aucun cours défini pour la promotion {promotion}",
                font=FONTS["subtitle"],
                bg=COLORS["bg_white"],
                pady=50
            )
            no_courses_label.pack()
            return
        
        # Titre
        promotion_title = tk.Label(
            self.students_frame,
            text=f"Gestion des cotes - Promotion {promotion}",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        promotion_title.pack(anchor="w", pady=(0, 15))
        
        # Tableau des étudiants et leurs cotes
        self.grades_table = CustomTreeview(
            self.students_frame,
            columns=["student_name"] + [course["course_name"] for course in courses],
            show="headings",
            selectmode="browse",
            height=15
        )
        
        # Configuration des colonnes
        self.grades_table.heading("student_name", text="Nom de l'étudiant")
        self.grades_table.column("student_name", width=200, anchor="w")
        
        for course in courses:
            course_name = course["course_name"]
            self.grades_table.heading(course_name, text=course_name)
            self.grades_table.column(course_name, width=150, anchor="center")
        
        # Récupérer toutes les cotes
        grades = dh.get_all_grades()
        
        # Ajouter chaque étudiant avec ses cotes
        for i, student in enumerate(students):
            student_name = student["student_name"]
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            
            # Préparer les valeurs pour chaque cours
            values = [student_name]
            
            for course in courses:
                course_name = course["course_name"]
                # Chercher la cote pour ce cours
                grade_found = False
                for grade in grades:
                    if grade["student_name"] == student_name and grade["course"] == course_name:
                        average = float(grade["average"])
                        values.append(f"{average:.2f}/10")
                        grade_found = True
                        break
                
                if not grade_found:
                    values.append("N/A")
            
            self.grades_table.insert("", "end", values=values, tags=(tag,))
        
        # Barre de défilement
        scrollbar = ttk.Scrollbar(self.students_frame, orient="vertical", command=self.grades_table.yview)
        self.grades_table.configure(yscrollcommand=scrollbar.set)
        
        # Placement du tableau et de la barre de défilement
        self.grades_table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Boutons d'action
        buttons_frame = tk.Frame(self.students_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        self.add_grade_btn = PrimaryButton(
            buttons_frame,
            text="Ajouter une cote",
            command=self._add_grade
        )
        self.add_grade_btn.pack(side="left", padx=(0, 5))
        
        self.edit_grade_btn = SecondaryButton(
            buttons_frame,
            text="Modifier une cote",
            command=self._edit_grade
        )
        self.edit_grade_btn.pack(side="left", padx=(0, 5))
        
        # Liaison d'événement pour la sélection dans le tableau
        self.grades_table.bind("<<TreeviewSelect>>", self._on_grade_select)
        
        # Variables pour stocker les données actuelles
        self.current_promotion = promotion
        self.current_courses = courses
        self.current_students = students
    
    def _add_grade(self):
        """Ouvre la fenêtre d'ajout d'une cote."""
        if not hasattr(self, 'current_promotion') or not self.current_promotion:
            messagebox.showinfo("Information", "Veuillez d'abord charger une promotion.")
            return
        
        # Fenêtre d'ajout
        self.add_window = tk.Toplevel(self)
        self.add_window.title("Ajouter une cote")
        self.add_window.geometry("400x500")
        self.add_window.resizable(False, False)
        self.add_window.configure(bg=COLORS["bg_white"])
        
        # Centrer la fenêtre
        self.add_window.update_idletasks()
        width = self.add_window.winfo_width()
        height = self.add_window.winfo_height()
        x = (self.add_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.add_window.winfo_screenheight() // 2) - (height // 2)
        self.add_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Création du formulaire
        form_frame = tk.Frame(self.add_window, bg=COLORS["bg_white"], padx=20, pady=20)
        form_frame.pack(fill="both", expand=True)
        
        # Titre
        title = tk.Label(
            form_frame,
            text=f"Ajouter une cote - {self.current_promotion}",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Sélection de l'étudiant
        student_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        student_frame.pack(fill="x", pady=5)
        
        student_label = tk.Label(
            student_frame,
            text="Étudiant",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        student_label.pack(fill="x", pady=(0, 2))
        
        student_names = [student["student_name"] for student in self.current_students]
        self.student_var = tk.StringVar()
        self.student_combobox = ttk.Combobox(
            student_frame,
            textvariable=self.student_var,
            values=student_names,
            font=FONTS["main"],
            state="readonly"
        )
        self.student_combobox.pack(fill="x", ipady=4)
        if student_names:
            self.student_combobox.current(0)
        
        # Sélection du cours
        course_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        course_frame.pack(fill="x", pady=5)
        
        course_label = tk.Label(
            course_frame,
            text="Cours",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        course_label.pack(fill="x", pady=(0, 2))
        
        course_names = [course["course_name"] for course in self.current_courses]
        self.course_var = tk.StringVar()
        self.course_combobox = ttk.Combobox(
            course_frame,
            textvariable=self.course_var,
            values=course_names,
            font=FONTS["main"],
            state="readonly"
        )
        self.course_combobox.pack(fill="x", ipady=4)
        if course_names:
            self.course_combobox.current(0)
        
        # Validation pour les champs numériques
        vcmd = (self.register(validate_numeric_input), '%d', '%P')
        
        # Notes
        notes_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        notes_frame.pack(fill="x", pady=5)
        
        # Interrogation
        self.interrogation_entry = LabeledEntry(notes_frame, "Note d'interrogation (sur 10)")
        self.interrogation_entry.entry.config(validate="key", validatecommand=vcmd)
        self.interrogation_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        # Examen
        self.exam_entry = LabeledEntry(notes_frame, "Note d'examen (sur 10)")
        self.exam_entry.entry.config(validate="key", validatecommand=vcmd)
        self.exam_entry.pack(side="left", fill="x", expand=True, padx=(5, 0))
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x",side="bottom")
        
        add_btn = PrimaryButton(
            buttons_frame,
            text="Ajouter",
            command=self._save_grade
        )
        add_btn.pack(side="left", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=self.add_window.destroy
        )
        cancel_btn.pack(side="left")
    
    def _save_grade(self):
        """Enregistre une nouvelle cote."""
        student_name = self.student_var.get()
        course = self.course_var.get()
        interrogation = self.interrogation_entry.get()
        exam = self.exam_entry.get()
        
        if not student_name or not course or not interrogation or not exam:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        try:
            interrogation = float(interrogation)
            exam = float(exam)
            
            if not (0 <= interrogation <= 10) or not (0 <= exam <= 10):
                messagebox.showerror("Erreur", "Les notes doivent être comprises entre 0 et 10.")
                return
        except ValueError:
            messagebox.showerror("Erreur", "Les notes doivent être des nombres.")
            return
        
        # Ajout de la cote
        if dh.add_grade(student_name, course, str(interrogation), str(exam)):
            messagebox.showinfo("Succès", "Cote ajoutée avec succès.")
            self.add_window.destroy()
            self._load_promotion_data()  # Recharger les données
        else:
            messagebox.showerror("Erreur", "Cet étudiant a déjà une cote pour ce cours.")
    
    def _edit_grade(self):
        """Ouvre la fenêtre de modification d'une cote."""
        if not hasattr(self, 'grades_table'):
            messagebox.showinfo("Information", "Veuillez d'abord charger une promotion.")
            return
        
        selected_items = self.grades_table.selection()
        if not selected_items:
            messagebox.showinfo("Information", "Veuillez sélectionner un étudiant.")
            return
        
        # Récupérer les valeurs de l'élément sélectionné
        item = selected_items[0]
        values = self.grades_table.item(item, "values")
        student_name = values[0]
        
        # Fenêtre pour choisir un cours
        self.course_selection_window = tk.Toplevel(self)
        self.course_selection_window.title("Sélectionner un cours")
        self.course_selection_window.geometry("300x200")
        self.course_selection_window.resizable(False, False)
        self.course_selection_window.configure(bg=COLORS["bg_white"])
        
        # Centrer la fenêtre
        self.course_selection_window.update_idletasks()
        width = self.course_selection_window.winfo_width()
        height = self.course_selection_window.winfo_height()
        x = (self.course_selection_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.course_selection_window.winfo_screenheight() // 2) - (height // 2)
        self.course_selection_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Création du formulaire
        form_frame = tk.Frame(self.course_selection_window, bg=COLORS["bg_white"], padx=20, pady=20)
        form_frame.pack(fill="both", expand=True)
        
        # Titre
        title = tk.Label(
            form_frame,
            text=f"Choisir un cours pour {student_name}",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 20))
        
        # Sélection du cours
        course_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        course_frame.pack(fill="x", pady=5)
        
        course_label = tk.Label(
            course_frame,
            text="Cours",
            font=FONTS["main"],
            bg=COLORS["bg_white"],
            anchor="w"
        )
        course_label.pack(fill="x", pady=(0, 2))
        
        course_names = [course["course_name"] for course in self.current_courses]
        self.edit_course_var = tk.StringVar()
        self.edit_course_combobox = ttk.Combobox(
            course_frame,
            textvariable=self.edit_course_var,
            values=course_names,
            font=FONTS["main"],
            state="readonly"
        )
        self.edit_course_combobox.pack(fill="x", ipady=4)
        if course_names:
            self.edit_course_combobox.current(0)
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        self.student_to_edit = student_name
        
        continue_btn = PrimaryButton(
            buttons_frame,
            text="Continuer",
            command=self._edit_grade_for_course
        )
        continue_btn.pack(side="left", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=self.course_selection_window.destroy
        )
        cancel_btn.pack(side="left")
    
    def _edit_grade_for_course(self):
        """Ouvre la fenêtre d'édition de cote pour un cours spécifique."""
        course_name = self.edit_course_var.get()
        student_name = self.student_to_edit
        
        # Fermer la fenêtre de sélection de cours
        self.course_selection_window.destroy()
        
        # Récupérer la cote existante
        grades = dh.get_all_grades()
        current_grade = None
        
        for grade in grades:
            if grade["student_name"] == student_name and grade["course"] == course_name:
                current_grade = grade
                break
        
        if not current_grade:
            # Pas de cote existante, proposer d'en créer une
            if messagebox.askyesno("Information", f"Aucune cote existante pour {student_name} dans {course_name}. Voulez-vous en créer une ?"):
                # Réutiliser la fonction d'ajout
                self._add_grade()
                # Pré-remplir l'étudiant et le cours
                if hasattr(self, 'student_combobox'):
                    student_index = [s["student_name"] for s in self.current_students].index(student_name)
                    self.student_combobox.current(student_index)
                if hasattr(self, 'course_combobox'):
                    course_index = [c["course_name"] for c in self.current_courses].index(course_name)
                    self.course_combobox.current(course_index)
            return
        
        # Fenêtre d'édition
        self.edit_window = tk.Toplevel(self)
        self.edit_window.title("Modifier une cote")
        self.edit_window.geometry("400x300")
        self.edit_window.resizable(False, False)
        self.edit_window.configure(bg=COLORS["bg_white"])
        
        # Centrer la fenêtre
        self.edit_window.update_idletasks()
        width = self.edit_window.winfo_width()
        height = self.edit_window.winfo_height()
        x = (self.edit_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.edit_window.winfo_screenheight() // 2) - (height // 2)
        self.edit_window.geometry(f"{width}x{height}+{x}+{y}")
        
        # Création du formulaire
        form_frame = tk.Frame(self.edit_window, bg=COLORS["bg_white"], padx=20, pady=20)
        form_frame.pack(fill="both", expand=True)
        
        # Titre
        title = tk.Label(
            form_frame,
            text=f"Modifier la cote de {student_name}",
            font=FONTS["subtitle"],
            bg=COLORS["bg_white"]
        )
        title.pack(pady=(0, 10))
        
        # Cours
        course_info = tk.Label(
            form_frame,
            text=f"Cours: {course_name}",
            font=FONTS["main"],
            bg=COLORS["bg_white"]
        )
        course_info.pack(pady=(0, 20))
        
        # Validation pour les champs numériques
        vcmd = (self.register(validate_numeric_input), '%d', '%P')
        
        # Notes
        notes_frame = tk.Frame(form_frame, bg=COLORS["bg_white"])
        notes_frame.pack(fill="x", pady=5)
        
        # Interrogation
        self.edit_interrogation_entry = LabeledEntry(notes_frame, "Note d'interrogation (sur 10)")
        self.edit_interrogation_entry.entry.config(validate="key", validatecommand=vcmd)
        self.edit_interrogation_entry.set(current_grade["interrogation"])
        self.edit_interrogation_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        # Examen
        self.edit_exam_entry = LabeledEntry(notes_frame, "Note d'examen (sur 10)")
        self.edit_exam_entry.entry.config(validate="key", validatecommand=vcmd)
        self.edit_exam_entry.set(current_grade["exam"])
        self.edit_exam_entry.pack(side="left", fill="x", expand=True, padx=(5, 0))
        
        # Variables cachées pour l'identification
        self.edit_student_name = student_name
        self.edit_course_name = course_name
        
        # Boutons
        buttons_frame = tk.Frame(form_frame, bg=COLORS["bg_white"], pady=15)
        buttons_frame.pack(fill="x")
        
        save_btn = PrimaryButton(
            buttons_frame,
            text="Enregistrer",
            command=self._update_grade
        )
        save_btn.pack(side="left", padx=(0, 5))
        
        delete_btn = DangerButton(
            buttons_frame,
            text="Supprimer cette cote",
            command=self._delete_grade
        )
        delete_btn.pack(side="left", padx=(0, 5))
        
        cancel_btn = SecondaryButton(
            buttons_frame,
            text="Annuler",
            command=self.edit_window.destroy
        )
        cancel_btn.pack(side="left")
    
    def _update_grade(self):
        """Met à jour une cote existante."""
        interrogation = self.edit_interrogation_entry.get()
        exam = self.edit_exam_entry.get()
        
        if not interrogation or not exam:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        
        try:
            interrogation = float(interrogation)
            exam = float(exam)
            
            if not (0 <= interrogation <= 10) or not (0 <= exam <= 10):
                messagebox.showerror("Erreur", "Les notes doivent être comprises entre 0 et 10.")
                return
        except ValueError:
            messagebox.showerror("Erreur", "Les notes doivent être des nombres.")
            return
        
        # Mise à jour de la cote
        if dh.update_grade(self.edit_student_name, self.edit_course_name, str(interrogation), str(exam)):
            messagebox.showinfo("Succès", "Cote mise à jour avec succès.")
            self.edit_window.destroy()
            self._load_promotion_data()  # Recharger les données
        else:
            messagebox.showerror("Erreur", "Impossible de mettre à jour la cote.")
    
    def _delete_grade(self):
        """Supprime une cote."""
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer la cote de {self.edit_student_name} pour {self.edit_course_name} ?"):
            if dh.delete_grade(self.edit_student_name, self.edit_course_name):
                messagebox.showinfo("Succès", "Cote supprimée avec succès.")
                self.edit_window.destroy()
                self._load_promotion_data()  # Recharger les données
            else:
                messagebox.showerror("Erreur", "Impossible de supprimer la cote.")
    
    def _on_grade_select(self, event):
        """Gère l'événement de sélection dans le tableau des cotes."""
        if hasattr(self, 'edit_grade_btn'):
            selected_items = self.grades_table.selection()
            if selected_items:
                self.edit_grade_btn.config(state="normal")
            else:
                self.edit_grade_btn.config(state="disabled")
