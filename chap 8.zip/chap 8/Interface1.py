def calculer():
    result=eval(text.get())
    txt.configure(text=result)

from tkinter import*
from math import*
from cmath import*
fen=Tk()
fen.geometry("300x300")
fen.title("Exercice")
but=Button(fen,text="Evaluer",command=calculer)
but.pack(side=BOTTOM,pady=10)
txt=Label(fen,text="Bonjour !",fg='red',font=('Arial',12))
txt.pack(side=TOP,pady=10)
text=Entry(fen)
text.pack()
