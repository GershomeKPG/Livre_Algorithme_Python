from tkinter import*
from tkinter import filedialog
from tkinter import messagebox

def color():
    print(var.get())
    #boite de dialogue appelee apres choix de la couleur
    messagebox.showinfo(title="Choix Couleur",
                message="Vous avez selectionner\n la couleur "+var.get())
def italic():
    print("Italic" if var2.get() else "Pas italic")
    
def Menucontex(event):
    #coodonnee relatives
    x = event.x_root 
    y = event.y_root
    men_col.post(x,y)
def ouvrir():
    #boite de dialogue pour le choix de fichier
    file=filedialog.askopenfilename(title="Ouvrir un fichier",
                filetypes=[("Fichiers pdf","*.pdf"),("Tous fichiers","*.*")])
    print(file)
def Quitte():

    #boite de dialogue pour confirmation de fermeture
    rep=messagebox.askyesno(title="Fermeture",message="Voulez-vous ferme ?")

    if rep:
        fen.destroy()


fen=Tk()
fen.geometry("250x200")
fen.title("Les Boites de dialogue")


#-------creation de la barre de menu-----------#
Menu_bar=Menu(fen,tearoff=0)

#-------creation du menu fichier-----------#

men_File=Menu(Menu_bar,tearoff=0)
#Ajout des options
men_File.add_command(label="Ouvrir",accelerator="ctrl-o",
                     command=ouvrir)
men_File.add_command(label="Enregistrer",accelerator="ctrl-s",
                     command=lambda:print("sous Menu save"))

men_File.add_separator()
men_File.add_command(label="Quitter",command=Quitte)

#lie le menu au bouton Fichier
Menu_bar.add_cascade(label="Fichier", menu=men_File)

#-------creation du menu Couleur-----------#
var=StringVar(value="Rouge")
var2=BooleanVar(value=True)

men_col=Menu(Menu_bar,tearoff=0)
men_col.add_radiobutton(label="Rouge",foreground="red",variable=var,
                        value="Rouge",command=color)
men_col.add_radiobutton(label="Verte",foreground="green",variable=var,
                        value="Verte",command=color)
men_col.add_radiobutton(label="Bleu",foreground="blue",variable=var,
                        value="Blue",command=color)
men_col.add_radiobutton(label="Jaune",foreground="yellow",variable=var,
                        value="Jaune",command=color)
men_col.add_separator()
men_col.add_command(label="Italic",font="cambria 10 italic",state="disabled")
men_col.add_checkbutton(label="Italic",variable=var2,
                        command=italic)
#lie le menu au bouton Couleur
Menu_bar.add_cascade(label="Couleur", menu=men_col)

fen.bind("<Button-3>",Menucontex)
fen.configure(menu=Menu_bar)

fen.mainloop()

