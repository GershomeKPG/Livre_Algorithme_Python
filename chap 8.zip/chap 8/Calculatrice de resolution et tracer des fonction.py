# creation des graphiques

from tkinter import*
from math import*

class graphique(Canvas):
    "Zone de dessin"
    def __init__(self,boss=None,larg=350,long=300,coulF='white',
                 coulT='black',relf=SOLID):
        Canvas.__init__(self,width=larg,height=long,
                        bg=coulF,relief=relf,bd=1)
        self._coulT=coulT
        self._long=long
        self._larg=larg
        self._translatey=0
        self._translatex=0
        self._fonction=""
        self._amplitude=1
        self.axe()
        
    def axe(self):
        self.create_line(10,self._long-10,10,10,width=1,
                         fill=self._coulT,arrow=LAST)
        self.create_text(17,10,text='y')
        self.create_line(5,self._long/2,self._larg-10,self._long/2,
                         width=1,fill=self._coulT,arrow=LAST)
        self.create_text(self._larg-10,self._long/2+7,text='x')

    def graph(self,ftn):
        self._fonction=eval('lambda x:'+ftn)
        ListPoint=[]
        for x in range(10,self._larg-10,7):
            y=self._fonction(x)+self._long/2+self._translatey
            ListPoint.append((x,y))
        self.delete(ALL)
        self.create_line(ListPoint,fill='blue',smooth=1)

    def retracer(self):
        self.delete(ALL)
        self.axe()
        ListPoint=[]
        for x in range(10+self._translatex,self._larg-10,7):
            y=self._fonction(x)*self._amplitude+self._long/2+self._translatey
            ListPoint.append((x,y))
        self.create_line(ListPoint,fill='blue',smooth=1)
        
    def setTranslatey(self,trans):
        self._translatey=int(trans)
        self.retracer()
        
    def setTranslatex(self,trans):
        self._translatex=int(trans)
        self.retracer()
        
    def setAmplitude(self,trans):
        self._amplitude=int(trans)
        if self._amplitude<0:
            self._amplitude=-(1/self._amplitude)
        self.retracer()

def tracer():
    eqtn=eqt.get()
    if len(eqtn)>=2:
        grap.graph(eqtn)
        
def resoudre():
    mess=""
    mess1=""
    eqat1=eq1.get()
    eqat2=eq2.get()
    eqat3=eq3.get()
    if len(eqat1)>8 and len(eqat2)>8 and len(eqat3)>8:
        
        eqat1=extraction(eqat1)
        eqat2=extraction(eqat2)
        eqat3=extraction(eqat3)

        a1,b1,c1=int(eqat1[0]),int(eqat1[1]),int(eqat1[2])
        d1=int(eqat1[3])
        a2,b2,c2=int(eqat2[0]),int(eqat2[1]),int(eqat2[2])
        d2=int(eqat2[3])
        a3,b3,c3=int(eqat3[0]),int(eqat3[1]),int(eqat3[2])
        d3=int(eqat3[3])
        D=a1*b2*c3+b1*c2*a3+c1*a2*b3-(a3*b2*c1+b3*c2*a1+a2*b1*c3)
        Dx=d1*b2*c3+b1*c2*d3+c1*d2*b3-(d3*b2*c1+b3*c2*d1+d2*b1*c3)
        Dy=a1*d2*c3+d1*c2*a3+c1*a2*d3-(a3*d2*c1+d3*c2*a1+a2*d1*c3)
        Dz=a1*b2*d3+b1*d2*a3+d1*a2*b3-(a3*b2*d1+b3*d2*a1+a2*b1*d3)
        mess="L'equation : \n |{}\n+|{}\n |{}\n\n".format(eq1.get(),
                                            eq2.get(),eq3.get())
        mess1=""
        if D==0:
            mess1="N'a pas de solution"
        else:
            x,y,z=Dx/D,Dy/D,Dz/D
            mess1="A pour solution:\n x={}\n y={}\n z={}".format(x,y,z)
        mess=mess+mess1

    mes=""
    mes1=""

    if (len(eqt.get())>2):
        ft=eval('lambda x:'+eqt.get())
        esp=1
        a,b=-5,5
        c=b
        n=0
        while esp>0.00001:
            n+=1
            c=(a+b)/2
            if ft(a)*ft(c)<=0:
                b=c
            else:
                a=c
            if abs(b-a)<0.00001:
                break
            esp=abs(ft(c))
        mes="\nL'equation : \n |{}=0\n".format(eqt.get())
        mes1="A pour solution x={}\n Iteration:{}".format(c,n)

    mess=mess+mes+mes1
    text.delete('1.0',END)
    text.insert('1.0',"------Solution de l'Equation------")
    text.insert(END,mess)
        
def extraction(chn):
    lis=[]
    chn=chn.replace('x',',')
    chn=chn.replace('y',',')
    chn=chn.replace('z=',',')
    lis=chn.split(',')
    return lis

from tkinter import*

fen=Tk()
grap=graphique(fen)
scalTransy=Scale(fen,label='Translation Y',from_=-100,to=100,
                 orient=HORIZONTAL,command=grap.setTranslatey)
scalTransy.grid(row=1,column=0,padx=2,pady=2)
scalTransx=Scale(fen,label='Translation X',from_=-100,to=100,
                 orient=HORIZONTAL,command=grap.setTranslatex)
scalTransx.grid(row=1,column=1,padx=2,pady=2)
sAmpl=Scale(fen,label='Amplitude',showvalue=1,from_=-100,to=100,
            orient=HORIZONTAL,command=grap.setAmplitude)
sAmpl.grid(row=1,column=2,padx=2,pady=2)
grap.grid(row=0,column=0,columnspan=3,padx=2,pady=2)

eqt=Entry(fen,width=18,font=('Times new roman',10,'italic'),
          justify=CENTER)
eqt.grid(row=2,column=0,columnspan=2,pady=5)
btnAff=Button(fen,text='Tracer',command=tracer)
btnAff.grid(row=2,column=2,padx=2,pady=5)

text=Text(fen,fg='blue',width=25,height=16,font=('Times new roman',10),
          bg='white')
text.insert('1.0',"------Solution de l'Equation------")
text.grid(row=0,column=3,pady=5,padx=5)

fr=Frame(fen,width=220,height=120,bd=1)
fr.grid(row=1,column=3,rowspan=2,padx=5,pady=3)
eq1=Entry(fr,width=18,font=('Times new roman',10),justify=CENTER)
eq2=Entry(fr,width=18,font=('Times new roman',10),justify=CENTER)
eq3=Entry(fr,width=18,font=('Times new roman',10),justify=CENTER)
btnRes=Button(fr,text='Resoudre',command=resoudre)

eq1.pack(side=TOP,pady=2,padx=3)
eq2.pack(side=TOP,pady=2,padx=3)
eq3.pack(side=TOP,pady=2,padx=3)
btnRes.pack(side=TOP,pady=2,padx=3)

fen.mainloop()

