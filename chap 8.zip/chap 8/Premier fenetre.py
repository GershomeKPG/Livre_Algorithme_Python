from tkinter import *
fenetre=Tk()
fen=Tk()
fen.destroy()
fenetre.geometry("300x150")
fenetre.title("Premier fenetre")
fenetre.mainloop()
fen.state()

