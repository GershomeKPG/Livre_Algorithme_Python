#--------UNIVERSITE CATHALIQUE LA SAPIENTIA DE GOMA(UCS/Goma)-------------
#------------------EXAMAEN DU PREMIER SEMETRE-----------------------------
#------------------ALGORITHME ET PROGRAMATION-----------------------------
#------------------MUHINDO MWIRAWAVANGI JOSPIN----------------------------
#---------------------L2 GENIE ELECTRIQUE---------------------------------

from tkinter import *
from tkinter import colorchooser, simpledialog, messagebox
import time

class Jeu_breakout:
    def __init__(self, fenetre_principale):
        self.fenetre_principale = fenetre_principale

        # Les Valeurs par défaut
        self.vitesse_initiale_dx = 3
        self.vitesse_initiale_dy = -5
        self.couleur_balle = "red"      # Couleur initiale de la balle
        self.couleur_raquette = "white"  # Couleur initiale de la raquette
        self.couleur_brique = "blue"     # Couleur par défaut pour les briques
        self.couleur_fond = "black"      # Couleur par défaut du fond (sombre)
        self.nom_joueur = "Joueur"       # Nom du joueur par défaut

        # Compteurs et gestion du score
        self.briques_supprimer = 0
        self.start_time = None
        self.score = 0

        # Meilleur score enregistré pendant la session
        self.meilleur_score = 0
        self.meilleur_joueur = ""

        self.fenetre_principale.title(f"JEU DE BREAKOUT - {self.nom_joueur}")

        # Création de la barre de menu
        self.menu_bar = Menu(self.fenetre_principale)
        self.fenetre_principale.config(menu=self.menu_bar)
        self.options_menu = Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Configurations", menu=self.options_menu)
        self.options_menu.add_command(label="Couleur de la balle", command=self.configurer_couleur_balle)
        self.options_menu.add_command(label="Couleur des briques", command=self.configurer_couleur_briques)
        self.options_menu.add_command(label="Couleur de la raquette", command=self.configurer_couleur_raquette)
        self.options_menu.add_separator()
        self.options_menu.add_command(label="Couleur de fond", command=self.configurer_couleur_fond)
        self.options_menu.add_separator()
        self.options_menu.add_command(label="Vitesse de la balle", command=self.configurer_vitesse)
        self.options_menu.add_separator()
        self.options_menu.add_command(label="Nom du joueur", command=self.configurer_nom_joueur)
        self.options_menu.add_separator()
        self.options_menu.add_command(label="Meilleur score", command=self.afficher_meilleur_score)

        # Canvas de la zone du jeu
        self.zone_jeu_canvas = Canvas(fenetre_principale, width=600, height=400, bg=self.couleur_fond)
        self.zone_jeu_canvas.pack()

        # Label pour afficher le score courant
        self.score_label = Label(fenetre_principale, text=f"Score: {self.score}", font=("Arial", 14))
        self.score_label.pack()

        # Label pour afficher le meilleur score dans l'interface (optionnel)
        self.meilleur_score_label = Label(fenetre_principale, text=f"Meilleur score: {self.meilleur_score}", font=("Arial", 14))
        self.meilleur_score_label.pack()

        # Création de la raquette (sur laquelle la balle va se déposer)
        self.raquette_balle = self.zone_jeu_canvas.create_rectangle(250, 380, 350, 390, fill=self.couleur_raquette)

        # Création de la balle (initialement immobile)
        self.balle = self.zone_jeu_canvas.create_oval(290, 360, 310, 380, fill=self.couleur_balle)
        self.balle_dx = 0  # Vitesse initiale nulle (démarrage avec "Espace")
        self.balle_dy = 0

        # Création des briques
        self.briques = []
        self.creation_briques()

        # Lier les actions des touches (gauche, droite, espace)
        self.fenetre_principale.bind("<Left>", self.action_touche_direction_gauche)
        self.fenetre_principale.bind("<Right>", self.action_touche_direction_droite)
        self.fenetre_principale.bind("<space>", self.debut_jeu)

        # Variable de contrôle du jeu
        self.execution = False
        self.redemarrage_boutton = None  # Bouton pour relancer le jeu (initialement non créé)

    def creation_briques(self):
        """Création d'une grille de briques en haut de l'écran avec la couleur définie"""
        self.briques = []  # Réinitialisation de la liste des briques
        for i in range(5):
            for j in range(8):
                brique = self.zone_jeu_canvas.create_rectangle(
                    j * 75 + 5, i * 30 + 5, j * 75 + 70, i * 30 + 30,
                    fill=self.couleur_brique, outline="black")
                self.briques.append(brique)

    def debut_jeu(self, event):
        """Démarrer le jeu en appuyant sur Espace"""
        # Supprimer le message de fin s'il est présent
        self.zone_jeu_canvas.delete("endmessage")

        # Supprimer le bouton de redemarrage du jeu s'il existe ebcore sur l'ecran
        if self.redemarrage_boutton:
            self.redemarrage_boutton.destroy()
            self.redemarrage_boutton = None

        # Si le jeu n'est pas en cours, on réinitialise tout (y compris les briques).
        if not self.execution:
            self.recommencer_jeu()  # Reconstruire le canvas, les briques, la raquette et la balle

            self.execution = True
            self.balle_dx = self.vitesse_initiale_dx
            self.balle_dy = self.vitesse_initiale_dy
            self.start_time = time.time()
            self.briques_supprimer = 0
            self.score = 0
            self.score_label.config(text=f"Score: {self.score}")
            self.mise_a_jour_jeu()

    def action_touche_direction_gauche(self,event):
        """Déplacer la raquette vers la gauche"""
        x1, _, x2, _ = self.zone_jeu_canvas.coords(self.raquette_balle)
        if x1 > 0:
            self.zone_jeu_canvas.move(self.raquette_balle, -50, 0)# vitesse deplacement de la raquette est de 50

    def action_touche_direction_droite(self, event):
        """Déplacer la raquette vers la droite"""
        x1, _, x2, _ = self.zone_jeu_canvas.coords(self.raquette_balle)
        if x2 < 600:
            self.zone_jeu_canvas.move(self.raquette_balle, 50, 0)# vitesse deplacement de la raquette est de 50

    def mise_a_jour_jeu(self):
        """Mettre à jour la position de la balle, vérifier les collisions et mettre à jour le score"""
        if not self.execution:
            return

        self.zone_jeu_canvas.move(self.balle, self.balle_dx, self.balle_dy)
        balle_coordonnees = self.zone_jeu_canvas.coords(self.balle)
        raquette_coordonnees = self.zone_jeu_canvas.coords(self.raquette_balle)

        # Rebondir la balle sur les murs
        if balle_coordonnees[0] <= 0 or balle_coordonnees[2] >= 600:
            self.balle_dx = -self.balle_dx
        if balle_coordonnees[1] <= 0:
            self.balle_dy = -self.balle_dy

        # Vérifier la collision avec la raquette
        if (raquette_coordonnees[0] < balle_coordonnees[2] and balle_coordonnees[0] < raquette_coordonnees[2] and
                raquette_coordonnees[1] < balle_coordonnees[3] < raquette_coordonnees[3]):
            self.balle_dy = -self.balle_dy
            # Optionnel : modifier la vitesse horizontale pour ajouter un effet de rebond
            self.balle_dx += (balle_coordonnees[0] - raquette_coordonnees[0]) / 50 - 0.5

        # Vérification des collisions avec les briques
        for brique in self.briques[:]:
            brique_coordonnees = self.zone_jeu_canvas.coords(brique)
            if brique_coordonnees:
                if (brique_coordonnees[0] < balle_coordonnees[2] and balle_coordonnees[0] < brique_coordonnees[2] and
                        brique_coordonnees[1] < balle_coordonnees[3] and balle_coordonnees[1] < brique_coordonnees[3]):
                    self.zone_jeu_canvas.delete(brique)
                    self.briques.remove(brique)
                    self.balle_dy = -self.balle_dy

                    # Mise à jour du compteur de briques détruites
                    self.briques_supprimer += 1
                    # Calcul du temps écoulé depuis le début du jeu, éviter division par zéro
                    temps_ecouler = time.time() - self.start_time if self.start_time else 1
                    points = int(1000 / max(temps_ecouler, 1))
                    self.score += points
                    self.score_label.config(text=f"Score: {self.score}")

        # Vérifier si la balle est tombée (Game Over)
        if balle_coordonnees[3] >= 400:
            self.game_over()
            return

        # Vérifier si toutes les briques ont été détruites (Win)
        if not self.briques:
            self.win()
            return

        self.fenetre_principale.after(20, self.mise_a_jour_jeu)

    def verifier_meilleur_score(self):
        """Vérifie et met à jour le meilleur score et le nom du joueur si nécessaire."""
        if self.score > self.meilleur_score:
            self.meilleur_score = self.score
            self.meilleur_joueur = self.nom_joueur
            self.meilleur_score_label.config(
                text=f"Meilleur score: {self.meilleur_score} par {self.meilleur_joueur}"
            )

    def afficher_meilleur_score(self):
        """Afficher la boite de dialogue avec le meilleur score et le nom du joueur correspondant."""
        messagebox.showinfo(
            "Meilleur Score",
            f"Meilleur score: {self.meilleur_score}\nRéalisé par: {self.meilleur_joueur or 'Aucun'}"
        )

    def game_over(self):
        """Afficher Game Over, vérifier le meilleur score et arrêter le jeu"""
        self.execution = False
        self.balle_dx = 0
        self.balle_dy = 0
        self.zone_jeu_canvas.create_text(300, 200, text="Game Over", fill="red", font=("Arial", 24), tags="endmessage")
        self.verifier_meilleur_score()
        self.affichage_boutton_recommencer()

    def win(self):
        """Afficher Victoire, vérifier le meilleur score et arrêter le jeu"""
        self.execution = False
        self.balle_dx = 0
        self.balle_dy = 0
        self.zone_jeu_canvas.create_text(300, 200, text="You Win!", fill="green", font=("Arial", 24), tags="endmessage")
        self.verifier_meilleur_score()
        self.affichage_boutton_recommencer()

    def affichage_boutton_recommencer(self):
        """Créer et afficher le bouton 'Relancer' après une fin de partie"""
        if not self.redemarrage_boutton:
            self.redemarrage_boutton = Button(self.fenetre_principale, text="Relancer", command=self.recommencer_jeu)
            self.redemarrage_boutton.pack(pady=5)

    def recommencer_jeu(self):
        """Réinitialiser le jeu"""
        self.zone_jeu_canvas.delete("all")
        self.creation_briques()

        # Redessiner la raquette et la balle
        self.raquette_balle = self.zone_jeu_canvas.create_rectangle(250, 380, 350, 390, fill=self.couleur_raquette)
        self.balle = self.zone_jeu_canvas.create_oval(290, 360, 310, 380, fill=self.couleur_balle)

        # Réinitialiser les variables de contrôle du jeu
        self.execution = False
        self.balle_dx = 0
        self.balle_dy = 0
        self.briques_supprimer = 0
        self.start_time = None

        # Réinitialiser le score et mettre à jour l'affichage
        self.score = 0
        self.score_label.config(text=f"Score: {self.score}")

        # Supprimer le bouton de redemarrage si présent
        if self.redemarrage_boutton:
            self.redemarrage_boutton.destroy()
            self.redemarrage_boutton = None

    def configurer_vitesse(self):
        """Configurer la vitesse horizontale de la balle"""
        config_fenetre = Toplevel(self.fenetre_principale)
        config_fenetre.title("Configuration de la vitesse horizontale de la balle")

        Label(config_fenetre, text="Vitesse horizontale (dx):").pack(pady=5)
        slider_dx = Scale(config_fenetre, from_=1, to=15, orient=HORIZONTAL)
        slider_dx.set(abs(self.vitesse_initiale_dx))
        slider_dx.pack(pady=5)

        def appliquer_config():
            self.vitesse_initiale_dx = slider_dx.get()
            config_fenetre.destroy()

        Button(config_fenetre, text="Appliquer", command=appliquer_config).pack(pady=10)

    def configurer_couleur_balle(self):
        """Choisir une nouvelle couleur pour la balle"""
        couleur = colorchooser.askcolor(title="Choisissez une couleur pour la balle")
        if couleur[1]:
            self.couleur_balle = couleur[1]
            self.zone_jeu_canvas.itemconfig(self.balle, fill=self.couleur_balle)

    def configurer_couleur_raquette(self):
        """Choisir une nouvelle couleur pour la raquette"""
        couleur = colorchooser.askcolor(title="Choisissez une couleur pour la raquette")
        if couleur[1]:
            self.couleur_raquette = couleur[1]
            self.zone_jeu_canvas.itemconfig(self.raquette_balle, fill=self.couleur_raquette)

    def configurer_couleur_briques(self):
        """Choisir une nouvelle couleur pour les briques"""
        couleur = colorchooser.askcolor(title="Choisissez une couleur pour les briques")
        if couleur[1]:
            self.couleur_brique = couleur[1]
            for brique in self.briques:
                self.zone_jeu_canvas.itemconfig(brique, fill=self.couleur_brique)

    def configurer_couleur_fond(self):
        """Configurer la couleur de fond (sombre ou clair)"""
        config_fenetre = Toplevel(self.fenetre_principale)
        config_fenetre.title("Configuration de la couleur de fond")

        var = StringVar(value=self.couleur_fond)
        Radiobutton(config_fenetre, text="Sombre", variable=var, value="black").pack(anchor=W, padx=10, pady=5)
        Radiobutton(config_fenetre, text="Clair", variable=var, value="white").pack(anchor=W, padx=10, pady=5)

        def appliquer_config():
            self.couleur_fond = var.get()
            self.zone_jeu_canvas.config(bg=self.couleur_fond)
            config_fenetre.destroy()

        Button(config_fenetre, text="Appliquer", command=appliquer_config).pack(pady=10)

    def configurer_nom_joueur(self):
        """Boîte de dialogue pour saisir le nom du joueur"""
        nom = simpledialog.askstring("Nom du joueur", "Entrez votre nom :")
        if nom:
            self.nom_joueur = nom
            self.fenetre_principale.title(f"JEU DE BREAKOUT - {self.nom_joueur}")

fenetre_principale = Tk()
game_breakout = Jeu_breakout(fenetre_principale)
fenetre_principale.mainloop()