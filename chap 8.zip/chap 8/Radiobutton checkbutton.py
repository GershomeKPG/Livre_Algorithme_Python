
from tkinter import *

def textDef():
    Maj=Majeur.get()
    sex=int(sexe.get())
    te="Tu est {0} {1}"
    label.configure(text=te.format(item[sex],"Majeur")if Maj
                    else te.format(item[sex],"Mineur"))
    

fen=Tk()
fen.geometry("200x150")
fen.title("Widget")

sexe=StringVar(value='1')
Majeur=BooleanVar(value=False)

item=["Homme", "Femme"]
label=Label(fen,fg='orange',font="Cambria 12 italic")
btnR1=Radiobutton(fen,font="Cambria 12 italic",
                  variable=sexe,value='0',text="Homme")
btnR2=Radiobutton(fen,font="Cambria 12 italic",
                  variable=sexe,value='1',text="Femme")
btnC=Checkbutton(fen,font="Cambria 12 italic",
                  variable=Majeur,text="Majeur")

btn=Button(fen,text="Enter",command=textDef)
label.grid(pady=5, padx=5,row=0,column=0,columnspan=2)
btnC.grid(pady=5, padx=5,row=1,column=0,rowspan=2)
btnR1.grid(pady=5, padx=5,row=1,column=1)
btnR2.grid(pady=5, padx=5,row=2,column=1)
btn.grid(pady=5, padx=5,row=3,column=0,columnspan=2)
fen.mainloop()

