
from tkinter import *

    
fen=Tk()
fen.geometry("200x250")
fen.title("Widget")

imag=PhotoImage(file="D:\\Cours\\Algoithme et Programmation\\Code\\Graphic\\logo.png")

txt=Text(fen,bg='black',font="Cambria 12",width=150,height=200,wrap='word')
txt.tag_configure('style1',foreground='blue',font="Arial 14 bold")
txt.tag_configure('style2',foreground='orange',font="Cambria 12 italic")
txt.insert('1.0','Bienvenue a UCS\n\n','style1')
txt.image_create('3.4',image=imag)
txt.insert('4.0',"\nFormer les génies de la transformation",'style2')

txt.pack(pady=5,side=TOP)
fen.mainloop()

