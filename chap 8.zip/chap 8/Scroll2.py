from tkinter import ttk 
from tkinter import *  

fen=Tk()
fen.geometry("250x120")
fen.title("tkinter.ttk")

style = ttk.Style()
style.configure("bar.Horizontal.TProgressbar",
                background="Ivory",
                troughtcolor="Silver", # couleur de l'arriere-plan
                thickness=10, #epaisseur de la barre
                )
Pbar= ttk.Progressbar(fen,length=220,mode="indeterminate",
                      style="bar.Horizontal.TProgressbar")
Pbar.start(10)
fen.after(50000,Pbar.stop)

Pbar.pack(padx=5,pady=10)

fen.mainloop()
