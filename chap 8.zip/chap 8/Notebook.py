from tkinter import ttk 
from tkinter import *

fen=Tk()
fen.geometry("300x200")
fen.title("tkinter.ttk")

style = ttk.Style()

style.configure("btn.TButton",
                background="ivory",
                forground="Black", 
                font="Cambria 12 italic", 
                )

style.configure("note.TNotebook",
                background="Teal",
                forground="Black", 
                font="Cambria 12 bold italic", 
                )
style.configure("fr1.TFrame",
                background="Light Green",
                forground="Black", 
                font="Cambria 12 bold italic", 
                )
style.configure("fr2.TFrame",
                background="Dark Green",
                forground="Black", 
                font="Cambria 12 bold italic", 
                )

note= ttk.Notebook(fen,width=270,height=180,style="note.TNotebook")
fr1=ttk.Frame(note,widt=265,height=175,style="fr1.TFrame")
fr2=ttk.Frame(note,widt=265,height=175,style="fr2.TFrame")
ttk.Button(fr1,text="Bouton 1", style="btn.TButton").pack(pady=10)
ttk.Button(fr2,text="Bouton 2", style="btn.TButton").pack(pady=10)
note.add(fr1,text="Frame 1")
note.add(fr2,text="Frame 2")

note.pack()

fen.mainloop()

