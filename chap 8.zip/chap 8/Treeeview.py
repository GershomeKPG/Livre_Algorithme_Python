from tkinter import ttk 
from tkinter import *

def affich(event):
    ident=tab.selection()[0]
    Select_dat=tab.item(ident,"values")
    nomSe=Select_dat[0]
    DomSe=Select_dat[1]
    FilSe=Select_dat[2]
    NivSe=Select_dat[3]
    l1.config(text="Nom : "+nomSe)
    l2.config(text="Domaine : "+DomSe)
    l3.config(text="Filiere : "+FilSe)
    l4.config(text="Niveau : "+NivSe)

fen=Tk()
fen.geometry("500x360")
fen.title("tkinter.ttk")

#Definition da la liste des nom des colonnes
colon = ["Nom","Domaine","Filiere","Niveau"]

#Les donnees a affichees
Donnee=[["Jospin","ST","Genie Elec","L2"],
        ["Lumiere","ST","Genie Civil","L2"],
        ["Josue","ST","Genie Elec","L2"],
        ["Naty","ST","Genie Civil","L3"],
        ["Guerschome","Sante Public","Science de la Sante","L2"],
        ["Jonas","Economie","GFIN","L3"],
        ["Nadege","DAH","Gestion de Catastrophe","M1"]]

style = ttk.Style()

#Configuration du style du tableau
style.configure("tableau.Treeview",
                background="ivory",
                forground="Black", 
                font="Cambria 12", 
                )
#Configuration du style du tableau, specifiquement l'en-tete
style.configure("tableau.Treeview.Heading",
                background="silver",
                forground="Black", 
                font="Cambria 12 bold italic", 
                )


tab= ttk.Treeview(fen,columns=colon,
                      style="tableau.Treeview")

#Ajout des en-tete des colonnes
tab.heading("#0",text="N")
tab.heading("Nom",text="Nom")
tab.heading("Domaine",text="Domaine")
tab.heading("Filiere",text="Filier")
tab.heading("Niveau",text="Niveau")

#Formatage des colonnes
tab.column("#0",width=30,anchor='center')
tab.column("Nom",width=120,anchor='w')
tab.column("Domaine",width=120,anchor='center')
tab.column("Filiere",width=100,anchor='center')
tab.column("Niveau",width=100,anchor='center')

#Insertion des donnees dans le tableau
for id,data in enumerate(Donnee):
    tab.insert("","end",iid=id,text=str(id),values=data)

#Evenement
tab.bind("<<TreeviewSelect>>",affich)

inf=LabelFrame(fen,width=450,text="Etudiant", height=500,bg="white",
               labelanchor="nw",relief="ridge")
nom="Nom"
dom="Domaine"
fil="Filiere"
niv="Niveau"
l1=Label(inf,text=f"{nom:<11} : ",fg="black",font="Cambia 11",bg="white", anchor='w')
l2=Label(inf,text=f"{dom:<8} : ",fg="black",font="Cambia 11",bg="white", anchor='w')
l3=Label(inf,text=f"{fil:<13} : ",fg="black",font="Cambia 11",bg="white", anchor='w')
l4=Label(inf,text=f"{niv:<11} : ",fg="black",font="Cambia 11",bg="white", anchor='w')
l1.grid(row=0,column=0)
l2.grid(row=1,column=0)
l3.grid(row=2,column=0)
l4.grid(row=3,column=0)

tab.pack(padx=5,pady=5,side=BOTTOM)
inf.pack(padx=5,pady=5,side=TOP,fill='x')

fen.mainloop()
