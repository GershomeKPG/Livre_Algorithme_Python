from tkinter import *

class EntryAvecDel(Frame):  # Hérite de Frame
    def __init__(self, parent,relief='solid',bg='Ivory'):
        super().__init__(parent,relief=relief,bg=bg)  # Initialise le widget Frame

        # Champ de saisie
        self.text = Entry(self, font=("Cambia", 12), width=20,justify='center')
        self.text.pack(side="left", padx=5)

        # Bouton pour effacer le texte
        self.clear_btn = Button(self, text="X",
                                command=self.clear, font=("Cambria", 12))
        self.clear_btn.pack(side="right")

    def clear(self):
        """ Efface le texte du champ de saisie """
        self.text.delete(0, END)
    def get(self):
        """retourne le texte saisie"""
        return self.text.get()

def afficher():
    print("Texte 1 : "+entry1.get())
    print("Texte 2 : "+entry2.get())

# Création de la fenêtre principale
fen= Tk()
fen.title("Champ de Texte Personnalisé")

# Ajout du widget personnalisé
entry1 = EntryAvecDel(fen,bg='blue')
entry2 = EntryAvecDel(fen,relief='sunken')
btn=Button(fen,text="Print",command=afficher)
entry1.grid(row=0,column=0,padx=5,pady=5)
entry2.grid(row=1,column=0,padx=5,pady=5)
btn.grid(row=2,column=0,pady=10)

fen.mainloop()
