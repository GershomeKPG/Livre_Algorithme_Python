from tkinter import *

fen=Tk()
fen.geometry("300x250")
fen.title("Canvas")
can=Canvas(fen, width=290,height=240,bg='pink',relief=SOLID)
can.create_line(25,20,75,24,150,200,fill='black',width=3,smooth=True)
can.pack()
