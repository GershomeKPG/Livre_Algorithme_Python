import tkinter as tk
from tkinter import ttk

# creation d'un widget Bouton Héritant de ttk.Button

class Bouton(ttk.Button): 
    def __init__(self, parent, text="Bouton", command=None,style=None):
        self.styl=style
        super().__init__(parent, text=text, command=command, style=self.styl)

        style = ttk.Style()
        style.configure("Entre.TButton", font=("Arial", 12,'italic'),
                        background="blue", foreground="white")
        style.configure("Press.TButton", font=("Cambria", 12,'bold'),
                        background="green", foreground="white")

        
        # Associer les événements
        self.bind("<Enter>", self.entre)  # Entree de la Souris
        self.bind("<Leave>", self.sorti)  # Sorti de la souris
        self.bind("<ButtonPress-1>", self.click)# Clique de la souris
        
# Application des style
    def entre(self, event):
        """ Change de style au survol """
        self["style"] = "Entre.TButton"

    def sorti(self, event):
        """ Revient au style normal """
        self["style"] = self.styl
        
    def click(self, event):
        """ Revient au style normal """
        self["style"] = "Press.TButton"

# Création de la fenêtre principale
fen = tk.Tk()
fen.title("Bouton ttk Personnalisé")

# Création des style ttk
style = ttk.Style()
style.configure("btn1.TButton", font=("Arial", 12),
                background="gray", foreground="orange")
style.configure("btn2.TButton", font=("Arial", 12),
                background="yellow", foreground="red")

# Ajout du bouton personnalisé a la fenetre
btn1 = Bouton(fen, text="Entree",style="btn1.TButton")
btn2 = Bouton(fen, text="Sortie",style="btn2.TButton")
btn1.pack(pady=10)
btn2.pack(pady=10)

fen.mainloop()
