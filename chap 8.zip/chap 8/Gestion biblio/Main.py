
def AjouterLivre():
    titr=tit.get()
    aut=Aut.get()
    ann=An.get()
    message=""
    error=False
    if len(titr)<5:
        message="Veillez remplir le titre du livre"
        error=True
        tit.delete(0,END)
    elif len(aut)<5:
        message="Veillez remplir le nom de l'auteur du livre"
        error=True
        Aut.delete(0,END)
    elif len(ann)<3:
        message="Veillez remplir l'annee de publication"
        error=True
        An.delete(0,END)
    else:
        message="Livre ajoute avec succes"

    if error:
        m.showerror(title='Erreur',message=message)
    else:
        bk=book(titr,aut,ann)
        bib.add_book(bk)
        m.showinfo(title='Ajouter livre',message=message)
        tit.delete(0,END)
        Aut.delete(0,END)
        An.delete(0,END)
def Recherche():
    aut_ann=typedeRech.get()
    textRech=txtRech.get()
    sort=""
    if len(textRech)<=3:
        m.showerror(title='Erreur',message="Specifier le mot cle")
    else:
        if aut_ann=='Auteur':
            sort=bib.Find_book_by_author(textRech)
        else:
            sort=bib.Find_book_by_year(textRech)
        sortie.delete('1.0',END)
        sortie.insert('1.0',"_______----Livres----______\n\n",'titre')
        sortie.insert(END,sort,'autre')

from tkinter import*
from tkinter import messagebox as m
from ex7_chap6 import*

fen=Tk()
bib=bibliotheque("UCS")
typedeRech=StringVar()
fen.title("Bibliotheque")
fen.geometry("500x360")
fen.resizable(width=False,height=False)

#Creation des widgets principals
sortie=Text(fen,bg='black',fg='white',font=('Cambia',10),width=30,height=18)
fr1=Frame(fen,bd=2,relief=SUNKEN,width=210,height=170)
fr2=Frame(fen,bd=2,relief=SOLID,width=210,height=170)
fr2.grid_propagate(0)
sortie.insert('1.0',"_______----Livres----______\n\n")
sortie.tag_configure('titre',foreground='orange',font=('Arial bord',10,'italic'))
sortie.tag_configure('autre',foreground='red',font=('Arial bord',8))
                     
Label(fr1,text='Nouveau livre',font=('Arial',12),anchor=N).grid(row=0,column=0,columnspan=4,pady=2)
Label(fr1,text='Titre    :',font=('Arial',9),anchor=E).grid(row=1,column=0,pady=2,sticky=W)
Label(fr1,text='Auteur :',font=('Arial',9),anchor=E).grid(row=2,column=0,pady=2,sticky=W)
Label(fr1,text='Annee :',font=('Arial',9),anchor=E).grid(row=3,column=0,pady=2,sticky=W)
tit=Entry(fr1,font=('Arial',9),width=18,justify=CENTER)
tit.grid(row=1,column=1,columnspan=3,padx=2,pady=1)
Aut=Entry(fr1,font=('Arial',9),width=18,justify=CENTER)
Aut.grid(row=2,column=1,columnspan=3,padx=2,pady=1)
An=Entry(fr1,font=('Arial',9),width=18,justify=CENTER)
An.grid(row=3,column=1,columnspan=3,padx=2,pady=1)
btnSave=Button(fr1,text='Enregistrer',font=('Arial',8),command=AjouterLivre)
btnSave.grid(row=4,column=1,columnspan=2,pady=2)


Label(fr2,text='Recherche livre',font=('Arial',12),anchor=N).grid(row=0,column=0,columnspan=3,pady=2)
Radiobutton(fr2,text='Auteur',value='Auteur',variable=typedeRech).grid(row=1,column=0,padx=4,pady=2)
Label(fr2,text='   ',font=('Arial',12),anchor=N).grid(row=1,column=2,pady=2)
Radiobutton(fr2,text='Annee',value='Annee',variable=typedeRech).grid(row=1,column=2,padx=4,pady=2)
txtRech=Entry(fr2,font=('Arial',9),width=23,justify=CENTER)
txtRech.grid(row=2,column=0,columnspan=3,padx=4,pady=4)
btnRech=Button(fr2,text='Rechercher',font=('Arial',8),command=Recherche)
btnRech.grid(row=3,column=0,columnspan=3,pady=5)
typedeRech.set('Auteur')

sortie.grid(row=0,column=0,rowspan=2,padx=5,pady=5)
fr1.grid(row=0,column=1,padx=2,pady=5)
fr2.grid(row=1,column=1,padx=2,pady=5)

fen.mainloop()
fen.destroy()
