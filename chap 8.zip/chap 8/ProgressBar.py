from tkinter import ttk 
from tkinter import *  

def Start():
    if Pbar["value"]<100: # Pbar["valeur"] recupere la valeur actuel
        Pbar["value"]+=10 # Ajouter 10 a la valeur actuel
        #Pbar.step(10)
        fen.after(700,Start) # rappeler la fonction Start() apres 500 millisecondes
def Restart():
    Pbar["value"]=0 # modifie la valeur actuel
   

fen=Tk()
fen.geometry("250x120")
fen.title("tkinter.ttk")

style = ttk.Style()
style.configure("bar.Horizontal.TProgressbar",
                background="Ivory",
                troughtcolor="Silver", # couleur de l'arriere-plan
                thickness=10, #epaisseur de la barre
                )
Pbar= ttk.Progressbar(fen,length=220,mode="determinate",
                      style="bar.Horizontal.TProgressbar")
Pbar.grid(row=0,column=0,columnspan=2,padx=5,pady=5)
ttk.Button(fen,text="Restart",command=Restart).grid(row=1,column=0,padx=5,pady=5)
ttk.Button(fen,text="Start",command=Start).grid(row=1,column=1,padx=5,pady=5)

fen.mainloop()

