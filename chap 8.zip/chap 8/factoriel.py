
from math import *

def evalu(expression):
    if '!' in expression:
        point=expression.index('!')
        if expression[point-1]!=')':
            for i in range(point-1,-1,-1):
                if expression[i].isdigit() and i!=0 :
                    continue
                else:
                    e=(expression[i+1:point])if i!=0 else (expression[i:point])
                    print(e)
                    return expression.replace(e+"!",str(eval("factorial("+e+")")))
                    break
        else:
            for i in range(point-2,-1,-1):
                if expression[i]=='(' and i!=0 :
                    continue
                else:
                    e=expression[i+1:point]if i!=0 else (expression[i:point])
                    if e.count('(')==e.count(')'):
                        e=expression[i+1:point]if i!=0 else (expression[i:point])
                        print(e)
                        return expression.replace(e+"!",str(eval("factorial("+e+")")))
                        break
                    else:
                        continue
                    
        
     
