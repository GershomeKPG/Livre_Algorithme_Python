from tkinter import ttk 
from tkinter import *  

fen=Tk()
fen.geometry("200x120")
fen.title("tkinter.ttk")

style = ttk.Style()
style.configure("aff.TLabel", foreground="Teal", background="Magenta")
style.configure("Btn.TButton", foreground="Black", background="orange")
style.map("Btn.TButton",
                foreground=[("pressed","blue"),("active","green")],
                background=[("pressed","white"),("active","Ivory")])
l1 = ttk.Label(fen,text="Bienvenu au cours", style="aff.TLabel")
l2 = ttk.Label(fen,text="Sciences et technologie", style="aff.TLabel")
btn=ttk.Button(fen,text="Bouton",style="Btn.TButton")
l1.pack()
l2.pack()
btn.pack(pady=5)
