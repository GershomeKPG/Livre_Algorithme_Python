from math import*
class NonLineaire(object):
    "Classe abstraite pour la résolution des équations non linéaires"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        self.Inter = Inter
        self.eps = eps
        self.IMax = IMax

    def resolution(self, fnc):
        raise NotImplementedError


class Bissection(NonLineaire):
    "Classe pour la méthode de dichotomie"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        super().__init__(Inter, eps, IMax)
        self.a, self.b = sorted(Inter)

    def division(self, a, b, f):
        return 0.5 * (a + b)

    def resolution(self, fnc):
        a, b = self.a, self.b
        f = eval("lambda x:"+fnc)

##        if f(a) * f(b) > 0:
##            return "La fonction ne change pas de signe sur [a, b]"

        for i in range(self.IMax):
            c = self.division(a, b, f)
            if abs(f(c)) < self.eps or (b - a) < self.eps:

                return c,f(c), i+1

            if f(c) * f(b) < 0:
                a = c
            else:
                b = c

        return c,f(c), i+1


class RegulaFalsi(Bissection):
    "Classe pour la méthode Regula Falsi"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        super().__init__(Inter, eps, IMax)

    def division(self, a, b, f):
        return a-f(a)*(b-a)/(f(b)-f(a))
    
        
class PointFixe(NonLineaire):
    "Classe pour la méthode Point Fixe"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        super().__init__(Inter, eps, IMax)
        [self.a, self.b] = Inter

    def resolution(self, fnc):
        X0=(self.a+self.b)*0.5
        g = eval("lambda x:"+fnc)
        f=eval("lambda x:x-"+fnc)
        X0,X1=X0,g(X0)

        for i in range(self.IMax):
            if abs(X0-X1) < self.eps or abs(f(X1))<self.eps:

                return X1,f(X1),i+1

            X0,X1=X1,g(X1)

        return X1,f(X1),i+1

class NewTon(PointFixe):
    "Classe pour la méthode de Newton-Raphson"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        super().__init__(Inter, eps, IMax)

    def resolution(self, fnc,dfnc):
        gx="x-("+fnc+")/("+dfnc+")"
        f=eval("lambda x:"+fnc)
        result= PointFixe.resolution(self,gx)
        return result[0],f(result[0]),result[2]

class Secante(NonLineaire):
    "Classe pour la méthode de la Secante"
    def __init__(self, Inter, eps=2.22e-10, IMax=10**5):
        super().__init__(Inter, eps, IMax)
        [self.a, self.b] = sorted(Inter)

    def resolution(self, fnc):
        X0,X1=self.a,self.b
        f = eval("lambda x:"+fnc)

        for i in range(self.IMax):
            X2=X1-f(X1)*(X1-X0)/(f(X1)-f(X0))
            if abs(X0-X2) < self.eps or abs(f(X2))<self.eps:

                return X2,f(X2),i+1

            X0,X1=X1,X2

        return X2,f(X2),i+1

## comparatif des methodes de resolution
## f(x)=x^3+4x-2
## f'(x)=3x^2+4
## g(x)=2/(x^2+4)
Entete="|{:^9}|{:^12}|{:^12}|{:^13s}|{:^13s}|{:^13s}|".format("MaxIter",
            "Bissection","Regula Falsi","Point Fixe","Newton","Secante")
print("-"*79)
print(Entete)
print("-"*79)
for i in range(1,11):
    bi=Bissection([0,1],IMax=i)
    re=RegulaFalsi([0,1],IMax=i)
    pf=PointFixe([0,1],IMax=i)
    ne=NewTon([0,1],IMax=i)
    se=Secante([0,1],IMax=i)
    resultat=[eval(k).resolution("x**3+4*x-2")[1] for k in ["bi","re","se"]]
    resultat.append(pf.resolution("2/(x**2+4)")[1])
    resultat.append(ne.resolution("x**3+4*x-2","3*x**2+4")[1])
    ligne='''| {:^8d}|{:^12.2e}|{:^12.2e}| {:^12.2e}| {:^12.2e}|
{:^12.2e}|'''.format(i,resultat[0],resultat[1],resultat[3],
                                                      resultat[4],resultat[2])
    print(ligne)
    print("-"*79)




    
