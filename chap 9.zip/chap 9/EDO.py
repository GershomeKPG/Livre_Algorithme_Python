from math import *

class EDO(object):
    def __init__(self,f,I,CI,h=0.1):
        self.fnc=f
        self.h=h
        self.a,self.b=min(I),max(I)
        self.x0,self.y0=CI[0],CI[1]
        self.f=eval("lambda x,y:"+f)
        self.resultat=[[self.x0,self.y0]]
        self.i=-1
        
        
    def iteration(self):
        raise NotImplementedError
    
    def resolution(self):
        while self.resultat[-1][0]<=self.b:
            self.resultat.append(self.iteration())
        self.h=-self.h
        self.i=0
        while self.resultat[0][0]>=self.a:
            self.resultat.insert(0,self.iteration())
        return self.resultat

class Euler(EDO):
    def __init__(self,f,I,CI,h=0.1):
        super().__init__(f,I,CI,h)

    def iteration(self):
        f,h=self.f,self.h
        [x,y]=self.resultat[self.i]
        x1=x+h
        y1=y+h*f(x,y)
        return [x1,y1]
        
class RK2(EDO):
    def __init__(self,f,I,CI,h=0.1):
        super().__init__(f,I,CI,h)

    def iteration(self):
        f,h=self.f,self.h
        [x,y]=self.resultat[self.i]
        x1=x+h
        k=y+h*f(x,y)
        y1=y+(h/2)*(f(x,y)+f(x1,k))
        return [x1,y1]

class RK4(EDO):
    def __init__(self,f,I,CI,h=0.1):
        super().__init__(f,I,CI,h)

    def iteration(self):
        f,h=self.f,self.h
        [x,y]=self.resultat[self.i]
        x1=x+h
        k1=h*f(x,y)
        k2=h*f(x+h/2,y+k1/2)
        k3=h*f(x+h/2,y+k2/2)
        k4=h*f(x+h,y+k3)
        y1=y+(1/6)*(k1+2*k2+2*k3+k4)
        return [x1,y1]

class RK4_2(EDO):
    def __init__(self,f,I,CI,h=0.1):
        super().__init__(f,I,CI,h)
        
    def g(self,x,y):
        fnc=eval("lambda x,y,z:"+self.fnc)
        return [y[1],fnc(x,y[0],y[1])]

    def iteration(self):
        h=self.h
        [x,y]=self.resultat[self.i]
        x1=x+h
        k1=[h*t for t in self.g(x,y)]
        ft=[u+v/2 for u,v in zip(y,k1)]
        k2=[h*t for t in self.g(x+h/2,ft)]
        ft=[u+v/2 for u,v in zip(y,k2)]
        k3=[h*t for t in self.g(x+h/2,ft)]
        ft=[u+v for u,v in zip(y,k3)]
        k4=[h*t for t in self.g(x+h,ft)]
        y1=[yt+(1/6)*(k11+2*k22+2*k33+k44)
            for yt,k11,k22,k33,k44 in zip(y,k1,k2,k3,k4)]
        return [x1,y1]

class Tir(object):
    def __init__(self,f,I,CI,h=0.1,s_min=-2,s_max=2,eps=1e-7):
        self.x01,self.x02=CI[0][0],CI[0][1]
        self.y01,self.y02=CI[1][0],CI[1][1]
        self.s_min=s_min
        self.s_max=s_max
        self.s_mid=(self.s_max+self.s_min)/2
        self.fcn=f
        self.eps=eps
        self.h=h
        self.I=I
        self.angle_tir=self.tirer()

    def tirer(self):
        ep=self.eps
        while True:
            self.s_mid=(self.s_max+self.s_min)/2
            RK42=RK4_2(f=self.fcn,I=[self.x01,self.x02],
                       CI=[self.x01,[self.y01,self.s_mid]],h=self.h)
            R=RK42.resolution()
            y_end=R[-1][1][0]
            if abs(y_end-self.y02)<=ep or abs(self.s_max-self.s_min)<=ep:
                return self.s_mid
            elif y_end<self.y02:
                self.s_min=self.s_mid
            else:
                self.s_max=self.s_mid
        return self.s_mid

    def resolution(self):
        RK42=RK4_2(f=self.fcn,I=self.I,CI=[self.x01,
                 [self.y01,self.angle_tir]],h=self.h)
        R=RK42.resolution()
        return R


import matplotlib.pyplot as plt            
if __name__ == "__main__":
    h=0.01
    y=lambda x: sin(x)
    R_exact=[[x*h,y(x*h)] for x in range(-700,701)]
    Tr=Tir(f="-y",I=[-7,7],CI=[[0,pi/2],[0,1]],h=h)

    #y=lambda x: exp(2*x)
    #R_exact=[[x*h,y(x*h)] for x in range(-100,301)]
    #Tr=Tir(f="4*y",I=[-1,3],CI=[[0,1],[1,exp(2)]],h=h)
    
    R=Tr.resolution()
    
    
    x_ex=[x[0] for x in R_exact]
    y_ex=[x[1] for x in R_exact]
    x_RK2=[x[0] for x in R]
    y_RK2=[x[1][0] for x in R]

    mse_rk4=[(y-y1)**2 for y,y1 in zip(y_ex,y_RK2)]
    mse_rk4=(sum(mse_rk4)/len(mse_rk4))*100

    plt.plot(x_ex, y_ex, label='Exact', color='black')
    plt.plot(x_RK2, y_RK2, label=f'RK4 :{mse_rk4:.2f}%', color='green')

    # Mise en forme
    plt.title('''Methode de Tir pour une EDO du 2 eme ordre, y"=-y''')
    plt.xlabel("t")
    plt.ylabel("y")
    plt.grid(True)
    plt.legend()
    plt.show()
    
        
        
    

##import matplotlib.pyplot as plt
##
##if __name__ == "__main__":
##    h=0.01
##    y=lambda x: (3/2)*sin(x)-0.5*x*cos(x)
##    RK4=RK4_2(f="sin(x)-y",I=[0,6],CI=[0,[0,1]],h=h)
##    #y=lambda x: x*exp(x)+(1/2)*(x**2)*exp(x)
##    #RK4=RK4_2(f="2*z-y+exp(x)",I=[-2,2],CI=[0,[0,1]],h=h)
##
##    #y=lambda x: 2*exp(x)-exp(2*x)
##    #RK4=RK4_2(f="-2*y+3*z",I=[-2,2],CI=[0,[1,0]],h=h)
##
##    R=RK4.resolution()
##    R_exact=[[x*h,y(x*h)] for x in range(0,601)]
##    x_ex=[x[0] for x in R_exact]
##    y_ex=[x[1] for x in R_exact]
##    x_RK2=[x[0] for x in R]
##    y_RK2=[x[1][0] for x in R]
##
##    mse_rk4=[(y-y1)**2 for y,y1 in zip(y_ex,y_RK2)]
##    mse_rk4=(sum(mse_rk4)/len(mse_rk4))*100
##
##    plt.plot(x_ex, y_ex, label='Exact', color='black')
##    plt.plot(x_RK2, y_RK2, label=f'RK4 :{mse_rk4:.2f}%', color='green')
##
##    # Mise en forme
##    plt.title("Methode de Runge-Kutta 2 pour une EDO du 2 eme ordre")
##    plt.xlabel("t")
##    plt.ylabel("y")
##    plt.grid(True)
##    plt.legend()
##    plt.show()
##    

   



##y(x0=0)=2
##y'(x)=y(x)
## h=0.1
## Exact y=2*e^x

##import matplotlib.pyplot as plt
##
##
##if __name__ == "__main__":
##    y=lambda x: 2*exp(x)
##    h=0.01
##    eul=Euler(f="y",I=[-2,2],CI=[0,2],h=h)
##    RK2=RK2(f="y",I=[-2,2],CI=[0,2],h=h)
##    RK4=RK4(f="y",I=[-2,2],CI=[0,2],h=h)
##    R_exact=[[x*h,y(x*h)] for x in range(-200,201)]
##    R_eul=eul.resolution()
##    R_RK2=RK2.resolution()
##    R_RK4=RK4.resolution()
##    x_ex=[x[0] for x in R_exact]
##    y_ex=[x[1] for x in R_exact]
##    x_eul=[x[0] for x in R_eul]
##    y_eul=[x[1] for x in R_eul]
##    x_RK2=[x[0] for x in R_RK2]
##    y_RK2=[x[1] for x in R_RK2]
##    x_RK4=[x[0] for x in R_RK4]
##    y_RK4=[x[1] for x in R_RK4]
##
##    #Calcul de l'erreur moyenne
##    mse_el=[(y-y1)**2 for y,y1 in zip(y_ex,y_eul)]
##    mse_eul=(sum(mse_el)/len(mse_el))*100
##    mse_R2=[(y-y1)**2 for y,y1 in zip(y_ex,y_RK2)]
##    mse_RK2=(sum(mse_R2)/len(mse_R2))*100
##    mse_R4=[(y-y1)**2 for y,y1 in zip(y_ex,y_RK4)]
##    mse_RK4=(sum(mse_R4)/len(mse_R4))*100
##
##    #Tracer les courbes
##    plt.plot(x_ex, y_ex, label='Exact', color='blue')
##    plt.plot(x_eul, y_eul, label=f'Euler : {mse_eul:.2f}%', color='red')
##    plt.plot(x_RK2, y_RK2, label=f'RK2 : {mse_RK2:.2f}%', color='black')
##    plt.plot(x_RK4, y_RK4, label=f'RK4 : {mse_RK4:.2f}%', color='green')
##
##    # Mise en forme
##    plt.title("Comparaison approximation et solution exacte h=0.5")
##    plt.xlabel("x")
##    plt.ylabel("y")
##    plt.grid(True)
##    plt.legend()
##    plt.show()
    
    
    
    
    
