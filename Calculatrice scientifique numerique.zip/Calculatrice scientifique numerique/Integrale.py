
from math import *
class integration(object):
    def __init__(self,f,a,b,n):
        self.fnc=eval("lambda x :"+f)
        self.a,self.b,self.n=a,b,n
        self.poids_pivots=self.poids_pivots()
        

    def poids_pivots(self):
        raise NotImplementedError

    def integrale(self):
        inte=sum(w*fx for w, fx in self.poids_pivots)
        return inte
        

class Rectangle(integration):
    def __init__(self,f,a,b,n):
        super().__init__(f,a,b,n)

    def poids_pivots(self):
        h=(self.b-self.a)/self.n
        po_piv=[(h,self.fnc(self.a+j*h)) for j in range(self.n)]
        return po_piv


class Trapeze(integration):
    def __init__(self,f,a,b,n):
        super().__init__(f,a,b,n)

    def poids_pivots(self):
        h=(self.b-self.a)/self.n
        po_piv=[(h/2,self.fnc(self.a+j*h)+self.fnc(self.a+(j+1)*h))
                for j in range(self.n)]
        return po_piv
    
class Simpson(integration):
    def __init__(self,f,a,b,n):
        super().__init__(f,a,b,n)

    def poids_pivots(self):
        h=(self.b-self.a)/self.n
        po_piv=[(h/6,self.fnc(self.a)),(h/6,self.fnc(self.b))]
        x1=[(self.a+j*h) for j in range(1,self.n)]
        x2=[(2*self.a+(2*j+1)*h)/2 for j in range(self.n)]
        for x in x1:
            po_piv.append((h/6,2*self.fnc(x)))
        for x in x2:
            po_piv.append((h/6,4*self.fnc(x)))
            
        return po_piv

class Romberg(object):
    def __init__(self,f,a,b,n):
        self.fnc=eval("lambda x :"+f)
        self.f=f
        self.a=a
        self.b=b
        self.n=n
    def integrale(self):
        a=self.a
        b=self.b
        n=self.n
        f=self.f
        T0=(b-a)*(self.fnc(a)+self.fnc(b))/2
        tableau=[[T0]]
        for i in range(1,n):
            tableau.append([Trapeze(f,a,b,2**i).integrale()])
        for k in range(1,n):
            for j in range(1,k+1):
                T=((4**j)*tableau[k][j-1]-tableau[k-1][j-1])/(4**j-1)
                tableau[k].append(T)
        return tableau[n-1][n-1]
        
class Gauss(integration):
    def __init__(self,f,a,b,n):
        super().__init__(f,a,b,n)
        
    def LegendreApp(self,xi,n):
        p0=1
        p1=xi
        for i in range(1,n):
            p=((2*i+1)*xi*p1-i*p0)/(i+1)
            p0,p1=p1,p
        dp=n*(xi*p1-p0)/(xi**2-1)
        return p, dp
    
    def poidsNoeuds(self,n ,tol=1e-14):
        W=[]
        X=[]
        NbreXip=(n+1)//2
        for i in range(NbreXip):
            xi=cos(pi*(2*i+1.5)/(2*n+1))
            for k in range(50):
                p,dp=self.LegendreApp(xi,n)
                dx=-p/dp
                xi=xi+dx
                if abs(dx)<=tol:
                    wi=2/((1-xi**2)*(dp**2))
                    X.append(xi)
                    W.append(wi)
                    X.append(-xi)
                    W.append(wi)
                    break
        PoidsNoeuds=[(w,x) for w,x in zip(W,X)]
        return PoidsNoeuds
        
    def poids_pivots(self):
        a,b,n,f=self.a,self.b,self.n,self.fnc
        po_piv=[((b-a)*0.5*wi,f((b-a)*0.5*xi+(b+a)*0.5))
                for wi,xi in self.poidsNoeuds(n)]
        return po_piv


if __name__ == "__main__":

    Entete="|{:^5}|{:^12}|{:^12}|{:^13}|{:^13}|{:^13}|".format("N","Rectangle",
                                                      "Trapeze","Simpson",
                                                      "Romberg","Gauss")
    print("-"*75)
    print(Entete)
    print("-"*75)
    I=pi/4
    for i in range(1,10):
        r=Rectangle("1/(1+x**2)",0,1,2*i)
        t=Trapeze("1/(1+x**2)",0,1,2*i)
        s=Simpson("1/(1+x**2)",0,1,2*i)
        ro=Romberg("1/(1+x**2)",0,1,i)
        g=Gauss("1/(1+x**2)",0,1,2*i)
        Error=[abs(eval(m).integrale()-I)/I for m in ['r','t','s','ro','g']]
        ligne="| {:^4d}|{:^12.2e}|{:^12.2e}| {:^12.2e}| {:^12.2e}| {:^12.2e}|".format(i,
                                                        Error[0],
                                                      Error[1],Error[3],
                                                      Error[4],Error[2])
        print(ligne)
        print("-"*75)
        
        

    
