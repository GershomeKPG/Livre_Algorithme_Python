from tkinter import *
from tkinter import ttk
from Calculer import calcul


class ComandeRes(ttk.Frame):
    def __init__(self, parent,actionC=None,actionVar=None):
        self.calcul=calcul(self.SetVariable)
        self.style=ttk.Style()
        self.colf="#2B579A"
        self.style.configure("b.TFrame",
                             background=self.colf)
        
        super().__init__(parent,style="b.TFrame")
        self.Commande=[]
        self.indexCommande=-1
        self.Parametre={
            'Equation':{
                'Iteration': '5000',
                'Epsilon': '2.2e-10',
                'Methode': 'Secante'},
            'EDO': {
                'h': '1e-1',
                'Methode': 'RK4'
                }}
        self.Eqtouch={'Equation':{'Secante':'Equation(fx=. . .=0,[a,b])',
                                  'Bissection':'Equation(fx=. . .=0,[a,b])',
                                  'Regula Falsi':'Equation(fx=. . .=0,[a,b])',
                                  'Newton':'Equation(fx=. . .=0,dfx=. . .=0,[a,b])',
                                  'Point Fixe':'Equation(fx=. . .=0,gx=. . .=0,[a,b])'},
                      'EDO':{'Euler':"EDO(y'=. . .,CI=[x0=. . ., y0=. . .], I=[. . ., . . .])",
                             'RK2':"EDO(y'=. . ., CI=[x0=. . ., y0=. . .], I=[. . ., . . .])",
                             'RK4':"EDO(y'=. . ., CI=[x0=. . ., y0=. . .], I=[. . ., . . .])",
                             'Tir':"EDO(f=. . ., CI=[[x01=. . ., y01=. . .], [x02=. . ., y02=. . .]], I=[. . ., . . .])",
                             'RK4_2':"EDO(f=. . ., CI=[x0=. . ., [y0=. . ., dy0=. . .]], I=[. . ., . . .])"}}

        self.ActionC=actionC
        self.ActionVar=actionVar
        self.Es=Text()
        self.bande=Text()
        self.construction()
        self.prompt = ">> "
        self.inserer_prompt()

        self.Es.bind("<Return>", self.Executer)
        self.Es.bind("<BackSpace>", self.Supprimer)
        self.Es.bind("<Up>", self.commande_precedente)
        self.Es.bind("<Down>", self.commande_suivante)

    def construction(self):
        self.style = ttk.Style()
        self.style.theme_use('clam')

        self.style.configure("a.TLabel",background="#2B579A",foreground="#FFFFFF",
                             font=('Segoe UI italic',10))
        
        self.rowconfigure(0,weight=0)
        self.columnconfigure(0,weight=0)
        self.rowconfigure(1,weight=1)
        self.columnconfigure(1,weight=1)
        
        fen=self

        txt=ttk.Label(fen,text=">>Commande",style='a.TLabel')
        self.bande=Text(fen,width=2,bg='#b0b0b0',fg='#000000',font=('Cambria italic',12),wrap='word')
        self.Es=Text(fen,fg='#000000',font=('Cambria',12),wrap='word')
        self.Es.focus()
        self.Es.tag_configure('erreur',foreground='red')
        self.Es.tag_configure('resultat',foreground='blue')
        self.bande.tag_configure('bande',justify='center')
        self.bande.insert(END,'fx','bande')
   
        txt.grid(row=0,column=0,columnspan=2,padx=2,pady=2,sticky='ew')
        self.bande.grid(row=1,column=0,padx=2,pady=2,sticky='ns')
        self.Es.grid(row=1,column=1,padx=2,pady=2,sticky='ewns')

    def inserer_text(self,text):
        if text=='↵':
            self.Executer()
        elif text=='⇦':
            self.Es.focus_set()
            self.Es.event_generate("<BackSpace>")
        else:
            if text.strip() in self.Eqtouch:
                print(text)
                self.Es.insert(END, self.Eqtouch[text.strip()][self.Parametre[text.strip()]['Methode']])
            else:
                self.Es.insert(END,text)
            self.Es.mark_set("insertion_point", END)
            self.Es.focus_set()

    def inserer_prompt(self):
        self.Es.insert(END, self.prompt)
        self.Es.mark_set("insertion_point", END)

    def Supprimer(self,event=None):
        ligne = self.Es.get("insert linestart", "insert")
        if ligne.strip() == self.prompt.strip():
            return "break"

    def Executer(self,event=None):
        ligne = self.Es.get("insert linestart", "insert lineend")
        commande = ligne.replace(self.prompt, "", 1).strip()
        self.Commande.append(commande)
        self.ActionC(self.Commande)
        if commande=='clc':
            self.Es.delete(0.0,END)
            self.inserer_prompt()
            self.Es.see(END)
            self.bande.delete(0.0,END)
            self.bande.insert('0.0','fx','bande')
            del self.Commande[:]
            self.calcul.clear()
            return "break"
        else:
            try:
                #resultat = eval(commande)
                self.calcul.actualiseParam(self.Parametre)
                resultat=self.calcul.executer(commande)
                if resultat is not None:
                    self.Es.insert(END, f"\n\n\t{resultat}\n",'resultat')
            except Exception as e:
                try:
                    exec(commande)
                except Exception as ex:
                    self.Es.insert(END, f"\n{ex}",'erreur')

            self.Es.insert(END, "\n")
            self.inserer_prompt()
            self.Es.see(END)
            nombreligne=len(self.Es.get(0.0,END).split('\n'))
            self.bande.delete(0.0,END)
            self.bande.insert('0.0','\n'*(nombreligne-2)+'fx','bande')
            return "break"

    def commande_precedente(self, event):
        if self.indexCommande > 0:
            self.indexCommande -= 1
            self.placerligne(self.Commande[self.indexCommande])
        return "break"

    def commande_suivante(self, event):
        if self.indexCommande < len(self.Commande) - 1:
            self.indexCommande += 1
            self.placerligne(self.Commande[self.indexCommande])
        else:
            self.indexCommande = len(self.Commande)
            self.placerligne("")
        return "break"

    def placerligne(self, nouvelle_commande):
        self.Es.delete("insert linestart + %dc" % len(self.prompt), "insert lineend")
        self.Es.insert("insert lineend", nouvelle_commande)

    def SetParametre(self,param):
        self.Parametre[param[0]]=param[1]
        #print(self.Parametre)
    def SetVariable(self,var):
        self.ActionVar(var)


        

if __name__=="__main__":
    boot=Tk()
    cl=ComandeRes(boot)
    cl.pack(expand=True,fill='both')
