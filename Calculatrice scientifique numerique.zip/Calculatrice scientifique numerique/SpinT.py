from tkinter import *
from tkinter import ttk

class Spin_text(ttk.Frame):
    def __init__(self,root,txt,commande,style,de=0,fin=100,pas=5):
        super().__init__(root,style=style)
        self.ent=Spinbox(self,justify='center',from_=de,to=fin,increment=pas,
                         command=commande,width=15, font=('Segoe UI', 11),bg='white',fg='black')
        self.txt=Label(self,justify='center',text=txt,font=('Segoe UI Italic', 11),bg='white',fg='black')
        self.ent.delete(0,END)
        self.ent.insert(0,str((de+fin)/2))
        self.ent.grid(row=1,column=0,padx=2,pady=2)
        self.txt.grid(row=0,column=0,padx=2,pady=2)

    def get(self):
        return self.ent.get()

class Entry_text(ttk.Frame):
    def __init__(self,root,txt,commande,style,init='2.2e-10'):
        super().__init__(root,style=style)
        self.ent=Entry(self,justify='center',width=15, font=('Segoe UI', 11),bg='white',fg='black')
        self.txt=Label(self,justify='center',text=txt,font=('Segoe UI Italic', 11),bg='white',fg='black')
        self.ent.delete(0,END)
        self.ent.insert(0,init)

        self.ent.bind('<Return>',commande)

        self.ent.grid(row=1,column=0,padx=2,pady=2)
        self.txt.grid(row=0,column=0,padx=2,pady=2)

    def get(self):
        return self.ent.get()


if __name__=="__main__":

    def getter():
        print(cl.get())

    def geter(event):
        print(txt.get())
        
        
    
    boot=Tk()
    style = ttk.Style()
    style.theme_use('clam')
    style.configure("a.TFrame",
                             background="#FFFFFF",
                             foreground="#FFFFFF")


    cl=Spin_text(boot,style='a.TFrame',txt='Iteration',commande=getter, de=0,fin=40,pas=1)
    txt=Entry_text(boot,style='a.TFrame',txt='Epsilon',commande=geter)
    cl.pack()
    txt.pack()
