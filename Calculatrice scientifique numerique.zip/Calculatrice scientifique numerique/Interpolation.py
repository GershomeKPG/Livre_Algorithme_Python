from math import *
import sympy as sp

class interpolation(object):
    def __init__(self,liste):
        self.liste=liste
        self.coef=[]
        
    def resoudre(self):
        raise NotImplementedError

    def P(self,x):
        raise NotImplementedError

    def interpol(self):
        # declaration d'un symbole
        #variable pour le polynome
        t=sp.Symbol('x')
        self.resoudre()
        p=self.P(t)
        #effectue l'operation sur le
        # polynome
        p=sp.simplify(p)
        return "P(x)="+str(p)

class Lagrange(interpolation):
    def __init__(self,liste):
        super().__init__(liste)

    def resoudre(self):
        n=len(self.liste)
        self.coef=[]
        for i in range(n):
            [xi,yi]=self.liste[i]
            c=[]
            coe=1
            for j in range(n):
                if i!=j:
                    xj=self.liste[j][0]
                    coe*=(xi-xj)
                    c.append(xj)
            self.coef.append([yi/coe,c])

    def P(self,x):
        y=0
        for coeff,xks in self.coef:
            yy=1
            for xk in xks:
                yy=yy*(x-xk)
            y+=yy*coeff
        return y

class DifferenceDivisee(interpolation):
    def __init__(self,liste):
        super().__init__(liste)

    def resoudre(self):
        n=len(self.liste)
        tableau=[[y[1]] for y in self.liste]
        for i in range(1,n):
            for k in range(1,i+1):
                c=((tableau[i][k-1]-tableau[i-1][k-1])/
                   (self.liste[i][0]-self.liste[i-k][0]))
                tableau[i].append(c)
        self.coef=[ligne[-1] for ligne in tableau]

    def P(self,x):
        y=self.coef[0]        
        for coeff,pos in zip(self.coef[1:],list(range(0,len(self.liste)))):
            yy=1
            for i in range(0,pos+1):
                xi=self.liste[i][0]
                yy=yy*(x-xi)
            y+=yy*coeff
        return y
    


##if __name__ == "__main__":
##    l=Lagrange([(-2,-23),(-1,-5),(0,1),(1,1),(3,7)])
##    dif=DifferenceDivisee([(-2,-23),(-1,-5),(0,1),(1,1),(3,7)])
##    Px_L=l.interpol()
##    Px_D=dif.interpol()
##    print("Lagrange :",Px_L)
##    print("Difference Divise :",Px_D)

                
##import matplotlib.pyplot as plt
##import random
##if __name__ == "__main__":
##    a=pi/2
##    b=4*pi
##    X=[]
##    Nbre_Point=30
##    while a<b:
##        X.append(a)
##        a+=0.1
##    y=lambda x: exp(-x)+sin(2*x)/x
##    R_exact=[[x,y(x)] for x in X]
##    xy=[]
##    start=0
##    for i in range(0,Nbre_Point):
##        start+=random.randint(1,5)
##        xy.append(R_exact[start])
##
##    l=Lagrange(xy)
##    dif=DifferenceDivisee(xy)
##    Px_L=l.interpol()
##    Px_D=dif.interpol()
##    
##    P_L=[[x,l.P(x)] for x in X]
##    P_D=[[x,dif.P(x)] for x in X]
##
##    x_ex, y_ex=[x[0] for x in R_exact],[x[1] for x in R_exact]
##    x_L, y_L=[x[0] for x in P_L],[x[1] for x in P_L]
##    x_D, y_D=[x[0] for x in P_D],[x[1] for x in P_D]
##
##    mse_L=[(y-y1)**2 for y,y1 in zip(y_ex,y_L)]
##    mse_L=(sum(mse_L)/len(mse_L))*100
##    mse_D=[(y-y1)**2 for y,y1 in zip(y_ex,y_D)]
##    mse_D=(sum(mse_D)/len(mse_D))*100
##
##    plt.plot(x_ex, y_ex, label='Exact', color='black')
##    plt.plot(x_L, y_L, label=f'Lagrange :{mse_L:.2f}%', color='green')
##    plt.plot(x_D, y_D, label=f'Diff_ Div :{mse_D:.2f}%', color='red')
##
##    # Mise en forme
##    plt.title('''Interpolation de la fonction f(x)= exp(-x)+(sin(2x)/x)''')
##    plt.xlabel("x")
##    plt.ylabel("P(x)")
##    plt.grid(True)
##    plt.legend()
##    plt.show()


import matplotlib.pyplot as plt
import random
if __name__ == "__main__":
    a=pi/2
    b=4*pi
    X=[]
    Nbre_Point=30
    while a<b:
        X.append(a)
        a+=0.1
    y=lambda x: exp(-x)+sin(2*x)/x
    R_exact=[[x,y(x)] for x in X]
    entete="|{:^12}|{:^14}|{:^14}|".format("Nbre_Point","Lagrange",
                                             "Diff_Divisee")
    print("-"*44);print(entete); print("-"*44)

    for nbr in range(5,Nbre_Point,4):
        xy=[]
        start=0
        for i in range(0,nbr):
            start+=random.randint(1,5)
            xy.append(R_exact[start])

        l=Lagrange(xy)
        dif=DifferenceDivisee(xy)
        Px_L=l.interpol()
        Px_D=dif.interpol()

        P_L=[[x,l.P(x)] for x in X]
        P_D=[[x,dif.P(x)] for x in X]

        x_ex, y_ex=[x[0] for x in R_exact],[x[1] for x in R_exact]
        x_L, y_L=[x[0] for x in P_L],[x[1] for x in P_L]
        x_D, y_D=[x[0] for x in P_D],[x[1] for x in P_D]

        mse_L=[(y-y1)**2 for y,y1 in zip(y_ex,y_L)]
        mse_L=(sum(mse_L)/len(mse_L))*100
        mse_D=[(y-y1)**2 for y,y1 in zip(y_ex,y_D)]
        mse_D=(sum(mse_D)/len(mse_D))*100

        res="|{:^12d}|{:^14.2e}|{:^14.2e}|".format(nbr,mse_L,mse_D)
        print(res); print("-"*44)

        

