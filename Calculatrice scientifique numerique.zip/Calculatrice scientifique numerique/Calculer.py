from math import *
from cmath import *
from NonLineaire import *
from EDO import*
import matplotlib.pyplot as plt



class calcul(object):
    def __init__(self,actionVar=None):
        self.variable={}
        self.actionVar=actionVar
        self.action={'Equation':self.EqLn,'EDO':self.edo}
        self.commande=['Derive','Integral','EDO',
                       'Interpolation','Equation','Systeme',
                       'Matrice','Inverse','somme',
                       'Diagonal','Produit','Vecteur',
                       'Polar','Cartesienne','Tracer',
                       'Residus','convolution','Laplace',
                       'ReLU','Sig','ELU','Softmax']
        self.Parametres = {
            'EDO': {
                'h': '1e-1',
                'Methode': 'RK4'
                },
            'Equation': {
                'Iteration': '5000',
                'Epsilon': '2.2e-10',
                'Methode': 'Secante'
                }
            }
    

    def executer(self,txt):
        text=txt.split('=')
        if(len(text)>=2 and not '(' in text[0]):
            #com=self.variable_place(text[1])
            com=self.variable_place(txt.replace(text[0]+'=',''))
            self.variable[text[0]]= self.executer(com)
            self.actionVar(self.variable)
            if not(text[1].isdigit()):
                resultat='{} = {}'.format(text[0],self.variable[text[0]])    
        else:
            coma=self.variable_place(txt)
            val=self.VerifierFactoriel(coma)
            commande=self.findCommande(val)
            if commande==None:
                resultat = eval(val)
            else:
                resultat=self.action[commande](val)
        return resultat

    def variable_place(self,exp):
        list_ord=sorted(self.variable.keys(),key=len,reverse=True)
        for v in list_ord:
            exp=exp.replace(v,'('+str(self.variable[v])+')')
        return exp

    def clear(self):
        self.variable={}

    def VerifierFactoriel(self,expression):
        while '!' in expression:
            point=expression.index('!')
            if expression[point-1]!=')':
                for i in range(point-1,-1,-1):
                    if (expression[i].isdigit()or expression[i]=='.') and i!=0:
                        continue
                    else:
                        e=(expression[i+1:point])if i!=0 else (expression[i:point])
                        expression=expression.replace(e+"!",str(eval("factorial(("+e+"))")))
                        break
            else:
                for i in range(point-2,-1,-1):
                    if expression[i]=='(' and i!=0:
                        continue
                    else:
                        e=expression[i+1:point]if i!=0 else (expression[i:point])
                        if e.count('(')==e.count(')'):
                            expression=expression.replace(e+"!",str(eval("factorial(int("+e+"))")))
                            break
                        else:
                            continue
        return expression

    def findCommande(self,val):
        for c in self.commande:
            if c in val:
                return c.strip()
        return None
    def actualiseParam(self,param):
        self.Parametres=param

    def EqLn(self,param):
        param=param.replace(" ","")
        
        p=self.Parametres['Equation']
        if p['Methode'].strip() in ['Bissection','Secante','Regula Falsi']:

            ## Equation(fx=3*x**2-3=0,[a,b])
            
            param=((param.replace('Equation','')).strip()).replace('fx=','').replace('=0','')
            param=param[1:-1]
            fx=param.split(',')[0]
            a=float((param.split(',')[1])[1:])
            b=float((param.split(',')[2])[:-1])
            if p['Methode'].strip()=='Secante':
                ob=Secante([a,b],IMax=eval(p['Iteration']),eps=eval(p['Epsilon']))
                result=ob.resolution(fx)
            elif p['Methode'].strip()=='Regula Falsi':
                ob=RegulaFalsi([a,b],IMax=eval(p['Iteration']),eps=eval(p['Epsilon']))
                result=ob.resolution(fx)
                #print('regula')
            else:
                ob=Bissection([a,b],IMax=eval(p['Iteration']),eps=eval(p['Epsilon']))
                result=ob.resolution(fx)
                #print('bissection')
            
        else:
            ## Equation(fx=3*x**2-3=0,gx(dfx)=3x-2=0,[a,b])

            param=((param.replace('Equation','')).strip()).replace('dfx=','').replace('fx=','').replace('=0','').replace('gx=','')
            param=param[1:-1]
            fx=param.split(',')[0]
            gx=param.split(',')[1]
            a=float((param.split(',')[2])[1:])
            b=float((param.split(',')[3])[:-1])
            if p['Methode'].strip()=='Newton':
                ob=NewTon([a,b],IMax=eval(p['Iteration']),eps=eval(p['Epsilon']))
                result=ob.resolution(fx,gx)
            else:
                ob=PointFixe([a,b],IMax=eval(p['Iteration']),eps=eval(p['Epsilon']))
                result=ob.resolution(gx)
                #print(fx)
                #print(gx)

        return result
        
    def edo(self,param):
        param=param.replace(" ","")
        try:        
            p=self.Parametres['EDO']
        except ValueError as e:
            print('valeur',e)
        except KeyError as e:
            print('Key',e)
        except Exception as e:
            print('Exception',e)
        print(p)
        if p['Methode'].strip() in ['Euler','RK2','RK4']:
            print('Par')

            ## EDO(y'=y,CI=[x0=0,y0=2],I=[-2,2])
            
            param=((param.replace('EDO','')).strip()).replace("y'=",'').replace('x0=','').replace('y0=','').replace('CI=','').replace('I=','')
            param=param[1:-1]
            f=param.split(',')[0]           
            x0=float((param.split(',')[1])[1:])
            y0=float((param.split(',')[2])[:-1])
            a=float((param.split(',')[3])[1:])
            b=float((param.split(',')[4])[:-1])
            I=[a,b]
            CI=[x0,y0]
            h=float(p['h'])
            eul=Euler(f=f,I=I,CI=CI,h=h)
            RK22=RK2(f=f,I=I,CI=CI,h=h)
            RK44=RK4(f=f,I=I,CI=CI,h=h)
            eq={'Euler':eul,'RK2':RK22,'RK4':RK44}
            result=eq[p['Methode']].resolution()

            x=[x[0] for x in result]
            y=[x[1] for x in result]
            plt.plot(x, y, label="y=f(x)", color='green')
            plt.title(f'''EDO du 1 ere ordre,methode de {p['Methode']}''')
            plt.xlabel("t")
            plt.ylabel("y")
            plt.grid(True)
            plt.legend()
            plt.show()
          
            
        elif p['Methode'].strip() in ['Tir']:

            #Tr=EDO(f=-y,CI=[[x01=0,y01=0],[x02=pi/2,y02=1]],I=[-7,7])

            param=((param.replace('EDO','')).strip()).replace("f=",'').replace('x01=','').replace('y01=','').replace('CI=','').replace('I=','').replace('x02=','').replace('y02=','')
            param=param[1:-1]
            f=param.split(',')[0]
            
            x01=float(eval((param.split(',')[1])[2:]))
            y01=float(eval((param.split(',')[2])[:-1]))
            x02=float(eval((param.split(',')[3])[1:]))
            y02=float(eval((param.split(',')[4])[:-2]))
            
            a=float((param.split(',')[5])[1:])
            b=float((param.split(',')[6])[:-1])
            I=[a,b]
            CI=[[x01,x02],[y01,y02]]
            h=float(p['h'])
            Tr=Tir(f=f,I=I,CI=CI,h=h)
            result=Tr.resolution()
            x=[x[0] for x in result]
            y=[x[1][0] for x in result]
            dy=[x[1][1] for x in result]

            plt.plot(x, y, label='y=f(x)', color='black')
            plt.plot(x, dy, label="y=df(x)/dx", color='green')
            plt.title('''Methode de Tir pour une EDO du 2 eme ordre''')
            plt.xlabel("t")
            plt.ylabel("y")
            plt.grid(True)
            plt.legend()
            plt.show()
          
        elif p['Methode'].strip() in ['RK4_2']:

            #RK4=EDO(f=2*z-y+exp(x),CI=[x0=0,[y0=0,dy0=1]],I=[-2,2],h=h)

            param=((param.replace('EDO','')).strip()).replace("f=",'').replace('x0=','').replace('dy0=','').replace('y0=','').replace('CI=','').replace('I=','')
            param=param[1:-1]
            f=param.split(',')[0]
            
            
            x0=float(eval((param.split(',')[1])[1:]))
            y0=float(eval((param.split(',')[2])[1:]))
            dy0=float(eval((param.split(',')[3])[:-2]))
            
            a=float((param.split(',')[4])[1:])
            b=float((param.split(',')[5])[:-1])
            I=[a,b]
            CI=[x0,[y0,dy0]]
            h=float(p['h'])
            
            rk=RK4_2(f=f,I=I,CI=CI,h=h)            
            result=rk.resolution()
            x=[x[0] for x in result]
            y=[x[1][0] for x in result]
            dy=[x[1][1] for x in result]

            plt.plot(x, y, label='y=f(x)', color='black')
            plt.plot(x, dy, label="y=df(x)/dx", color='green')
            plt.title('''Methode de Runge-Kutta d'ordre 4 pour une EDO du 2 eme degre''')
            plt.xlabel("t")
            plt.ylabel("y")
            plt.grid(True)
            plt.legend()
            plt.show()
          
            
        return result
