from tkinter import *
from tkinter import ttk
from Menu import *
from clavier import *
from Commande import *
from TabVariable import *

class Application:
    def __init__(self, parent):
        fen = parent
        fen.title("Calculatrice Numerique")
        fen.iconbitmap("calcu.ico")
        #fen.configure(bg="#2B579A")
        fen.geometry("1200x810")  

        fen.columnconfigure(0, weight=1)
        fen.rowconfigure(0, weight=0)
        fen.rowconfigure(1, weight=1)
        #fen.columnconfigure(1, weight=0)

        style = ttk.Style()
        style.theme_use('clam')

        style.configure("a.TFrame",
                                     background="#FFFFFF",
                                     foreground="#FFFFFF")

        fr=ttk.Frame(fen,heigh=3,style='a.TFrame')

        bar=BarreMenu(fen,self.ParametreENL)

        pan=PanedWindow(fen,orient=HORIZONTAL, sashwidth=5,
                        sashrelief=RAISED)

        self.touche=Clavier(pan,self.ActionClavier)
        self.com=ComandeRes(pan,self.CommandeSet,self.VariableSet)

        #f3=ttk.Frame(pan,width=5)
        self.f3=TabVariable(pan)
        pan.add(self.touche)
        pan.add(self.com)
        pan.add(self.f3)

        bar.grid(row=0,column=0,sticky='ew')
        fr.grid(row=1,column=0,sticky='nsew')
        pan.grid(row=2,column=0,sticky='nsew')

    def ActionClavier(self,char):
        self.com.inserer_text(char)
    def ParametreENL(self,param):
        self.com.SetParametre(param)
    def CommandeSet(self,com):
        self.f3.setCom(com)
    def VariableSet(self,var):
        self.f3.setVar(var)

if __name__=='__main__':
    root=Tk()
    app=Application(root)
    root.mainloop()
