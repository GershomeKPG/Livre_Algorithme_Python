from math import *

class derive(object):
    def __init__(self,f,h=1e-8):
        self.h=h
        self.f=eval("lambda x:"+f)

class Diff1(derive):
    def __init__(self,f,x,h=1e-8):
        derive.__init__(self,f,h)
        self.x=x
    def __call__(self):
        dfx=(self.f(self.x)-self.f(self.x-self.h))/self.h
        return dfx

class Diff2(derive):
    def __init__(self,f,x,h=1e-8):
        derive.__init__(self,f,h)
        self.x=x
    def __call__(self):
        dfx=(-self.f(self.x+2*self.h)+
             4*self.f(self.x+self.h)-
             3*self.f(self.x))/(2*self.h)
        return dfx

class Diff3(derive):
    def __init__(self,f,x,h=1e-8):
        derive.__init__(self,f,h)
        self.x=x
    def __call__(self):
        dfx=(-(1/6)*self.f(self.x+2*self.h)+
             self.f(self.x+self.h)-
             (1/2)*self.f(self.x)-
             (1/3)*self.f(self.x-self.h))/self.h
        return dfx
        
#f(x)=xe^x
df=lambda x: (1+x)*exp(x)
entete="|{:^5}|{:^10}|{:^10}|{:^10}|".format("h","Ordre 1",
                                             "Ordre 2","Ordre 3")
print("-"*40);print(entete); print("-"*40)
for i in range(5,11):
    d1=Diff1("x*exp(x)",1,10**(-i))
    d2=Diff2("x*exp(x)",1,10**(-i))
    d3=Diff3("x*exp(x)",1,10**(-i))
    diff=[eval(re) for re in ["d1","d2","d3"]]
    diff=[(abs(df(1)-re())/df(1))*100 for re in diff]
    res="|{:5.0e}|{:^10.5}|{:^10.5}|{:^10.5}|".format(10**(-i),
                                                      diff[0],
                                                      diff[1],diff[2])
    print(res); print("-"*40)

