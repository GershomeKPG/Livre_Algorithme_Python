from tkinter import *
from tkinter import ttk

class Clavier(ttk.Frame):
    def __init__(self, parent,action=None):
        self.style=ttk.Style()
        self.haut=70
        self.colf="#2B579A"
        self.style.configure("b.TFrame",
                             background=self.colf)
        
        super().__init__(parent,style="b.TFrame")
        self.construction()
        self.action=action

    def construction(self):
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("a.TFrame",
                             background="#FFFFFF",
                             foreground="#FFFFFF")

        self.style.configure("TButton",background="#FFFFFF",
                             font=('Segoe UI', 8))

        self.style.configure("a.TButton",background="#FFFFFF",
                             font=('Segoe UI', 9))
        self.rowconfigure(0,weight=1)
        self.rowconfigure(1,weight=1)
        self.columnconfigure(1,weight=1)
        
        
        fen=self

        frt1=ttk.Frame(fen,style='a.TFrame',width=200,heigh=400)
        frt2=ttk.Frame(fen,style='a.TFrame',width=200,heigh=400)

        for i in range(5):frt1.rowconfigure(i,weight=1)
        for i in range(3):frt1.columnconfigure(i,weight=1)
        for i in range(14):frt2.rowconfigure(i,weight=1)
        for i in range(4):frt2.columnconfigure(i,weight=1)


        touche1=[['Derive','Integral','  EDO  '],
                ['Interpolation','Equation','Systeme'],
                ['Matrice','Inverse',' somme '],
                ['Diagonal','Produit','Vecteur'],
                ['Polar','Cartesienne','Tracer'],
                ['Residus','convolution','Laplace']]
        touche2=[['sin','cos','tan','ReLU'],
                 ['sinh','cosh','tanh','Sig'],
                 ['asin','acos','atan','ELU'],
                 ['asinh','acosh','atanh','Softmax'],
                 ['log','ln','x^y','√'],
                 ['10^','e^','∛','x√y'],
                 ['π','j','(',')'],
                 ['!','%','x','y'],
                 ['z','t','f','g'],
                 ['+','-','[',']'],
                 ['×','÷','↵','⇦'],
                 ['6','7','8','9'],
                ['2','3','4','5'],
                ['Ans','.','0','1']]

        li=0
        co=0
        bout1=[ttk.Button(frt1,text=tch,width=13,style='a.TButton',
                          command=lambda ch=tch: self.ToucheClick(ch))
               for ligne in touche1 for tch in ligne ]
     
        for b in bout1:
            b.grid(row=co+2,column=li%3,padx=2,pady=2,sticky='nsew')
            li=li+1
            co=li//3
        li=0
        co=0
        bout2=[ttk.Button(frt2,text=tch,width=9,style='TButton',
                          command=lambda ch=tch: self.ToucheClick(ch))
               for ligne in touche2 for tch in ligne ]
     
        for b in bout2:
            b.grid(row=co+3,column=li%4,padx=2,pady=2,sticky='nsew')
            li=li+1
            co=li//4
            
        #frt1.grid(row=0,column=0,padx=2,pady=2)
        #frt2.grid(row=1,column=0,padx=2,pady=2)
        frt1.pack(expand=True,fill='both',anchor=NW,side=TOP,padx=2,pady=2)
        frt2.pack(expand=True,fill='both',anchor=NW,side=BOTTOM)

    def ToucheClick(self,ch):
        self.action(ch)



if __name__=="__main__":
    boot=Tk()
    cl=Clavier(boot)
    cl.pack()
