from tkinter import *
from tkinter import ttk
from SpinT import *
from PIL import Image, ImageTk


class BarreMenu(ttk.Frame):
    def __init__(self, parent,refer):
        self.style=ttk.Style()
        self.haut=100
        self.colf="#2B579A"
        self.style.configure("b.TFrame",
                             background=self.colf)
        self.Emethode={'sec':'Secante','new':'Newton','point':'Point Fixe','reg':'Regula Falsi','bis':'Bissection'}
        self.EmethodeI={}
        self.ENLP={'Iteration':'5000','Epsilon':'2.2e-10','Methode':'Secante'}

        self.EDOmethode={'Euler':'Euler','RK2':'RK2','RK4':'RK4','RK4_2':'RK4_2','Tir':'Tir'}
        self.EDOParam={'h':'1e-1','Methode':'RK4'}
        
        super().__init__(parent,style="b.TFrame")
        self.construction()
        self.refer=refer

    def construction(self):
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("a.TFrame",
                             background="#FFFFFF",
                             foreground="#FFFFFF")
        self.style.configure("TNotebook", background=self.colf,tabmargins=[0,0,0,0])
        self.style.configure("TNotebook.Tab",tabmargins=[0,0,0,0],
                             background="#FFFFFF", padding=[10, 5],
                             font=('Segoe UI', 10),focuscolor='',borderwidth=0)
        self.style.map("TNotebook.Tab", background=[("selected", "#FFFFFF"),
                                                    ("!selected", self.colf)],
                       foreground=[("selected", self.colf),
                                                    ("!selected", "#FFFFFF")])
        self.style.configure("button.TButton",
                             background="#FFFFFF",
                             font=('Segoe UI', 11,))
        
        fen=self

        bar=ttk.Notebook(fen,height=self.haut,takefocus=False)
        Menu_Fichier=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Accueil=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Enl=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_ED0=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Systeme=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Derive=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Integrale=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Inter=ttk.Frame(bar,height=self.haut,style="a.TFrame")
        Menu_Aide=ttk.Frame(bar,height=self.haut,style="a.TFrame")


        for pos,clk in enumerate(self.Emethode.keys()):
            img=Image.open("icone/ENL/"+clk+'.png').resize((55,55))
            ima=ImageTk.PhotoImage(img)
            self.EmethodeI[clk]=ima
            bt=ttk.Button(Menu_Enl,text=self.Emethode[clk],style="button.TButton",image=self.EmethodeI[clk],compound='top')
            bt.bind('<Button-1>',self.EqNonLMeth)
            bt.grid(row=0,column=pos,rowspan=2,padx=2,pady=2)
        self.cl=Spin_text(Menu_Enl,style='a.TFrame',txt='Iteration',commande=self.EnlIter, de=0,fin=10000,pas=5)
        self.txt=Entry_text(Menu_Enl,style='a.TFrame',txt='Epsilon',commande=self.EnlEps)
        self.txt.grid(column=5,row=0,padx=2,pady=3)#,rowspan=2)
        self.cl.grid(column=6,row=0,padx=2,pady=3)#,rowspan=2)



        for pos,clk in enumerate(self.EDOmethode.keys()):
            img=Image.open("icone/EDO/"+clk+'.png').resize((55,55))
            ima=ImageTk.PhotoImage(img)
            self.EmethodeI[clk]=ima
            bt=ttk.Button(Menu_ED0,text=self.EDOmethode[clk],style="button.TButton",image=self.EmethodeI[clk],compound='top')
            bt.bind('<Button-1>',self.EDOMeth)
            bt.grid(row=0,column=pos,rowspan=2,padx=2,pady=2)
        self.txt=Entry_text(Menu_ED0,style='a.TFrame',txt='h',commande=self.Enh,init='1e-1')
        self.txt.grid(column=5,row=0,padx=2,pady=3)#,rowspan=2)
    


        bar.add(Menu_Fichier,text=" Fichier  ")
        bar.add(Menu_Accueil,text="  Accueil  ")
        bar.add(Menu_Enl,text="  Equation Non Lineaire  ")
        bar.add(Menu_ED0,text="  EDO  ")
        bar.add(Menu_Systeme,text="  Systeme d'équation  ")
        bar.add(Menu_Derive,text="  Derivé  ")
        bar.add(Menu_Integrale,text="  Integration  ")
        bar.add(Menu_Inter,text="  Interpolation  ")
        bar.add(Menu_Aide,text="  Aide  ")
        bar.pack(expand=True,fill='x',anchor=NW)

    def EnlIter(self):
        self.ENLP['Iteration']=self.cl.get()
        self.SendENLP()
    def EnlEps(self,event):
        event.widget.master.focus_set()
        self.ENLP['Epsilon']=self.txt.get()
        self.SendENLP()
    def EqNonLMeth(self,event):
        self.ENLP['Methode']=event.widget['text']
        self.SendENLP()
    def SendENLP(self):
        self.refer(['Equation',self.ENLP])
    def Enh(self,event):
        event.widget.master.focus_set()
        self.EDOParam['h']=self.txt.get()
        self.SendEDO()
    def EDOMeth(self,event):
        self.EDOParam['Methode']=event.widget['text']
        self.SendEDO()
    def SendEDO(self):
        self.refer(['EDO',self.EDOParam])
        

        
        
if __name__=='__main__':
    root=Tk()
    app=BarreMenu(root)
    app.pack()
    root.mainloop()
