from tkinter import *
from tkinter import ttk

class TabVariable(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent)
        self.var=[]
        self.com=[]
        self.construire()
        self.construireCom()

    def construire(self):
        fen=self
        colon = ["Nom","Type","Valeur"]
        tab= ttk.Treeview(fen,columns=colon)

        #Ajout des en-tete des colonnes
        tab.heading("#0",text="N")
        tab.heading("Nom",text="Nom")
        tab.heading("Type",text="Type")
        tab.heading("Valeur",text="Valeur")

        #Formatage des colonnes
        tab.column("#0",width=50,anchor='center')
        tab.column("Nom",width=70,anchor='center')
        tab.column("Type",width=120,anchor='center')
        tab.column("Valeur",width=100,anchor='center')

        for id,data in enumerate(self.var):
            tab.insert("","end",iid=id,text=str(id),values=data)

        tab.grid(row=0,column=0,pady=2,padx=2,sticky='ew')

    def construireCom(self):
        fen=self
        fr=Frame(fen)
        lisB=Listbox(fr,justify='left',font="Arial 12",height=10,width=50)
        scl=Scrollbar(fr,command=lisB.yview)
        lisB.config(yscrollcommand=scl.set)
        for i in self.com:
            lisB.insert("end",i)
        scl.pack(side=RIGHT)
        lisB.pack(side=LEFT)
        fr.grid(row=1,column=0,pady=2,padx=2,sticky='ew')

    def setVar(self,var):
        self.var=[[var,type(val),val]for var,val in var.items()]
        #self.var=var
        self.construire()
    def setCom(self,com):
        self.com=com
        self.construireCom()


if __name__=="__main__":
    boot=Tk()
    tb=TabVariable(boot)
    tb.pack()


        
    
        
